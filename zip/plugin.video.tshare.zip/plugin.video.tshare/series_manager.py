# -*- coding: utf-8 -*-
# Module: series_manager
# Author: Tomas for friends
# Created on: 2.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import os
import io
import re
import json
import xbmc
import xbmcaddon
import xbmcgui
import xml.etree.ElementTree as ET
import unidecode
import traceback

try:
    from urllib import urlencode
    from urlparse import parse_qsl
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

# Regular expressions for detecting episode patterns
EPISODE_PATTERNS = [
    r'[Ss](\d+)[Ee](\d+)',  # S01E01 format
    r'(\d+)x(\d+)',         # 1x01 format
    r'[Ee]pisode\s*(\d+)',  # Episode 1 format
    r'[Ee]p\s*(\d+)',       # Ep 1 format
    r'[Ee](\d+)',           # E1 format
    r'(\d+)\.\s*(\d+)'      # 1.01 format
]

class SeriesManager:
    def __init__(self, addon, profile):
        self.addon = addon
        self.profile = profile
        self.series_db_path = os.path.join(profile, 'series_db')
        self.ensure_db_exists()
        
    def ensure_db_exists(self):
        """Ensure that the series database directory exists"""
        try:
            if not os.path.exists(self.profile):
                os.makedirs(self.profile)
            if not os.path.exists(self.series_db_path):
                os.makedirs(self.series_db_path)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error creating directories: {str(e)}', level=xbmc.LOGERROR)
    
    def search_series(self, series_name, api_function, token):
        """Search for episodes of a series"""
        series_data = {
            'name': series_name,
            'last_updated': xbmc.getInfoLabel('System.Date'),
            'seasons': {}
        }
        
        all_results = self._perform_multi_search(series_name, api_function, token)
        
        # Process and organize results
        for item in all_results:
            season_num, episode_num = self._detect_episode_info(item['name'])
            
            if season_num is not None and episode_num is not None:
                if self._is_likely_episode(item['name'], series_name, season_num, episode_num):
                    season_num_str = str(season_num)
                    episode_num_str = str(episode_num)
                    
                    if season_num_str not in series_data['seasons']:
                        series_data['seasons'][season_num_str] = {}
                    
                    if episode_num_str not in series_data['seasons'][season_num_str]:
                        series_data['seasons'][season_num_str][episode_num_str] = {
                            'episodes': []
                        }
                    
                    series_data['seasons'][season_num_str][episode_num_str]['episodes'].append({
                        'name': item['name'],
                        'ident': item['ident'],
                        'size': item.get('size', '0')
                    })
        
        # Sort episodes by size
        for season in series_data['seasons'].values():
            for episode_data in season.values():
                episode_data['episodes'].sort(key=lambda x: int(x['size']), reverse=True)
        
        # Save the series data
        self._save_series_data(series_name, series_data)
        
        return series_data
    
    def _is_likely_episode(self, filename, series_name, season_num, episode_num):
        """Check if a filename is likely to be an episode of the series based on patterns and name"""
        normalized_filename = unidecode.unidecode(filename).lower()
        normalized_series_name = unidecode.unidecode(series_name).lower().replace(':', '')

        if normalized_series_name.split(' - ')[0] not in normalized_filename:
            return False

        s_e_pattern = f"s{season_num:02d}e{episode_num:02d}"
        x_x_pattern = f"{season_num}x{episode_num}"
        ep_pattern = f"ep{episode_num}"

        if s_e_pattern in normalized_filename or x_x_pattern in normalized_filename or ep_pattern in normalized_filename:
            return True

        return False
    
    def _perform_search(self, search_query, api_function, token):
        """Perform the actual search using the provided API function with pagination"""
        all_results = []
        limit = 100
        offset = 0
        total = limit + 1
        
        while offset < total:
            response = api_function('search', {
                'what': search_query, 
                'category': 'video', 
                'sort': 'recent',
                'limit': limit,
                'offset': offset,
                'wst': token,
                'maybe_removed': 'true'
            })
            
            xml = ET.fromstring(response.content)
            
            status = xml.find('status')
            if status is None or status.text != 'OK':
                break
            
            total_elem = xml.find('total')
            if total_elem is not None:
                total = int(total_elem.text)
            
            for file in xml.iter('file'):
                item = {}
                for elem in file:
                    item[elem.tag] = elem.text
                all_results.append(item)
                
            offset += limit
            
        return all_results

    def _perform_multi_search(self, series_name, api_function, token):
        """Perform search with multiple queries to increase chances of finding correct results."""
        search_queries = []
        
        # Cleaned name without special characters and diacritics
        normalized_name = unidecode.unidecode(series_name).lower()
        normalized_name = re.sub(r'[^a-z0-9\s]', '', normalized_name).strip()
        
        # Prioritized "cz" queries
        search_queries.append(f'{normalized_name} cz')
        search_queries.append(f'{normalized_name.replace(" ", ".")} cz')
        
        # General queries for fallback
        search_queries.append(normalized_name)
        search_queries.append(normalized_name.replace(' ', '.'))

        # Generate queries for the first few episodes to bootstrap the search
        clean_name_for_episodes = unidecode.unidecode(series_name).lower()
        clean_name_for_episodes = re.sub(r'[^a-z0-9\s]', '', clean_name_for_episodes).strip()
        
        for season in range(1, 2):  # Only check season 1
            for episode in range(1, 10): # Check first 10 episodes
                search_queries.append(f'{clean_name_for_episodes} s{season:02d}e{episode:02d}')
                search_queries.append(f'{clean_name_for_episodes}.s{season:02d}e{episode:02d}')
                search_queries.append(f'{clean_name_for_episodes} cz s{season:02d}e{episode:02d}')
                search_queries.append(f'{clean_name_for_episodes}.cz.s{season:02d}e{episode:02d}')

        all_results = []
        seen_idents = set()

        for query in search_queries:
            if not query.strip():
                continue
            
            results = self._perform_search(query, api_function, token)
            for item in results:
                if item['ident'] not in seen_idents:
                    all_results.append(item)
                    seen_idents.add(item['ident'])
        
        return all_results
    
    def _detect_episode_info(self, filename):
        """Try to detect season and episode numbers from filename using only patterns"""
        cleaned = unidecode.unidecode(filename).lower()
        
        for pattern in EPISODE_PATTERNS:
            match = re.search(pattern, cleaned)
            if match:
                groups = match.groups()
                if len(groups) == 2:
                    return int(groups[0]), int(groups[1])
                elif len(groups) == 1:
                    return 1, int(groups[0])
        
        return None, None
    
    def _save_series_data(self, series_name, series_data):
        """Save series data to the database"""
        safe_name = self._safe_filename(series_name)
        file_path = os.path.join(self.series_db_path, f"{safe_name}.json")
        
        try:
            with io.open(file_path, 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(series_data, indent=2).decode('utf8')
                except AttributeError:
                    data = json.dumps(series_data, indent=2)
                file.write(data)
                file.close()
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error saving series data: {str(e)}', level=xbmc.LOGERROR)
    
    def load_series_data(self, series_name):
        """Load series data from the database"""
        safe_name = self._safe_filename(series_name)
        file_path = os.path.join(self.series_db_path, f"{safe_name}.json")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with io.open(file_path, 'r', encoding='utf8') as file:
                data = file.read()
                file.close()
                try:
                    series_data = json.loads(data, "utf-8")
                except TypeError:
                    series_data = json.loads(data)
                return series_data
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error loading series data: {str(e)}', level=xbmc.LOGERROR)
            return None
    
    def get_all_series(self):
        """Get a list of all saved series"""
        series_list = []
        
        try:
            for filename in os.listdir(self.series_db_path):
                if filename.endswith('.json'):
                    series_name = os.path.splitext(filename)[0]
                    proper_name = series_name.replace('_', ' ')
                    series_list.append({
                        'name': proper_name,
                        'filename': filename,
                        'safe_name': series_name
                    })
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error listing series: {str(e)}', level=xbmc.LOGERROR)
        
        return series_list
    
    def _safe_filename(self, name):
        """Convert a series name to a safe filename"""
        safe = re.sub(r'[^\w\-_.\s]', '', name)
        return safe.strip().lower().replace(' ', '_')

# Utility functions for the UI layer
def get_url(**kwargs):
    """Create a URL for calling the plugin recursively"""
    from Tshare import _url
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def create_series_menu(series_manager, handle):
    """Create the series selection menu"""
    import xbmcplugin
    
    listitem = xbmcgui.ListItem(label="Hledat novy serial")
    listitem.setArt({'icon': 'DefaultAddSource.png'})
    xbmcplugin.addDirectoryItem(handle, get_url(action='series_search'), listitem, True)
    
    series_list = series_manager.get_all_series()
    for series in series_list:
        listitem = xbmcgui.ListItem(label=series['name'])
        listitem.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle, get_url(action='series_detail', series_name=series['name']), listitem, True)
    
    xbmcplugin.endOfDirectory(handle)

def create_seasons_menu(series_manager, handle, series_name):
    """Create menu of seasons for a series"""
    import xbmcplugin
    
    series_data = series_manager.load_series_data(series_name)
    if not series_data:
        xbmcgui.Dialog().notification('Tshare', 'Data serialu nenalezena', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    
    listitem = xbmcgui.ListItem(label="Aktualizovat serial")
    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(handle, get_url(action='series_refresh', series_name=series_name), listitem, True)
    
    for season_num in sorted(series_data['seasons'].keys(), key=int):
        season_name = f"Rada {season_num}"
        listitem = xbmcgui.ListItem(label=season_name)
        listitem.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle, get_url(action='series_season', series_name=series_name, season=season_num), listitem, True)
    
    xbmcplugin.endOfDirectory(handle)

def create_episodes_menu(series_manager, handle, series_name, season_num):
    """Create menu of episodes for a season"""
    import xbmcplugin
    from Tshare import sizelize
    
    series_data = series_manager.load_series_data(series_name)
    if not series_data or str(season_num) not in series_data['seasons']:
        xbmcgui.Dialog().notification('Tshare', 'Data sezony nenalezena', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    
    season_num = str(season_num)
    season = series_data['seasons'][season_num]

    for episode_num in sorted(season.keys(), key=int):
        episode_data = season[episode_num]
        
        # Get the largest episode if multiple files are found
        episode = episode_data['episodes'][0]
        
        size_label = sizelize(episode.get('size')) if episode.get('size') else '?'
        episode_label = f"Epizoda {episode_num}: {episode['name']} ({size_label})"
        
        listitem = xbmcgui.ListItem(label=episode_label)
        listitem.setArt({'icon': 'DefaultVideo.png'})
        listitem.setProperty('IsPlayable', 'true')
        
        url = get_url(action='play', ident=episode['ident'], name=episode['name'])
        
        xbmcplugin.addDirectoryItem(handle, url, listitem, False)
    
    xbmcplugin.endOfDirectory(handle)