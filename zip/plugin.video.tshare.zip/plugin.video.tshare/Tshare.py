# -*- coding: utf-8 -*-
# Module: default
# Author: Tomas for friends
# Created on: 2.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import io
import os
import sys
import time
import logging
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import requests.cookies
from xml.etree import ElementTree as ET
import hashlib
from md5crypt import md5crypt
import traceback
import json
import unidecode
import re
import zipfile
import uuid
import series_manager

try:
    from urllib import urlencode
    from urlparse import parse_qsl, urlparse
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl, urlparse

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer':BASE}
REALM = ':Webshare:'
CATEGORIES = ['','video','images','audio','archives','docs','adult']
SORTS = ['','recent','rating','largest','smallest']
SEARCH_HISTORY = 'search_history'
NONE_WHAT = '%#NONE#%'
BACKUP_DB = 'D1iIcURxlR'

# Cache settings
CACHE_TIMEOUT = 300  # 5 minut
_cache = {}

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)
_session.timeout = (10, 30)  # connection timeout, read timeout
_profile = translatePath( _addon.getAddonInfo('profile'))
try:
    _profile = _profile.decode("utf-8")
except:
    pass

# Setup logging
def setup_logging():
    """Setup logging for debugging purposes"""
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)
        log_path = os.path.join(_profile, 'yawsp.log')
        logging.basicConfig(
            filename=log_path,
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            filemode='a'
        )
        # Also log to Kodi log
        logging.getLogger().addHandler(logging.StreamHandler())
    except Exception as e:
        xbmc.log(f'YaWSP: Nelze nastavit logování: {str(e)}', level=xbmc.LOGERROR)

# Initialize logging
setup_logging()

# Regular expressions for detecting episode patterns, shared with series_manager
EPISODE_PATTERNS = [
    r'[Ss](\d+)[Ee](\d+)',  # S01E01 format
    r'(\d+)x(\d+)',         # 1x01 format
    r'[Ee]pisode\s*(\d+)',  # Episode 1 format
    r'[Ee]p\s*(\d+)',       # Ep 1 format
    r'[Ee](\d+)',           # E1 format
    r'(\d+)\.\s*(\d+)'      # 1.01 format
]

def validate_params(params, required_keys):
    """Validate that required parameters are present"""
    for key in required_keys:
        if key not in params or not params[key]:
            logging.error(f'Missing required parameter: {key}')
            return False, f'Missing required parameter: {key}'
    return True, None

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def cached_api_call(fnct, data, cache_key=None):
    """API call with caching for better performance"""
    try:
        # Check cache first
        if cache_key and cache_key in _cache:
            cached_time, cached_response = _cache[cache_key]
            if time.time() - cached_time < CACHE_TIMEOUT:
                logging.debug(f'Using cached response for {cache_key}')
                return cached_response

        # Make API call
        logging.debug(f'Making API call to {fnct} with data: {data}')
        response = _session.post(API + fnct + "/", data=data)

        # Cache the response if cache_key provided
        if cache_key and response.status_code == 200:
            _cache[cache_key] = (time.time(), response)
            logging.debug(f'Cached response for {cache_key}')

        return response

    except requests.Timeout:
        logging.error(f'Timeout při API volání {fnct}')
        popinfo('Vypršel časový limit spojení', icon=xbmcgui.NOTIFICATION_ERROR)
        return None
    except requests.ConnectionError:
        logging.error(f'Chyba připojení při API volání {fnct}')
        popinfo('Chyba připojení k serveru', icon=xbmcgui.NOTIFICATION_ERROR)
        return None
    except requests.RequestException as e:
        logging.error(f'Síťová chyba při API volání {fnct}: {str(e)}')
        popinfo(f'Síťová chyba: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
        return None

def api(fnct, data):
    """Standard API call without caching"""
    return cached_api_call(fnct, data)

def is_ok(xml):
    """Check if XML response indicates success"""
    if xml is None:
        return False
    status_elem = xml.find('status')
    if status_elem is None:
        logging.error('XML response missing status element')
        return False
    return status_elem.text == 'OK'

def popinfo(message, heading=_addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    """Show notification with logging"""
    logging.info(f'Notification: {message}')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def login():
    """Login with improved error handling"""
    try:
        username = _addon.getSetting('wsuser')
        password = _addon.getSetting('wspass')

        if not username or not password:
            logging.warning('Missing login credentials')
            popinfo(_addon.getLocalizedString(30101), sound=True)
            _addon.openSettings()
            return None

        logging.debug(f'Attempting login for user: {username}')
        response = api('salt', {'username_or_email': username})

        if response is None:
            return None

        try:
            xml = ET.fromstring(response.content)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in login: {str(e)}')
            popinfo('Chyba při zpracování odpovědi serveru', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

        if is_ok(xml):
            salt = xml.find('salt').text
            try:
                encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
                pass_digest = hashlib.md5(username.encode('utf-8') + REALM + encrypted_pass.encode('utf-8')).hexdigest()
            except TypeError:
                encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
                pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()

            response = api('login', {'username_or_email': username, 'password': encrypted_pass, 'digest': pass_digest, 'keep_logged_in': 1})
            if response is None:
                return None

            try:
                xml = ET.fromstring(response.content)
            except ET.ParseError as e:
                logging.error(f'XML parsing error in login verification: {str(e)}')
                popinfo('Chyba při zpracování přihlášení', icon=xbmcgui.NOTIFICATION_ERROR)
                return None

            if is_ok(xml):
                token = xml.find('token').text
                _addon.setSetting('token', token)
                logging.info('Login successful')
                return token
            else:
                logging.error('Login failed - invalid credentials')
                popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                _addon.openSettings()
        else:
            logging.error('Salt request failed')
            popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            _addon.openSettings()

    except Exception as e:
        logging.error(f'Unexpected error in login: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při přihlašování', icon=xbmcgui.NOTIFICATION_ERROR)
        return None

def revalidate():
    """Revalidate token with improved error handling"""
    try:
        token = _addon.getSetting('token')
        if len(token) == 0:
            logging.debug('No token found, attempting login')
            new_token = login()
            if new_token:
                return revalidate()
            return None
        else:
            # Use cache for user_data calls
            cache_key = f'user_data_{token[:10]}'
            response = cached_api_call('user_data', {'wst': token}, cache_key)

            if response is None:
                return None

            try:
                xml = ET.fromstring(response.content)
            except ET.ParseError as e:
                logging.error(f'XML parsing error in revalidate: {str(e)}')
                popinfo('Chyba při ověřování přihlášení', icon=xbmcgui.NOTIFICATION_ERROR)
                return None

            if is_ok(xml):
                vip = xml.find('vip')
                if vip is not None and vip.text != '1':
                    popinfo(_addon.getLocalizedString(30103), icon=xbmcgui.NOTIFICATION_WARNING)
                return token
            else:
                logging.warning('Token validation failed, attempting relogin')
                new_token = login()
                if new_token:
                    return revalidate()
                return None

    except Exception as e:
        logging.error(f'Unexpected error in revalidate: {str(e)}')
        traceback.print_exc()
        return None

def todict(xml, skip=[]):
    """Convert XML to dictionary with error handling"""
    try:
        result = {}
        for e in xml:
            if e.tag not in skip:
                value = e.text if len(list(e)) == 0 else todict(e,skip)
                if e.tag in result:
                    if isinstance(result[e.tag], list):
                        result[e.tag].append(value)
                    else:
                        result[e.tag] = [result[e.tag],value]
                else:
                    result[e.tag] = value
        return result
    except Exception as e:
        logging.error(f'Error converting XML to dict: {str(e)}')
        return {}

def sizelize(txtsize, units=['B','KB','MB','GB']):
    """Convert size to human readable format with error handling"""
    try:
        if txtsize:
            size = float(txtsize)
            if size < 1024:
                size = str(size) + units[0]
            else:
                size = size / 1024
                if size < 1024:
                    size = str(int(round(size))) + units[1]
                else:
                    size = size / 1024
                    if size < 1024:
                        size = str(round(size,2)) + units[2]
                    else:
                        size = size / 1024
                        size = str(round(size,2)) + units[3]
            return size
    except (ValueError, TypeError) as e:
        logging.warning(f'Error formatting size {txtsize}: {str(e)}')
    return str(txtsize) if txtsize else '?'

def labelize(file):
    """Create label for file with error handling"""
    try:
        if 'size' in file:
            size = sizelize(file['size'])
        elif 'sizelized' in file:
            size = file['sizelized']
        else:
            size = '?'
        name = file.get('name', 'Unknown')
        label = name + ' (' + size + ')'
        return label
    except Exception as e:
        logging.error(f'Error creating label: {str(e)}')
        return file.get('name', 'Unknown file')

def tolistitem(file, addcommands=[]):
    """Create list item with error handling"""
    try:
        label = labelize(file)
        listitem = xbmcgui.ListItem(label=label)

        if 'img' in file and file['img']:
            listitem.setArt({'thumb': file['img']})

        listitem.setInfo('video', {'title': label})
        listitem.setProperty('IsPlayable', 'true')

        commands = []
        if 'ident' in file:
            commands.append(( _addon.getLocalizedString(30211), 'RunPlugin(' + get_url(action='info',ident=file['ident']) + ')'))
            commands.append(( _addon.getLocalizedString(30212), 'RunPlugin(' + get_url(action='download',ident=file['ident']) + ')'))

        if addcommands:
            commands = commands + addcommands
        listitem.addContextMenuItems(commands)
        return listitem
    except Exception as e:
        logging.error(f'Error creating list item: {str(e)}')
        # Return basic listitem as fallback
        fallback_label = file.get('name', 'Error item')
        return xbmcgui.ListItem(label=fallback_label)

def ask(what):
    """Ask user for input with validation"""
    try:
        if what is None:
            what = ''
        kb = xbmc.Keyboard(what, _addon.getLocalizedString(30007))
        kb.doModal()
        if kb.isConfirmed():
            user_input = kb.getText().strip()
            logging.debug(f'User input: {user_input}')
            return user_input
        return None
    except Exception as e:
        logging.error(f'Error in user input dialog: {str(e)}')
        return None

def loadsearch():
    """Load search history with error handling"""
    history = []
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)

        history_file = os.path.join(_profile, SEARCH_HISTORY)
        if os.path.exists(history_file):
            with io.open(history_file, 'r', encoding='utf8') as file:
                fdata = file.read()
                try:
                    history = json.loads(fdata, "utf-8")
                except TypeError:
                    history = json.loads(fdata)

    except (IOError, json.JSONDecodeError) as e:
        logging.error(f'Error loading search history: {str(e)}')
    except Exception as e:
        logging.error(f'Unexpected error loading search history: {str(e)}')

    return history if isinstance(history, list) else []

def storesearch(what):
    """Store search term with error handling"""
    if not what or not what.strip():
        return

    try:
        size = int(_addon.getSetting('shistory'))
        history = loadsearch()

        if what in history:
            history.remove(what)

        history = [what] + history

        if len(history) > size:
            history = history[:size]

        with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
            try:
                data = json.dumps(history).decode('utf8')
            except AttributeError:
                data = json.dumps(history)
            file.write(data)

        logging.debug(f'Stored search term: {what}')

    except (IOError, ValueError) as e:
        logging.error(f'Error storing search history: {str(e)}')
    except Exception as e:
        logging.error(f'Unexpected error storing search: {str(e)}')

def removesearch(what):
    """Remove search term with error handling"""
    if not what:
        return

    try:
        history = loadsearch()
        if what in history:
            history.remove(what)
            with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(history).decode('utf8')
                except AttributeError:
                    data = json.dumps(history)
                file.write(data)
            logging.debug(f'Removed search term: {what}')

    except (IOError, ValueError) as e:
        logging.error(f'Error removing search history: {str(e)}')
    except Exception as e:
        logging.error(f'Unexpected error removing search: {str(e)}')

def _detect_episode_info(filename):
    """Try to detect season and episode numbers from filename using patterns"""
    try:
        if not filename:
            return None, None

        # Normalize the filename for better matching
        cleaned = unidecode.unidecode(filename).lower()

        # Try each of our patterns
        for pattern in EPISODE_PATTERNS:
            match = re.search(pattern, cleaned)
            if match:
                groups = match.groups()
                if len(groups) == 2:  # Patterns like S01E02 or 1x02
                    return int(groups[0]), int(groups[1])
                elif len(groups) == 1:  # Patterns like E02 or Episode 2
                    return 1, int(groups[0])

        return None, None
    except Exception as e:
        logging.error(f'Error detecting episode info from {filename}: {str(e)}')
        return None, None

def dosearch(token, what, category, sort, limit, offset, action):
    """Enhanced search function with better error handling and series detection"""
    try:
        if not token:
            logging.error('No valid token for search')
            popinfo('Chyba autentifikace', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)
            return

        # OPRAVENO: Pouze při explicitním hledání seriálů použij SeriesManager
        explicit_series_search = (action == 'series_search' or
                                 'series' in str(action).lower() or
                                 category == 'series')

        logging.debug(f'Search: what="{what}", action="{action}", explicit_series={explicit_series_search}')

        # Pokud není explicitní hledání seriálů, použij standardní vyhledávání
        if not explicit_series_search:
            found_files = {}

            # Parsing pro TMDB formát: {showname} {year} cz {originaltitle}
            showname = None
            originaltitle = None
            year = None

            # TMDB formát: "Válka světů 2005 cz War of the Worlds"
            tmdb_match = re.search(r'(.+?)\s+(\d{4})\s+cz\s+(.+)', what.strip(), re.IGNORECASE)

            if tmdb_match:
                showname = tmdb_match.group(1).strip()
                year = tmdb_match.group(2).strip()
                originaltitle = tmdb_match.group(3).strip()
                logging.debug(f'TMDB format - Czech: "{showname}", Year: "{year}", English: "{originaltitle}"')
            else:
                # Fallback - možná není "cz" v názvu nebo jiný formát
                year_match = re.search(r'(\d{4})', what)
                if year_match:
                    year = year_match.group(1)
                    showname = what.replace(year, '').strip()
                else:
                    showname = what.strip()
                logging.debug(f'Fallback parsing - Name: "{showname}", Year: "{year}"')

            # Očistí názvy od extra mezer
            if showname:
                showname = re.sub(r'\s+', ' ', showname).strip()
            if originaltitle:
                originaltitle = re.sub(r'\s+', ' ', originaltitle).strip()

            # Inteligentní vyhledávání - nejdříve český název, pak anglický
            search_queries = []

            # 1. Primární hledání: český název s rokem a 'cz'
            query1 = f'{showname} {year} cz' if year else f'{showname} cz'
            search_queries.append(('czech', query1))

            # 2. Fallback: anglický originální název s rokem a 'cz'
            if originaltitle and showname != originaltitle:
                query2 = f'{originaltitle} {year} cz' if year else f'{originaltitle} cz'
                search_queries.append(('english', query2))

            # 3. Další fallback: český název bez 'cz'
            query3 = f'{showname} {year}' if year else showname
            search_queries.append(('czech_nocz', query3))

            # 4. Poslední fallback: anglický název bez 'cz'
            if originaltitle and showname != originaltitle:
                query4 = f'{originaltitle} {year}' if year else originaltitle
                search_queries.append(('english_nocz', query4))

            # Postupně zkouší všechny varianty dokud nenajde dostatek výsledků
            for search_type, query in search_queries:
                if len(found_files) >= 10:  # Máme dost výsledků, končíme
                    break

                popinfo(_addon.getLocalizedString(30209) + f' "{query}" ({search_type})', icon=xbmcgui.NOTIFICATION_INFO)
                logging.debug(f'Searching with {search_type}: {query}')

                cache_key = f'search_{hashlib.md5(query.encode()).hexdigest()}'
                response = cached_api_call('search', {
                    'what': query,
                    'category': category,
                    'sort': sort,
                    'limit': limit,
                    'offset': offset,
                    'wst': token,
                    'maybe_removed': 'true'
                }, cache_key)

                if response is None:
                    continue

                try:
                    xml = ET.fromstring(response.content)
                    if is_ok(xml):
                        new_results = 0
                        for file in xml.iter('file'):
                            try:
                                item = todict(file)
                                if 'ident' in item and item['ident'] not in found_files:
                                    found_files[item['ident']] = item
                                    new_results += 1
                            except Exception as e:
                                logging.warning(f'Error processing search result: {str(e)}')
                                continue
                        logging.debug(f'Found {new_results} new results with {search_type} search')
                except ET.ParseError as e:
                    logging.error(f'XML parsing error in {search_type} search: {str(e)}')
                    continue

            # Display results
            if not found_files:
                logging.info(f'No results found for: {what}')
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
            else:
                logging.info(f'Found {len(found_files)} results for: {what}')
                for ident, file_item in found_files.items():
                    try:
                        listitem = tolistitem(file_item)
                        xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=ident,name=file_item.get('name', 'Unknown')), listitem, False)
                    except Exception as e:
                        logging.warning(f'Error adding item to directory: {str(e)}')
                        continue

            xbmcplugin.endOfDirectory(_handle)
            return

        # POUZE pro explicitní hledání seriálů použij SeriesManager
        logging.debug('Using SeriesManager for series search')
        try:
            sm = series_manager.SeriesManager(_addon, _profile)
            series_data = sm.search_series(what, api, token)

            if series_data and series_data.get('seasons'):
                progress = xbmcgui.DialogProgress()
                progress.create('YaWSP', f'Nalezen serial {what}...')
                progress.close()

                total_episodes = sum(len(season) for season in series_data["seasons"].values())
                popinfo(f'Nalezeno {total_episodes} epizod v {len(series_data["seasons"])} sezonach')
                xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=what)})')
                xbmcplugin.endOfDirectory(_handle)
                return

            # Pokud nejsou nalezeny žádné seriály
            popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(_handle)

        except Exception as e:
            logging.error(f'Error in SeriesManager search: {str(e)}')
            traceback.print_exc()
            popinfo(f'Chyba při hledání seriálu: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Unexpected error in dosearch: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def direct_search(params):
    """
    Zpracuje požadavek na přímé vyhledávání z externích zdrojů (jako je TMDB Helper).
    Přeskočí uživatelský vstup a menu historie vyhledávání.
    """
    try:
        # 1. Získej vyhledávací dotaz z parametrů URL
        what = params.get('what', None)
        if not what:
            logging.error("Přímé vyhledávání bylo voláno bez parametru 'what'.")
            popinfo('Chyba: Chybí název k vyhledání', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)
            return

        # 2. Získej další parametry z nastavení nebo URL
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        category = params.get('category', CATEGORIES[int(_addon.getSetting('scategory'))])
        sort = params.get('sort', SORTS[int(_addon.getSetting('ssort'))])
        limit = int(params.get('limit', _addon.getSetting('slimit')))
        offset = int(params.get('offset', 0))

        # 3. Přímé volání hlavní logiky vyhledávání (dosearch)
        dosearch(token, what, category, sort, limit, offset, 'direct_search')

    except Exception as e:
        logging.error(f'Chyba v direct_search: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při přímém vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search(params):
    """Main search function with parameter validation"""
    try:
        show_search_menu = params.get('show_search_menu')
        what = params.get('what', None)

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + _addon.getLocalizedString(30201))
        token = revalidate()

        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False

        if 'remove' in params:
            removesearch(params['remove'])
            updateListing = True

        if 'toqueue' in params:
            toqueue(params['toqueue'], token)
            updateListing = True

        if 'what' in params:
            what = params['what']

        if 'ask' in params and params['ask'] == '1' and 'query' not in params:
            if what is not None and what == NONE_WHAT:
                history = loadsearch()
                listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30205))
                listitem.setArt({'icon': 'DefaultAddSource.png'})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='search',ask=1), listitem, True)

                listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30208))
                listitem.setArt({'icon': 'DefaultAddonsRecentlyUpdated.png'})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[1]), listitem, True)

                listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30209))
                listitem.setArt({'icon': 'DefaultHardDisk.png'})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[3]), listitem, True)

                for search_item in history:
                    try:
                        listitem = xbmcgui.ListItem(label=str(search_item))
                        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
                        commands = []
                        commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search_item) + ')'))
                        listitem.addContextMenuItems(commands)
                        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=search_item), listitem, True)
                    except Exception as e:
                        logging.warning(f'Error adding history item {search_item}: {str(e)}')
                        continue

                xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)
                return

            what = ask(what)
            if what is not None:
                storesearch(what)
            else:
                updateListing = True

        if what is not None:
            if 'offset' not in params:
                _addon.setSetting('slast', what)
            else:
                _addon.setSetting('slast', NONE_WHAT)
                updateListing = True

            try:
                category = params.get('category', CATEGORIES[int(_addon.getSetting('scategory'))])
                sort = params.get('sort', SORTS[int(_addon.getSetting('ssort'))])
                limit = int(params.get('limit', _addon.getSetting('slimit')))
                offset = int(params.get('offset', 0))
            except (ValueError, IndexError) as e:
                logging.error(f'Error parsing search parameters: {str(e)}')
                # Use defaults
                category = CATEGORIES[0]
                sort = SORTS[0]
                limit = 50
                offset = 0

            # Přidání možnosti filtrování
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30216))
            listitem.setArt({'icon': 'DefaultFilter.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search_filter', what=what, category=category, sort=sort, limit=limit, offset=offset), listitem, True)

            dosearch(token, what, category, sort, limit, offset, 'search')
        else:
            _addon.setSetting('slast', NONE_WHAT)
            history = loadsearch()
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30205))
            listitem.setArt({'icon': 'DefaultAddSource.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',ask=1), listitem, True)

            # newest
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30208))
            listitem.setArt({'icon': 'DefaultAddonsRecentlyUpdated.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[1]), listitem, True)

            # biggest
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30209))
            listitem.setArt({'icon': 'DefaultHardDisk.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[3]), listitem, True)

            for search_item in history:
                try:
                    listitem = xbmcgui.ListItem(label=str(search_item))
                    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
                    commands = []
                    commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search_item) + ')'))
                    listitem.addContextMenuItems(commands)
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=search_item), listitem, True)
                except Exception as e:
                    logging.warning(f'Error adding history item {search_item}: {str(e)}')
                    continue

        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in search: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_filter(params):
    """Search filter menu with validation"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ Filtry")

        what = params.get('what', None)
        category = params.get('category', CATEGORIES[0])
        sort = params.get('sort', SORTS[0])
        limit = params.get('limit', _addon.getSetting('slimit'))
        offset = params.get('offset', 0)

        # Menu pro kategorie
        listitem_category = xbmcgui.ListItem(label='Kategorie: ' + (category if category else 'Vše'))
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search_category_menu', what=what, sort=sort, limit=limit, offset=offset), listitem_category, True)

        # Menu pro řazení
        listitem_sort = xbmcgui.ListItem(label='Řazení: ' + (sort if sort else 'Výchozí'))
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search_sort_menu', what=what, category=category, limit=limit, offset=offset), listitem_sort, True)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Error in search_filter: {str(e)}')
        popinfo('Chyba při zobrazení filtrů', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_category_menu(params):
    """Category selection menu with validation"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ Filtry \\\\ Kategorie")

        what = params.get('what', None)
        sort = params.get('sort', SORTS[0])
        limit = params.get('limit', _addon.getSetting('slimit'))
        offset = params.get('offset', 0)

        categories = ['Vše'] + [c.capitalize() for c in CATEGORIES if c]
        for cat in categories:
            category_value = '' if cat == 'Vše' else cat.lower()
            listitem = xbmcgui.ListItem(label=cat)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=what, category=category_value, sort=sort, limit=limit, offset=offset), listitem, True)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Error in search_category_menu: {str(e)}')
        popinfo('Chyba při zobrazení kategorií', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_sort_menu(params):
    """Sort selection menu with validation"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ Filtry \ Řazení")

        what = params.get('what', None)
        category = params.get('category', CATEGORIES[0])
        limit = params.get('limit', _addon.getSetting('slimit'))
        offset = params.get('offset', 0)

        sorts = ['Výchozí','Nejnovější','Hodnocení','Největší','Nejmenší']
        sort_values = [''] + SORTS[1:]

        for i, sort_label in enumerate(sorts):
            listitem = xbmcgui.ListItem(label=sort_label)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=what, category=category, sort=sort_values[i], limit=limit, offset=offset), listitem, True)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Error in search_sort_menu: {str(e)}')
        popinfo('Chyba při zobrazení řazení', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def queue(params):
    """Queue management with enhanced error handling"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + _addon.getLocalizedString(30202))
        token = revalidate()

        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False

        if 'dequeue' in params:
            response = api('dequeue_file',{'ident':params['dequeue'],'wst':token})
            if response is None:
                xbmcplugin.endOfDirectory(_handle)
                return

            try:
                xml = ET.fromstring(response.content)
                if is_ok(xml):
                    popinfo(_addon.getLocalizedString(30106))
                else:
                    popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                updateListing = True
            except ET.ParseError as e:
                logging.error(f'XML parsing error in dequeue: {str(e)}')
                popinfo('Chyba při odebírání ze fronty', icon=xbmcgui.NOTIFICATION_ERROR)

        response = api('queue',{'wst':token})
        if response is None:
            xbmcplugin.endOfDirectory(_handle)
            return

        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                for file in xml.iter('file'):
                    try:
                        item = todict(file)
                        if 'ident' in item:
                            commands = []
                            commands.append(( _addon.getLocalizedString(30215), 'Container.Update(' + get_url(action='queue',dequeue=item['ident']) + ')'))
                            listitem = tolistitem(item, commands)
                            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item.get('name', 'Unknown')), listitem, False)
                    except Exception as e:
                        logging.warning(f'Error processing queue item: {str(e)}')
                        continue
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in queue: {str(e)}')
            popinfo('Chyba při načítání fronty', icon=xbmcgui.NOTIFICATION_ERROR)

        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in queue: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba ve frontě', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def toqueue(ident, token):
    """Add to queue with error handling"""
    try:
        if not ident or not token:
            logging.error('Missing ident or token for queue operation')
            popinfo('Chyba při přidávání do fronty', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        response = api('queue_file',{'ident':ident,'wst':token})
        if response is None:
            return

        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                popinfo(_addon.getLocalizedString(30105))
                logging.info(f'Successfully queued file: {ident}')
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                logging.warning(f'Failed to queue file: {ident}')
        except ET.ParseError as e:
            logging.error(f'XML parsing error in toqueue: {str(e)}')
            popinfo('Chyba při přidávání do fronty', icon=xbmcgui.NOTIFICATION_ERROR)

    except Exception as e:
        logging.error(f'Unexpected error in toqueue: {str(e)}')
        popinfo('Neočekávaná chyba při přidávání do fronty', icon=xbmcgui.NOTIFICATION_ERROR)

def history(params):
    """History management with enhanced error handling"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\ " + _addon.getLocalizedString(30203))
        token = revalidate()

        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False

        if 'remove' in params:
            remove = params['remove']
            updateListing = True

            response = api('history',{'wst':token})
            if response is None:
                xbmcplugin.endOfDirectory(_handle)
                return

            try:
                xml = ET.fromstring(response.content)
                ids = []
                if is_ok(xml):
                    for file in xml.iter('file'):
                        ident_elem = file.find('ident')
                        download_id_elem = file.find('download_id')
                        if ident_elem is not None and download_id_elem is not None:
                            if remove == ident_elem.text:
                                ids.append(download_id_elem.text)
                else:
                    popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)

                if ids:
                    rr = api('clear_history',{'ids[]':ids,'wst':token})
                    if rr is not None:
                        try:
                            xml = ET.fromstring(rr.content)
                            if is_ok(xml):
                                popinfo(_addon.getLocalizedString(30104))
                            else:
                                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                        except ET.ParseError as e:
                            logging.error(f'XML parsing error in clear_history: {str(e)}')

            except ET.ParseError as e:
                logging.error(f'XML parsing error in history removal: {str(e)}')
                popinfo('Chyba při odebírání z historie', icon=xbmcgui.NOTIFICATION_ERROR)

        if 'toqueue' in params:
            toqueue(params['toqueue'], token)
            updateListing = True

        response = api('history',{'wst':token})
        if response is None:
            xbmcplugin.endOfDirectory(_handle)
            return

        try:
            xml = ET.fromstring(response.content)
            files = []
            if is_ok(xml):
                for file in xml.iter('file'):
                    try:
                        item = todict(file, ['ended_at', 'download_id', 'started_at'])
                        if item and item not in files:
                            files.append(item)
                    except Exception as e:
                        logging.warning(f'Error processing history item: {str(e)}')
                        continue

                for file in files:
                    try:
                        if 'ident' in file:
                            commands = []
                            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='history',remove=file['ident']) + ')'))
                            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='history',toqueue=file['ident']) + ')'))
                            listitem = tolistitem(file, commands)
                            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=file['ident'],name=file.get('name', 'Unknown')), listitem, False)
                    except Exception as e:
                        logging.warning(f'Error adding history item to directory: {str(e)}')
                        continue
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in history: {str(e)}')
            popinfo('Chyba při načítání historie', icon=xbmcgui.NOTIFICATION_ERROR)

        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in history: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba v historii', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def settings(params):
    """Open settings"""
    try:
        _addon.openSettings()
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
    except Exception as e:
        logging.error(f'Error opening settings: {str(e)}')

def infonize(data, key, process=str, showkey=True, prefix='', suffix='\n'):
    """Format info with error handling"""
    try:
        if key in data and data[key] is not None:
            processed_value = process(data[key])
            return prefix + (key.capitalize() + ': ' if showkey else '') + str(processed_value) + suffix
    except Exception as e:
        logging.warning(f'Error formatting info for key {key}: {str(e)}')
    return ''

def fpsize(fps):
    """Format FPS with error handling"""
    try:
        x = round(float(fps), 3)
        if int(x) == x:
           return str(int(x))
        return str(x)
    except (ValueError, TypeError):
        return str(fps) if fps else '?'

def getinfo(ident, wst):
    """Get file info with enhanced error handling"""
    try:
        if not ident or not wst:
            logging.error('Missing ident or token for getinfo')
            return None

        # Try with cache first
        cache_key = f'info_{ident}'
        response = cached_api_call('file_info', {'ident':ident,'wst': wst}, cache_key)

        if response is None:
            return None

        try:
            xml = ET.fromstring(response.content)
            ok = is_ok(xml)

            if not ok:
                # Try with maybe_removed flag
                response = api('file_info',{'ident':ident,'wst': wst, 'maybe_removed':'true'})
                if response is None:
                    return None
                xml = ET.fromstring(response.content)
                ok = is_ok(xml)

            if ok:
                return xml
            else:
                logging.warning(f'File info not found for ident: {ident}')
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                return None

        except ET.ParseError as e:
            logging.error(f'XML parsing error in getinfo: {str(e)}')
            popinfo('Chyba při zpracování informací o souboru', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

    except Exception as e:
        logging.error(f'Unexpected error in getinfo: {str(e)}')
        traceback.print_exc()
        return None

def getlink(ident, wst, dtype='video_stream'):
    """Get download link with enhanced error handling"""
    try:
        if not ident or not wst:
            logging.error('Missing ident or token for getlink')
            return None

        # UUID experiment
        duuid = _addon.getSetting('duuid')
        if not duuid:
            duuid = str(uuid.uuid4())
            _addon.setSetting('duuid', duuid)

        data = {'ident':ident,'wst': wst,'download_type':dtype,'device_uuid':duuid}

        response = api('file_link', data)
        if response is None:
            return None

        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                link_elem = xml.find('link')
                if link_elem is not None:
                    link = link_elem.text
                    logging.debug(f'Successfully got link for ident: {ident}')
                    return link
                else:
                    logging.error('Link element not found in response')
                    return None
            else:
                logging.warning(f'Failed to get link for ident: {ident}')
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                return None
        except ET.ParseError as e:
            logging.error(f'XML parsing error in getlink: {str(e)}')
            popinfo('Chyba při získávání odkazu', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

    except Exception as e:
        logging.error(f'Unexpected error in getlink: {str(e)}')
        traceback.print_exc()
        return None

def play(params):
    """Play file with robust error handling"""
    try:
        # Validate required parameters
        valid, error_msg = validate_params(params, ['ident', 'name'])
        if not valid:
            logging.error(f'Invalid play parameters: {error_msg}')
            popinfo('Chyba při spouštění - chybí parametry', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return

        token = revalidate()
        if not token:
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return

        link = getlink(params['ident'], token)
        if link is not None:
            # Headers experiment
            headers = _session.headers.copy()
            if headers:
                headers.update({'Cookie':'wst='+token})
                link = link + '|' + urlencode(headers)

            listitem = xbmcgui.ListItem(label=params['name'], path=link)
            listitem.setProperty('mimetype', 'application/octet-stream')
            logging.info(f'Successfully playing: {params["name"]}')
            xbmcplugin.setResolvedUrl(_handle, True, listitem)
        else:
            logging.error(f'Failed to get link for: {params["name"]}')
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

    except Exception as e:
        logging.error(f'Unexpected error in play: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při spouštění', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def join(path, file):
    """Join path components safely"""
    try:
        if not path or not file:
            return path or file or ''

        if path.endswith('/') or path.endswith('\\'):
            return path + file
        else:
            return path + '/' + file
    except Exception as e:
        logging.error(f'Error joining paths {path} and {file}: {str(e)}')
        return str(path) + '/' + str(file)

def download(params):
    """Download file with comprehensive error handling"""
    try:
        # Validate parameters
        valid, error_msg = validate_params(params, ['ident'])
        if not valid:
            logging.error(f'Invalid download parameters: {error_msg}')
            popinfo('Chyba při stahování - chybí parametry', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        token = revalidate()
        if not token:
            return

        where = _addon.getSetting('dfolder')
        if not where or not xbmcvfs.exists(where):
            popinfo('Nastavte složku pro stahování!', sound=True)
            _addon.openSettings()
            return

        local = os.path.exists(where)
        normalize = 'true' == _addon.getSetting('dnormalize')
        notify = 'true' == _addon.getSetting('dnotify')

        try:
            every = int(re.sub(r'[^\d]+', '', _addon.getSetting('dnevery')))
        except:
            every = 10

        # Get download link and file info
        link = getlink(params['ident'], token, 'file_download')
        if not link:
            return

        info_xml = getinfo(params['ident'], token)
        if not info_xml:
            return

        name_elem = info_xml.find('name')
        if name_elem is None:
            logging.error('File name not found in info response')
            popinfo('Nepodařilo se získat název souboru', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        name = name_elem.text
        if normalize:
            name = unidecode.unidecode(name)

        # Open file for writing
        try:
            if local:
                bf = io.open(os.path.join(where, name), 'wb')
            else:
                bf = xbmcvfs.File(join(where, name), 'w')
        except IOError as e:
            logging.error(f'Cannot open file for writing: {str(e)}')
            popinfo(f'Nepodařilo se otevřít soubor pro zápis: {name}', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        try:
            response = _session.get(link, stream=True)
            response.raise_for_status()

            total = response.headers.get('content-length')
            if total is None:
                popinfo(_addon.getLocalizedString(30301) + name, icon=xbmcgui.NOTIFICATION_WARNING, sound=True)
                bf.write(response.content)
            elif not notify:
                popinfo(_addon.getLocalizedString(30302) + name)
                bf.write(response.content)
            else:
                popinfo(_addon.getLocalizedString(30302) + name)
                dl = 0
                total = int(total)
                pct = max(total / 100, 1)  # Avoid division by zero
                lastpop = 0

                for data in response.iter_content(chunk_size=4096):
                    dl += len(data)
                    bf.write(data)
                    done = int(dl / pct)
                    if done % every == 0 and lastpop != done and done <= 100:
                        popinfo(str(done) + '% - ' + name)
                        lastpop = done

            bf.close()
            logging.info(f'Successfully downloaded: {name}')
            popinfo(_addon.getLocalizedString(30303) + name, sound=True)

        except requests.RequestException as e:
            bf.close()
            logging.error(f'Download failed for {name}: {str(e)}')
            popinfo(f'Chyba při stahování: {name}', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            # TODO: Remove unfinished file

    except Exception as e:
        logging.error(f'Unexpected error in download: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při stahování', icon=xbmcgui.NOTIFICATION_ERROR)

def loaddb(dbdir, file):
    """Load database with error handling"""
    try:
        file_path = os.path.join(dbdir, file)
        if not os.path.exists(file_path):
            logging.warning(f'Database file not found: {file_path}')
            return {}

        with io.open(file_path, 'r', encoding='utf8') as f:
            fdata = f.read()
            try:
                data = json.loads(fdata, "utf-8")['data']
            except TypeError:
                data = json.loads(fdata)['data']
            return data
    except (IOError, json.JSONDecodeError, KeyError) as e:
        logging.error(f'Error loading database {file}: {str(e)}')
        return {}
    except Exception as e:
        logging.error(f'Unexpected error loading database {file}: {str(e)}')
        traceback.print_exc()
        return {}

def db(params):
    """Database management with error handling"""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False
        dbdir = os.path.join(_profile, 'db')

        if not os.path.exists(dbdir):
            try:
                link = getlink(BACKUP_DB, token)
                if not link:
                    xbmcplugin.endOfDirectory(_handle)
                    return

                dbfile = os.path.join(_profile, 'db.zip')
                with io.open(dbfile, 'wb') as bf:
                    response = _session.get(link, stream=True)
                    response.raise_for_status()
                    bf.write(response.content)

                with zipfile.ZipFile(dbfile, 'r') as zf:
                    zf.extractall(_profile)
                os.unlink(dbfile)
                logging.info('Database successfully downloaded and extracted')

            except (requests.RequestException, zipfile.BadZipFile, IOError) as e:
                logging.error(f'Error setting up database: {str(e)}')
                popinfo('Chyba při nastavování databáze', icon=xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(_handle)
                return

        if 'toqueue' in params:
            toqueue(params['toqueue'], token)
            updateListing = True

        if 'file' in params and 'key' in params:
            data = loaddb(dbdir, params['file'])
            if data:
                item = next((x for x in data if x.get('id') == params['key']), None)
                if item is not None and 'streams' in item:
                    for stream in item['streams']:
                        try:
                            commands = []
                            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='db',file=params['file'],key=params['key'],toqueue=stream['ident']) + ')'))

                            stream_info = {
                                'ident': stream['ident'],
                                'name': stream.get('quality', '?') + ' - ' + stream.get('lang', '?') + stream.get('ainfo', ''),
                                'sizelized': stream.get('size', '?')
                            }

                            listitem = tolistitem(stream_info, commands)
                            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=stream['ident'],name=item.get('title', 'Unknown')), listitem, False)
                        except Exception as e:
                            logging.warning(f'Error processing stream: {str(e)}')
                            continue

        elif 'file' in params:
            data = loaddb(dbdir, params['file'])
            for item in data:
                try:
                    if 'id' in item and 'title' in item:
                        listitem = xbmcgui.ListItem(label=item['title'])
                        if 'plot' in item:
                            listitem.setInfo('video', {'title': item['title'],'plot': item['plot']})
                        xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=dbfile,key=item['id']), listitem, True)
                except Exception as e:
                    logging.warning(f'Error processing db item: {str(e)}')
                    continue
        else:
            if os.path.exists(dbdir):
                try:
                    dbfiles = [f for f in os.listdir(dbdir) if os.path.isfile(os.path.join(dbdir, f))]
                    for dbfile in dbfiles:
                        try:
                            listitem = xbmcgui.ListItem(label=os.path.splitext(dbfile)[0])
                            xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=dbfile), listitem, True)
                        except Exception as e:
                            logging.warning(f'Error processing db file {dbfile}: {str(e)}')
                            continue
                except OSError as e:
                    logging.error(f'Error listing database directory: {str(e)}')

        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in db: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba v databázi', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def menu():
    """Main menu with error handling"""
    try:
        token = revalidate()
        if not token:
            # Still show menu even if login fails
            pass

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))

        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30201))
        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', show_search_menu='true'), listitem, True)

        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30202))
        listitem.setArt({'icon': 'DefaultPlaylist.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='queue'), listitem, True)

        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30203))
        listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='history'), listitem, True)

        # Add Series Manager menu item
        listitem = xbmcgui.ListItem(label='Serialy')
        listitem.setArt({'icon': 'DefaultTVShows.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='series'), listitem, True)

        if 'true' == _addon.getSetting('experimental'):
            listitem = xbmcgui.ListItem(label='Backup DB')
            listitem.setArt({'icon': 'DefaultAddonsZip.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='db'), listitem, True)

        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30204))
        listitem.setArt({'icon': 'DefaultAddonService.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='settings'), listitem, False)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Unexpected error in menu: {str(e)}')
        traceback.print_exc()
        # Still try to show basic menu
        xbmcplugin.endOfDirectory(_handle)

def series_menu(params):
    """Handle Series functionality with error handling"""
    try:
        sm = series_manager.SeriesManager(_addon, _profile)
        series_manager.create_series_menu(sm, _handle)
    except Exception as e:
        logging.error(f'Error in series_menu: {str(e)}')
        popinfo('Chyba při zobrazení seriálů', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def series_search(params):
    """Search for a TV series with enhanced error handling"""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        series_name_param = params.get('series_name', None)

        if not series_name_param:
            user_input = ask(None)
            if not user_input:
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return
            series_name_param = user_input

        sm = series_manager.SeriesManager(_addon, _profile)

        progress = xbmcgui.DialogProgress()
        progress.create('YaWSP', f'Vyhledavam serial {series_name_param}...')

        try:
            series_data = sm.search_series(series_name_param, api, token)

            if not series_data or not series_data.get('seasons'):
                progress.close()
                popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return

            progress.close()
            total_episodes = sum(len(season) for season in series_data["seasons"].values())
            popinfo(f'Nalezeno {total_episodes} epizod v {len(series_data["seasons"])} sezonach')

            xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name_param)})')

        except Exception as e:
            progress.close()
            logging.error(f'Error in series search: {str(e)}')
            traceback.print_exc()
            popinfo(f'Chyba při hledání seriálu: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)

    except Exception as e:
        logging.error(f'Unexpected error in series_search: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při hledání seriálu', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def series_detail(params):
    """Show seasons for a series with error handling"""
    try:
        series_name = params.get('series_name')
        if not series_name:
            logging.error('Missing series_name in series_detail')
            xbmcplugin.endOfDirectory(_handle)
            return

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + series_name)

        sm = series_manager.SeriesManager(_addon, _profile)
        series_manager.create_seasons_menu(sm, _handle, series_name)

    except Exception as e:
        logging.error(f'Error in series_detail: {str(e)}')
        popinfo('Chyba při zobrazení seriálu', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def series_season(params):
    """Show episodes for a season with error handling"""
    try:
        valid, error_msg = validate_params(params, ['series_name', 'season'])
        if not valid:
            logging.error(f'Invalid series_season parameters: {error_msg}')
            xbmcplugin.endOfDirectory(_handle)
            return

        series_name = params['series_name']
        season = params['season']

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + series_name + " \\\\ " + f"Rada {season}")

        sm = series_manager.SeriesManager(_addon, _profile)
        series_manager.create_episodes_menu(sm, _handle, series_name, season)

    except Exception as e:
        logging.error(f'Error in series_season: {str(e)}')
        popinfo('Chyba při zobrazení sezóny', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def series_refresh(params):
    """Refresh series data with error handling"""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        series_name = params.get('series_name')
        if not series_name:
            logging.error('Missing series_name in series_refresh')
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        sm = series_manager.SeriesManager(_addon, _profile)

        progress = xbmcgui.DialogProgress()
        progress.create('YaWSP', f'Aktualizuji data pro serial {series_name}...')

        try:
            series_data = sm.search_series(series_name, api, token)

            if not series_data or not series_data.get('seasons'):
                progress.close()
                popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return

            progress.close()
            total_episodes = sum(len(season) for season in series_data["seasons"].values())
            popinfo(f'Aktualizovano: {total_episodes} epizod v {len(series_data["seasons"])} sezonach')

            xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name)})')

        except Exception as e:
            progress.close()
            logging.error(f'Error refreshing series: {str(e)}')
            traceback.print_exc()
            popinfo(f'Chyba při aktualizaci: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)

    except Exception as e:
        logging.error(f'Unexpected error in series_refresh: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při aktualizaci', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def info(params):
    """Show file info with error handling"""
    try:
        valid, error_msg = validate_params(params, ['ident'])
        if not valid:
            logging.error(f'Invalid info parameters: {error_msg}')
            popinfo('Chyba při zobrazení informací', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        token = revalidate()
        if not token:
            return

        ident = params['ident']
        xml = getinfo(ident, token)

        if xml is not None:
            try:
                file = todict(xml)
                dialog = xbmcgui.Dialog()

                info_text = infonize(file, 'name', prefix='\n')
                info_text += infonize(file, 'size', sizelize, prefix='\n')
                info_text += infonize(file, 'type', prefix='\n')
                info_text += infonize(file, 'positive_votes', prefix='\nPositivních hlasů: ')
                info_text += infonize(file, 'negative_votes', prefix='\nNegativních hlasů: ')
                info_text += infonize(file, 'video_quality', prefix='\n')
                info_text += infonize(file, 'video_format', prefix='\n')
                info_text += infonize(file, 'fps', fpsize, prefix='\nFps: ')
                info_text += infonize(file, 'audio_format', prefix='\n')
                info_text += infonize(file, 'audio_channels', prefix='\n')
                info_text += infonize(file, 'audio_lang', prefix='\n')
                info_text += infonize(file, 'subtitles_lang', prefix='\n')
                info_text += infonize(file, 'duration', prefix='\nDélka: ', suffix=' minut\n')

                dialog.textviewer(labelize(file), info_text)

            except Exception as e:
                logging.error(f'Error displaying file info: {str(e)}')
                popinfo('Chyba při zobrazení informací o souboru', icon=xbmcgui.NOTIFICATION_ERROR)

    except Exception as e:
        logging.error(f'Unexpected error in info: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při zobrazení informací', icon=xbmcgui.NOTIFICATION_ERROR)

def router(paramstring):
    """Main router with comprehensive error handling"""
    try:
        params = dict(parse_qsl(paramstring))
        logging.debug(f'Router called with params: {params}')

        if params:
            action = params.get('action', None)

            # OPRAVENO: Pokud action chybí ale máme 'what', předpokládej search
            if not action and 'what' in params:
                action = 'search'
                params['action'] = 'search'
                logging.info(f'Missing action parameter, defaulting to search with what="{params["what"]}"')

            # Log the action being performed
            logging.info(f'Performing action: {action}')

            # Route to appropriate function
            if action == 'series_detail' and 'series_name' not in params:
                logging.warning('series_detail called without series_name')
                xbmcplugin.endOfDirectory(_handle)
                return
            # OPRAVA: POUŽÍVAT direct_search
            elif action == 'direct_search':
                direct_search(params)
            elif action == 'search':
                search(params)
            elif action == 'search_filter':
                search_filter(params)
            elif action == 'search_category_menu':
                search_category_menu(params)
            elif action == 'search_sort_menu':
                search_sort_menu(params)
            elif action == 'queue':
                queue(params)
            elif action == 'history':
                history(params)
            elif action == 'settings':
                settings(params)
            elif action == 'info':
                info(params)
            elif action == 'play':
                play(params)
            elif action == 'download':
                download(params)
            elif action == 'db':
                db(params)
            # Series Manager actions
            elif action == 'series':
                series_menu(params)
            elif action == 'series_search':
                series_search(params)
            elif action == 'series_detail':
                series_detail(params)
            elif action == 'series_season':
                series_season(params)
            elif action == 'series_refresh':
                series_refresh(params)
            elif action is None:
                logging.debug('No action specified, showing main menu')
                menu()
            else:
                logging.warning(f'Unknown action: {action}')
                menu()
        else:
            logging.debug('No parameters, showing main menu')
            menu()

    except Exception as e:
        logging.error(f'Critical error in router: {str(e)}')
        traceback.print_exc()
        popinfo('Kritická chyba aplikace', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        # Try to show main menu as fallback
        try:
            menu()
        except:
            xbmcplugin.endOfDirectory(_handle)

# Main entry point
if __name__ == '__main__':
    try:
        logging.info('YaWSP plugin started')
        router(sys.argv[2][1:])
        logging.info('YaWSP plugin finished')
    except Exception as e:
        logging.error(f'Fatal error in main: {str(e)}')
        traceback.print_exc()
        popinfo('Fatální chyba při spouštění', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)