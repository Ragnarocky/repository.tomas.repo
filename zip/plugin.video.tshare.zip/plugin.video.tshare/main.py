# -*- coding: utf-8 -*-
# Tshare Main Entry Point with Auto-installer
# Author: Tomas for friends

import sys
import os
import io
import json
import xbmc
import xbmcvfs
import xbmcgui
import Tshare

def install_tmdb_player_config():
    """Automaticky nainstaluje TMDB Helper player konfiguraci při prvním spuštění"""
    try:
        # JSON konfigurace pro TMDB Helper
        tshare_player_config = {
            "name": "Tshare Player",
            "plugin": "plugin.video.tshare",
            "priority": 100,
            "search_movie": "plugin://plugin.video.tshare/?action=direct_search&what={showname} {year}",
            "search_episode": "plugin://plugin.video.tshare/?action=direct_search&what={showname} S{season}E{episode}",
            "assert": {
                "search_movie": ["title", "year"],
                "search_episode": ["showname", "season", "episode"]
            }
        }
        
        # Cesta k TMDB Helper players složce
        tmdb_profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper')
        tmdb_players_path = os.path.join(tmdb_profile, 'players')
        
        # Cesta k Tshare player konfiguraci
        player_config_file = os.path.join(tmdb_players_path, 'tshare_player.json')
        
        # Kontrola, jestli už konfigurace existuje
        if os.path.exists(player_config_file):
            xbmc.log('[Tshare]: TMDB Helper player config already exists', xbmc.LOGDEBUG)
            return True
        
        # Kontrola, jestli TMDB Helper existuje
        if not xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
            xbmc.log('[Tshare]: TMDB Helper not installed, skipping player config installation', xbmc.LOGDEBUG)
            return True
        
        # Vytvoř složky pokud neexistují
        if not os.path.exists(tmdb_profile):
            os.makedirs(tmdb_profile)
            xbmc.log(f'[Tshare]: Created TMDB Helper profile directory', xbmc.LOGDEBUG)
            
        if not os.path.exists(tmdb_players_path):
            os.makedirs(tmdb_players_path)
            xbmc.log(f'[Tshare]: Created players directory', xbmc.LOGDEBUG)
        
        # Zapis konfiguraci
        with io.open(player_config_file, 'w', encoding='utf-8') as f:
            json.dump(tshare_player_config, f, indent=2, ensure_ascii=False)
        
        xbmc.log('[Tshare]: TMDB Helper player configuration installed successfully', xbmc.LOGINFO)
        
        # Zobraz notifikaci uživateli (jen při prvním spuštění po instalaci)
        try:
            xbmcgui.Dialog().notification(
                'Tsahre', 
                'TMDB Helper player nainstalován',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
        except:
            pass
        
        return True
        
    except Exception as e:
        xbmc.log(f'[Tshare]: Error installing TMDB player config: {str(e)}', xbmc.LOGERROR)
        return False
    
def main():
    """Hlavní entry point"""
    try:
        # Při prvním spuštění zkus nainstalovat TMDB konfiguraci
        install_tmdb_player_config()
        # Spusť standardní Tshare router
        Tshare.router(sys.argv[2][1:])
        
    except Exception as e:
        xbmc.log(f'[Tshare]: Critical error in main: {str(e)}', xbmc.LOGERROR)
        # Zkus spustit alespoň základní Tshare
        try:
            Tshare.router(sys.argv[2][1:])
        except:
            pass

if __name__ == '__main__':
    main()