# Rychlý test pro crash debugging
# Přidej do Tshare.py pro testování - velmi přísné limity

def test_search_series_safe(series_manager, series_name, api_function, token):
    """Ultra bezpečná verze pro testování - minimální limity"""
    try:
        xbmc.log(f'SAFE TEST: Starting search for "{series_name}"', xbmc.LOGWARNING)
        
        # ULTRA PŘÍSNÉ LIMITY PRO TESTOVÁNÍ
        MAX_API_RESULTS = 50  # Max 50 výsledků z API
        MAX_PROCESSED = 25   # Max 25 zpracovaných položek  
        MAX_ACCEPTED = 15    # Max 15 přijatých epizod
        MAX_TIME = 10        # Max 10 sekund
        
        start_time = time.time()
        
        # Jen jeden jednoduchý search query
        results = series_manager._perform_search(series_name, api_function, token)
        results = results[:MAX_API_RESULTS]  # Okamžité omezení
        
        xbmc.log(f'SAFE TEST: Got {len(results)} results', xbmc.LOGWARNING)
        
        series_data = {'name': series_name, 'seasons': {}}
        processed = 0
        accepted = 0
        
        for item in results:
            # Časový check každou iteraci
            if time.time() - start_time > MAX_TIME:
                xbmc.log(f'SAFE TEST: Timeout after {processed} items', xbmc.LOGWARNING)
                break
                
            if processed >= MAX_PROCESSED:
                xbmc.log(f'SAFE TEST: Max processed reached', xbmc.LOGWARNING)
                break
                
            if accepted >= MAX_ACCEPTED:
                xbmc.log(f'SAFE TEST: Max accepted reached', xbmc.LOGWARNING)  
                break
                
            processed += 1
            
            # Progress každých 5 položek
            if processed % 5 == 0:
                elapsed = time.time() - start_time
                xbmc.log(f'SAFE TEST: Progress {processed}/{len(results)}, accepted={accepted}, time={elapsed:.1f}s', xbmc.LOGWARNING)
                import gc
                gc.collect()  # Garbage collection
                
            # Zkus detekci epizody
            season, episode = series_manager._detect_episode_info(item['name'], series_name)
            if season and episode:
                if series_manager._is_likely_episode(item['name'], series_name, season, episode):
                    accepted += 1
                    
                    # Přidej do dat
                    s_str, e_str = str(season), str(episode)
                    if s_str not in series_data['seasons']:
                        series_data['seasons'][s_str] = {}
                    if e_str not in series_data['seasons'][s_str]:
                        series_data['seasons'][s_str][e_str] = {'episodes': []}
                        
                    series_data['seasons'][s_str][e_str]['episodes'].append({
                        'name': item['name'],
                        'ident': item['ident'], 
                        'size': item.get('size', '0')
                    })
                    
                    xbmc.log(f'SAFE TEST: Added S{season}E{episode}: {item["name"][:30]}...', xbmc.LOGWARNING)
        
        elapsed = time.time() - start_time
        seasons_count = len(series_data['seasons'])
        total_eps = sum(len(season) for season in series_data['seasons'].values())
        
        xbmc.log(f'SAFE TEST: Complete - {seasons_count} seasons, {total_eps} episodes, {elapsed:.1f}s', xbmc.LOGWARNING)
        
        if total_eps > 0:
            series_manager._save_series_data(series_name, series_data)
            xbmc.log(f'SAFE TEST: Data saved successfully', xbmc.LOGWARNING)
            
        return series_data
        
    except Exception as e:
        xbmc.log(f'SAFE TEST: ERROR - {str(e)}', xbmc.LOGERROR)
        import traceback
        xbmc.log(f'SAFE TEST: Traceback - {traceback.format_exc()}', xbmc.LOGERROR)
        return None