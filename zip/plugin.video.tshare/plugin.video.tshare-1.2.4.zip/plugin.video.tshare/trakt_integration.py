# -*- coding: utf-8 -*-
# Module: trakt_integration
# Author: Tomas for friends
# Created on: 1.10.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import os
import io
import json
import time
import hashlib
import requests  # type: ignore
import threading
import xbmc  # type: ignore
import xbmcaddon  # type: ignore
import xbmcgui  # type: ignore
import xbmcvfs  # type: ignore
from datetime import datetime, timedelta

try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode

class TraktIntegration:
    """
    Integrace s Trakt.tv API pro synchronizaci sledovaného obsahu
    """
    
    def __init__(self, addon):
        self.addon = addon
        self.profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        
        # Shutdown flag pro bezpečné ukončení
        self._shutdown = False
        
        # Trakt.tv API konstanty - použij z nastavení nebo veřejné pro open-source
        user_client_id = self.addon.getSetting('trakt_client_id').strip()
        user_client_secret = self.addon.getSetting('trakt_client_secret').strip()
        
        # Pokud uživatel zadal své údaje, použij je
        if user_client_id and user_client_secret:
            self.CLIENT_ID = user_client_id
            self.CLIENT_SECRET = user_client_secret
        else:
            # Použij registrované credentials pro Tshare addon
            self.CLIENT_ID = '477e7b0c776a6010b296a53a731c90d72669dea80fc85a7beaca10fd1b878e32'
            self.CLIENT_SECRET = 'fdda8c18e74688a3773b23cdd2d0ce48b53a5389d7bb5d2b4e28b82c44fe5e39'
        self.REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'  # Out-of-band pro PIN
        self.API_BASE = 'https://api.trakt.tv'
        
        # Soubory pro ukládání dat
        self.token_file = os.path.join(self.profile_path, 'trakt_tokens.json')
        self.cache_file = os.path.join(self.profile_path, 'trakt_cache.json')
        self.sync_queue_file = os.path.join(self.profile_path, 'trakt_sync_queue.json')
        
        # Načti tokeny
        self.access_token = None
        self.refresh_token = None
        self.token_expires = None
        self.load_tokens()
        
        # Cache pro API volání
        self.cache = self.load_cache()
        
        # Fronta pro offline synchronizaci
        self.sync_queue = self.load_sync_queue()
    
    def is_enabled(self):
        """Zkontroluje, jestli je Trakt integrace povolena v nastavení"""
        return self.addon.getSetting('trakt_enabled') == 'true'
    
    def is_authenticated(self):
        """Zkontroluje, jestli je uživatel přihlášen"""
        return bool(self.access_token and not self.is_token_expired())
    
    def is_token_expired(self):
        """Zkontroluje, jestli je access token expirovaný"""
        if not self.token_expires:
            return True
        return time.time() > self.token_expires
    
    def should_refresh_token(self):
        """Zkontroluje, jestli by měl být token brzy obnoven (proaktivně)"""
        if not self.token_expires:
            return True
        # Obnov token pokud zbývá méně než 7 dní do expirace
        days_until_expiry = (self.token_expires - time.time()) / 86400
        return days_until_expiry < 7
    
    def load_tokens(self):
        """Načte access a refresh tokeny ze souboru"""
        if os.path.exists(self.token_file):
            try:
                with io.open(self.token_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.access_token = data.get('access_token')
                    self.refresh_token = data.get('refresh_token')
                    self.token_expires = data.get('expires_at')
                    last_refresh = data.get('last_refresh_time', 0)
                    if last_refresh:
                        days_ago = (time.time() - last_refresh) / 86400
                        xbmc.log(f'Trakt: Tokens loaded, last refreshed {days_ago:.1f} days ago', xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f'Trakt: Error loading tokens: {str(e)}', xbmc.LOGERROR)
    
    def save_tokens(self, access_token, refresh_token, expires_in):
        """Uloží tokeny do souboru"""
        try:
            if not os.path.exists(self.profile_path):
                os.makedirs(self.profile_path)
                
            expires_at = time.time() + expires_in - 300  # 5min buffer
            
            data = {
                'access_token': access_token,
                'refresh_token': refresh_token,
                'expires_at': expires_at,
                'last_refresh_time': time.time()
            }
            
            with io.open(self.token_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
                
            self.access_token = access_token
            self.refresh_token = refresh_token
            self.token_expires = expires_at
            
        except Exception as e:
            xbmc.log(f'Trakt: Error saving tokens: {str(e)}', xbmc.LOGERROR)
    
    def authenticate(self):
        """Spustí OAuth flow pro autentifikaci"""
        try:
            # Debug info
            xbmc.log(f'Trakt: Starting authentication with CLIENT_ID: {self.CLIENT_ID[:10]}...', xbmc.LOGINFO)
            
            # Základní kontrola CLIENT_ID
            if not self.CLIENT_ID or len(self.CLIENT_ID) < 10:
                raise Exception('Chyba v konfiguraci Trakt.tv API klíčů.')
            
            # Krok 1: Získej device code
            device_url = f'{self.API_BASE}/oauth/device/code'
            device_data = {
                'client_id': self.CLIENT_ID
            }
            
            xbmc.log(f'Trakt: Requesting device code from {device_url}', xbmc.LOGDEBUG)
            response = requests.post(device_url, json=device_data, timeout=10)
            
            xbmc.log(f'Trakt: Device code response status: {response.status_code}', xbmc.LOGDEBUG)
            
            if response.status_code != 200:
                error_text = response.text if response.text else 'Neznámá chyba'
                xbmc.log(f'Trakt: Device code error response: {error_text}', xbmc.LOGERROR)
                raise Exception(f'Device code request failed: HTTP {response.status_code} - {error_text}')
                
            device_info = response.json()
            xbmc.log(f'Trakt: Device code obtained successfully', xbmc.LOGINFO)
            
            # Zobraz dialog s instrukcemi
            dialog = xbmcgui.Dialog()
            message = (
                f'Pro přihlášení k Trakt.tv:\n\n'
                f'1. Jděte na: {device_info["verification_url"]}\n'
                f'2. Zadejte kód: [B]{device_info["user_code"]}[/B]\n'
                f'3. Stiskněte OK po dokončení'
            )
            
            if not dialog.yesno('Trakt.tv Autentifikace', message):
                return False
            
            # Krok 2: Poll pro token
            token_url = f'{self.API_BASE}/oauth/device/token'
            token_data = {
                'code': device_info['device_code'],
                'client_id': self.CLIENT_ID,
                'client_secret': self.CLIENT_SECRET
            }
            
            # Čekej až uživatel autorizuje (max 10 minut)
            interval = device_info.get('interval', 5)
            expires_in = device_info.get('expires_in', 600)
            start_time = time.time()
            
            progress = xbmcgui.DialogProgress()
            progress.create('Trakt.tv', 'Čekám na autorizaci...')
            
            while time.time() - start_time < expires_in:
                if progress.iscanceled():
                    progress.close()
                    return False
                
                try:
                    response = requests.post(token_url, json=token_data, timeout=10)
                    xbmc.log(f'Trakt: Token polling response: {response.status_code}', xbmc.LOGDEBUG)
                except requests.exceptions.RequestException as e:
                    xbmc.log(f'Trakt: Token polling network error: {str(e)}', xbmc.LOGERROR)
                    xbmc.sleep(interval * 1000)
                    continue
                
                if response.status_code == 200:
                    # Úspěch!
                    token_info = response.json()
                    self.save_tokens(
                        token_info['access_token'],
                        token_info['refresh_token'],
                        token_info['expires_in']
                    )
                    progress.close()
                    
                    # Získej user info pro potvrzení
                    user_info = self.get_user_info()
                    if user_info:
                        username = user_info.get('username', 'Unknown')
                        dialog.notification('Trakt.tv', f'Přihlášen jako {username}', xbmcgui.NOTIFICATION_INFO)
                    
                    return True
                    
                elif response.status_code == 400:
                    # Pending - pokračuj, nebo zkontroluj chybu
                    try:
                        error_data = response.json()
                        if error_data.get('error') == 'authorization_pending':
                            pass  # Normální pending stav
                        else:
                            progress.close()
                            error_msg = error_data.get('error_description', 'Neznámá chyba autorizace')
                            dialog.notification('Trakt.tv', f'Chyba: {error_msg}', xbmcgui.NOTIFICATION_ERROR)
                            return False
                    except:
                        pass  # Pokračuj i při parsing chybě
                elif response.status_code == 403:
                    # Forbidden - často problém s client credentials
                    progress.close()
                    dialog.notification('Trakt.tv', 'Chybné přihlašovací údaje (403)', xbmcgui.NOTIFICATION_ERROR)
                    xbmc.log('Trakt: 403 Forbidden - check CLIENT_ID and CLIENT_SECRET', xbmc.LOGERROR)
                    return False
                elif response.status_code == 404:
                    # Denied
                    progress.close()
                    dialog.notification('Trakt.tv', 'Autorizace zamítnuta', xbmcgui.NOTIFICATION_ERROR)
                    return False
                elif response.status_code == 410:
                    # Expired
                    progress.close()
                    dialog.notification('Trakt.tv', 'Kód expiroval', xbmcgui.NOTIFICATION_ERROR)
                    return False
                else:
                    # Jiná chyba
                    progress.close()
                    dialog.notification('Trakt.tv', f'HTTP chyba: {response.status_code}', xbmcgui.NOTIFICATION_ERROR)
                    xbmc.log(f'Trakt: Unexpected HTTP status: {response.status_code}, body: {response.text}', xbmc.LOGERROR)
                    return False
                
                # Čekej před dalším pokusem
                xbmc.sleep(interval * 1000)
                
                # Update progress
                elapsed = time.time() - start_time
                percent = int((elapsed / expires_in) * 100)
                progress.update(percent, 'Čekám na autorizaci...')
            
            progress.close()
            dialog.notification('Trakt.tv', 'Timeout při autorizaci', xbmcgui.NOTIFICATION_ERROR)
            return False
            
        except Exception as e:
            xbmc.log(f'Trakt: Authentication error: {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Trakt.tv', f'Chyba při přihlášení: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def refresh_access_token(self):
        """Obnoví access token pomocí refresh token"""
        if not self.refresh_token:
            xbmc.log('Trakt: No refresh token available, clearing auth state', xbmc.LOGWARNING)
            self._clear_auth_state()
            return False
            
        try:
            url = f'{self.API_BASE}/oauth/token'
            data = {
                'refresh_token': self.refresh_token,
                'client_id': self.CLIENT_ID,
                'client_secret': self.CLIENT_SECRET,
                'grant_type': 'refresh_token'
            }
            
            response = requests.post(url, json=data, timeout=10)
            
            if response.status_code == 200:
                token_info = response.json()
                self.save_tokens(
                    token_info['access_token'],
                    token_info['refresh_token'],
                    token_info['expires_in']
                )
                expires_in_days = token_info['expires_in'] / 86400
                xbmc.log(f'Trakt: Access token successfully refreshed, valid for {expires_in_days:.1f} days', xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f'Trakt: Token refresh failed: {response.status_code} - {response.text}', xbmc.LOGERROR)
                # Neplatný refresh token - smaž autentizaci
                self._clear_auth_state()
                return False
                
        except requests.exceptions.ConnectionError as e:
            xbmc.log(f'Trakt: Connection error during token refresh (server unreachable): {str(e)}', xbmc.LOGWARNING)
            # Síťová chyba - NESMAŽ tokeny, možná to příště projde
            return False
        except requests.exceptions.Timeout as e:
            xbmc.log(f'Trakt: Timeout during token refresh: {str(e)}', xbmc.LOGWARNING)
            # Timeout - NESMAŽ tokeny
            return False
        except requests.exceptions.RequestException as e:
            xbmc.log(f'Trakt: Request error during token refresh: {str(e)}', xbmc.LOGWARNING)
            # Síťová chyba - NESMAŽ tokeny
            return False
        except Exception as e:
            xbmc.log(f'Trakt: Unexpected error during token refresh: {str(e)}', xbmc.LOGERROR)
            # Síťová chyba - NESMAŽ tokeny, možná to příště projde
            return False
    
    def api_request(self, endpoint, method='GET', data=None, use_cache=True, cache_timeout=3600):
        """Provede API požadavek na Trakt.tv"""
        if not self.is_enabled() or self._shutdown:
            return None
            
        # Zkontroluj a obnov token PROAKTIVNĚ (před expiraci)
        if self.is_token_expired():
            xbmc.log('Trakt: Token expired, refreshing...', xbmc.LOGDEBUG)
            if not self.refresh_access_token():
                return None
        elif self.should_refresh_token():
            xbmc.log('Trakt: Token expiring soon, proactively refreshing...', xbmc.LOGDEBUG)
            # Proaktivní refresh - pokud selže, pokračuj se starým tokenem
            self.refresh_access_token()
        
        # Cache klíč
        cache_key = None
        if use_cache and method == 'GET':
            cache_key = hashlib.md5(f'{endpoint}_{str(data)}'.encode()).hexdigest()
            cached = self.cache.get(cache_key)
            if cached and time.time() - cached['timestamp'] < cache_timeout:
                return cached['data']
        
        try:
            url = f'{self.API_BASE}{endpoint}'
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'trakt-api-version': '2',
                'trakt-api-key': self.CLIENT_ID,
                'Content-Type': 'application/json'
            }
            
            if method == 'GET':
                response = requests.get(url, headers=headers, params=data, timeout=10)
            else:
                response = requests.request(method, url, headers=headers, json=data, timeout=10)
            
            # OPRAVENO: Akceptuj 200 (OK) i 201 (Created) i 204 (No Content)
            if response.status_code in [200, 201, 204]:
                result = response.json() if response.content else None
                
                # Debug log pro scrobbling
                if '/scrobble/' in endpoint:
                    xbmc.log(f'Trakt scrobble response [{response.status_code}]: {response.text[:200]}', xbmc.LOGINFO)
                
                # Ulož do cache
                if cache_key and result:
                    self.cache[cache_key] = {
                        'data': result,
                        'timestamp': time.time()
                    }
                    self.save_cache()
                
                return result
            elif response.status_code == 401:
                # Token expired, zkus refresh
                xbmc.log('Trakt: Received 401, attempting token refresh', xbmc.LOGDEBUG)
                if self.refresh_access_token():
                    # Rekurzivní volání s novým tokenem
                    return self.api_request(endpoint, method, data, use_cache, cache_timeout)
                else:
                    xbmc.log('Trakt: Token refresh failed, user needs to re-authenticate', xbmc.LOGWARNING)
                    # Tokeny už jsou smazané v refresh_access_token(), jen vrať None
                    return None
            else:
                xbmc.log(f'Trakt API error {response.status_code}: {response.text}', xbmc.LOGERROR)
                return None
                
        except requests.exceptions.ConnectionError as e:
            xbmc.log(f'Trakt: Connection error (server unreachable): {str(e)}', xbmc.LOGWARNING)
            return None
        except requests.exceptions.Timeout as e:
            xbmc.log(f'Trakt: Request timeout: {str(e)}', xbmc.LOGWARNING)
            return None
        except requests.exceptions.RequestException as e:
            xbmc.log(f'Trakt: Request error: {str(e)}', xbmc.LOGWARNING)
            return None
        except Exception as e:
            xbmc.log(f'Trakt: Unexpected error in API request: {str(e)}', xbmc.LOGERROR)
            return None
    
    def get_user_info(self):
        """Získá informace o přihlášeném uživateli"""
        return self.api_request('/users/me')
    
    def scrobble_start(self, tmdb_id, media_type, progress=0.0, season=None, episode=None):
        """Začne sledování (scrobbling)"""
        if not self.is_authenticated():
            xbmc.log('Trakt scrobble_start: Not authenticated', xbmc.LOGWARNING)
            return False
            
        # Připrav data podle typu obsahu
        if media_type == 'movie':
            ids = {'tmdb': int(tmdb_id)}
            data = {
                'movie': {
                    'ids': ids
                },
                'progress': progress
            }
            xbmc.log(f'Trakt scrobble_start: Movie TMDB {tmdb_id}, progress {progress}%', xbmc.LOGINFO)
        elif media_type == 'tv' or media_type == 'episode':
            ids = {'tmdb': int(tmdb_id)}
            data = {
                'show': {
                    'ids': ids
                },
                'episode': {
                    'season': int(season) if season else 1,
                    'number': int(episode) if episode else 1
                },
                'progress': progress
            }
            xbmc.log(f'Trakt scrobble_start: TV TMDB {tmdb_id}, S{season}E{episode}, progress {progress}%', xbmc.LOGINFO)
        else:
            return False
        
        result = self.api_request('/scrobble/start', method='POST', data=data, use_cache=False)
        if result:
            xbmc.log(f'Trakt scrobble_start: SUCCESS - {str(result)[:200]}', xbmc.LOGINFO)
        else:
            xbmc.log('Trakt scrobble_start: FAILED - no result', xbmc.LOGWARNING)
        return result is not None
    
    def scrobble_pause(self, tmdb_id, media_type, progress, season=None, episode=None):
        """Pozastaví sledování"""
        if not self.is_authenticated():
            return False
            
        # Podobné jako scrobble_start
        if media_type == 'movie':
            data = {
                'movie': {'ids': {'tmdb': int(tmdb_id)}},
                'progress': progress
            }
        else:
            data = {
                'show': {'ids': {'tmdb': int(tmdb_id)}},
                'episode': {
                    'season': int(season) if season else 1,
                    'number': int(episode) if episode else 1
                },
                'progress': progress
            }
        
        result = self.api_request('/scrobble/pause', method='POST', data=data, use_cache=False)
        return result is not None
    
    def scrobble_stop(self, tmdb_id, media_type, progress, season=None, episode=None):
        """Ukončí sledování a označí jako zhlédnuto (při >80% progress)"""
        if not self.is_authenticated():
            # Přidej do offline fronty
            self.add_to_sync_queue('scrobble_stop', {
                'tmdb_id': tmdb_id,
                'media_type': media_type,
                'progress': progress,
                'season': season,
                'episode': episode,
                'timestamp': time.time()
            })
            xbmc.log('Trakt scrobble_stop: Not authenticated, added to offline queue', xbmc.LOGWARNING)
            return False
            
        if media_type == 'movie':
            data = {
                'movie': {'ids': {'tmdb': int(tmdb_id)}},
                'progress': progress
            }
            xbmc.log(f'Trakt scrobble_stop: Movie TMDB {tmdb_id}, progress {progress}%', xbmc.LOGINFO)
        else:
            data = {
                'show': {'ids': {'tmdb': int(tmdb_id)}},
                'episode': {
                    'season': int(season) if season else 1,
                    'number': int(episode) if episode else 1
                },
                'progress': progress
            }
            xbmc.log(f'Trakt scrobble_stop: TV TMDB {tmdb_id}, S{season}E{episode}, progress {progress}%', xbmc.LOGINFO)
        
        result = self.api_request('/scrobble/stop', method='POST', data=data, use_cache=False)
        if result:
            xbmc.log(f'Trakt scrobble_stop: SUCCESS - {str(result)[:200]}', xbmc.LOGINFO)
        else:
            xbmc.log('Trakt scrobble_stop: FAILED - no result', xbmc.LOGWARNING)
        return result is not None
    
    def add_to_watchlist(self, tmdb_id, media_type):
        """Přidá do watchlistu"""
        if not self.is_authenticated():
            self.add_to_sync_queue('add_watchlist', {
                'tmdb_id': tmdb_id,
                'media_type': media_type,
                'timestamp': time.time()
            })
            return False
            
        if media_type == 'movie':
            data = {
                'movies': [{'ids': {'tmdb': int(tmdb_id)}}]
            }
        else:
            data = {
                'shows': [{'ids': {'tmdb': int(tmdb_id)}}]
            }
        
        result = self.api_request('/sync/watchlist', method='POST', data=data, use_cache=False)
        return result is not None
    
    def remove_from_watchlist(self, tmdb_id, media_type):
        """Odebere z watchlistu"""
        if not self.is_authenticated():
            return False
            
        if media_type == 'movie':
            data = {
                'movies': [{'ids': {'tmdb': int(tmdb_id)}}]
            }
        else:
            data = {
                'shows': [{'ids': {'tmdb': int(tmdb_id)}}]
            }
        
        result = self.api_request('/sync/watchlist/remove', method='POST', data=data, use_cache=False)
        return result is not None
    
    def get_watchlist(self, media_type='all'):
        """Získá watchlist uživatele"""
        endpoint = '/sync/watchlist'
        if media_type == 'movies':
            endpoint += '/movies'
        elif media_type == 'shows':
            endpoint += '/shows'
            
        return self.api_request(endpoint, cache_timeout=1800)  # Cache 30min
    
    def get_watched_movies(self):
        """Získá seznam zhlédnutých filmů"""
        return self.api_request('/sync/watched/movies', cache_timeout=3600)  # Cache 1h
    
    def get_watched_shows(self):
        """Získá seznam zhlédnutých seriálů"""
        return self.api_request('/sync/watched/shows', cache_timeout=3600)  # Cache 1h
    
    def get_show_progress(self, tmdb_id):
        """Získá pokrok v seriálu"""
        return self.api_request(f'/shows/{tmdb_id}/progress/watched', cache_timeout=1800)
    
    def sync_collection(self, items, media_type, action='add'):
        """Synchronizuje kolekci"""
        if not self.is_authenticated():
            return False
            
        endpoint = '/sync/collection'
        if action == 'remove':
            endpoint += '/remove'
            
        data = {f'{media_type}s': items}
        result = self.api_request(endpoint, method='POST', data=data, use_cache=False)
        return result is not None
    
    def load_cache(self):
        """Načte cache ze souboru"""
        if os.path.exists(self.cache_file):
            try:
                with io.open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {}
    
    def save_cache(self):
        """Uloží cache do souboru"""
        try:
            # Vyčisti staré záznamy (starší než 24h)
            now = time.time()
            clean_cache = {}
            for key, value in self.cache.items():
                if now - value.get('timestamp', 0) < 86400:  # 24h
                    clean_cache[key] = value
            
            with io.open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(clean_cache, f, indent=2)
                
            self.cache = clean_cache
        except Exception as e:
            xbmc.log(f'Trakt: Error saving cache: {str(e)}', xbmc.LOGERROR)
    
    def add_to_sync_queue(self, action, data):
        """Přidá akci do fronty pro offline sync"""
        self.sync_queue.append({
            'action': action,
            'data': data,
            'timestamp': time.time()
        })
        self.save_sync_queue()
    
    def load_sync_queue(self):
        """Načte sync frontu"""
        if os.path.exists(self.sync_queue_file):
            try:
                with io.open(self.sync_queue_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return []
    
    def save_sync_queue(self):
        """Uloží sync frontu"""
        try:
            with io.open(self.sync_queue_file, 'w', encoding='utf-8') as f:
                json.dump(self.sync_queue, f, indent=2)
        except Exception as e:
            xbmc.log(f'Trakt: Error saving sync queue: {str(e)}', xbmc.LOGERROR)
    
    def process_sync_queue(self):
        """Zpracuje offline sync frontu"""
        if not self.is_authenticated() or not self.sync_queue:
            return
            
        processed = []
        for i, item in enumerate(self.sync_queue):
            action = item['action']
            data = item['data']
            
            success = False
            if action == 'scrobble_stop':
                success = self.scrobble_stop(
                    data['tmdb_id'], data['media_type'], data['progress'],
                    data.get('season'), data.get('episode')
                )
            elif action == 'add_watchlist':
                success = self.add_to_watchlist(data['tmdb_id'], data['media_type'])
            
            if success:
                processed.append(i)
        
        # Odstraň zpracované položky
        for i in reversed(processed):
            del self.sync_queue[i]
        
        if processed:
            self.save_sync_queue()
            xbmc.log(f'Trakt: Processed {len(processed)} offline sync items', xbmc.LOGINFO)
    
    def _clear_auth_state(self):
        """Interní metoda pro smazání neplatné autentizace bez notifikace"""
        try:
            # Smaž tokeny ze souboru
            if os.path.exists(self.token_file):
                os.remove(self.token_file)
                xbmc.log('Trakt: Removed invalid token file', xbmc.LOGINFO)
            
            # Vynuluj in-memory tokeny
            self.access_token = None
            self.refresh_token = None
            self.token_expires = None
            
        except Exception as e:
            xbmc.log(f'Trakt: Error clearing auth state: {str(e)}', xbmc.LOGERROR)
    
    def logout(self):
        """Odhlásí uživatele"""
        try:
            # Revoke token na serveru
            if self.access_token:
                try:
                    self.api_request('/oauth/revoke', method='POST', 
                                   data={'token': self.access_token}, use_cache=False)
                except:
                    pass  # Pokud revoke selže, stejně pokračuj s lokálním smazáním
            
            # Smaž lokální autentizaci
            self._clear_auth_state()
            
            xbmcgui.Dialog().notification('Trakt.tv', 'Úspěšně odhlášen', xbmcgui.NOTIFICATION_INFO)
            
        except Exception as e:
            xbmc.log(f'Trakt: Logout error: {str(e)}', xbmc.LOGERROR)
    
    def shutdown(self):
        """Bezpečné ukončení při vypínání Kodi"""
        xbmc.log('Trakt: Shutting down gracefully', xbmc.LOGINFO)
        self._shutdown = True
        # Uložit všechny pending data
        try:
            self.save_cache()
            self.save_sync_queue()
        except Exception as e:
            xbmc.log(f'Trakt: Error during shutdown: {str(e)}', xbmc.LOGWARNING)


# Globální instance pro použití v ostatních modulech
trakt = None

def get_trakt_instance(addon):
    """Získá globální instanci Trakt integrace"""
    global trakt
    if trakt is None:
        trakt = TraktIntegration(addon)
    return trakt

def shutdown_trakt():
    """Bezpečně vypne Trakt integraci"""
    global trakt
    if trakt is not None:
        trakt.shutdown()