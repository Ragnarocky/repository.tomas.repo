# -*- coding: utf-8 -*-
"""
Inteligentní učící se systém pro detekci epizod
Automaticky se učí vzory na základě úspěšných rozpoznání
"""

import json
import re
import os
import xbmc  # type: ignore
import unidecode  # type: ignore

class PatternLearner:
    def __init__(self, profile_path):
        self.profile_path = profile_path
        self.patterns_file = os.path.join(profile_path, 'learned_patterns.json')
        self.learned_patterns = self._load_patterns()
        
    def _load_patterns(self):
        """Načte naučené vzory ze souboru"""
        try:
            if os.path.exists(self.patterns_file):
                with open(self.patterns_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při načítání vzorů: {e}", xbmc.LOGWARNING)
        
        return {
            'series_patterns': {},      # Vzory pro konkrétní seriály
            'general_patterns': [],     # Obecné vzory
            'success_count': {},        # Počet úspěšných použití
            'last_updated': None
        }
    
    def _save_patterns(self):
        """Uloží naučené vzory do souboru"""
        try:
            import time
            self.learned_patterns['last_updated'] = int(time.time())
            
            with open(self.patterns_file, 'w', encoding='utf-8') as f:
                json.dump(self.learned_patterns, f, indent=2, ensure_ascii=False)
                
            xbmc.log(f"PatternLearner: Vzory uloženy ({len(self.learned_patterns.get('general_patterns', []))} obecných)", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při ukládání vzorů: {e}", xbmc.LOGWARNING)
    
    def _standardize_name(self, name):
        """Odstraní speciální znaky a sjednotí mezery na jednu"""
        import re
        n = unidecode.unidecode(name or '').lower()
        n = re.sub(r'[^a-z0-9 ]+', ' ', n)
        n = re.sub(r'\s+', ' ', n).strip()
        return n

    def learn_pattern(self, filename, season, episode, series_name=None, pattern=None):
        """
        Naučí se vzor z úspěšně rozpoznanego souboru
        
        Args:
            filename: Název souboru
            season: Rozpoznaná sezóna
            episode: Rozpoznaná epizoda  
            series_name: Název seriálu (volitelné)
            pattern: Předaný vzor (volitelné)
        """
        try:
            cleaned = self._standardize_name(filename)
            
            if pattern:
                # Ulož obecný vzor do general_patterns
                entry = {
                    "pattern": pattern,
                    "confidence": 90,
                    "learned_from": filename,
                    "season": season,
                    "episode": episode,
                    "series": series_name or ""
                }
                # Zabránit duplicitám
                if entry not in self.learned_patterns["general_patterns"]:
                    self.learned_patterns["general_patterns"].append(entry)
                    self._save_patterns()
                return
            
            # Vytvoř vzor z názvu souboru
            pattern_candidates = self._extract_patterns(cleaned, season, episode)
            
            for pattern_info in pattern_candidates:
                pattern = pattern_info['pattern']
                confidence = pattern_info['confidence']
                
                # Přidej do obecných vzorů
                if pattern not in [p['pattern'] for p in self.learned_patterns['general_patterns']]:
                    self.learned_patterns['general_patterns'].append({
                        'pattern': pattern,
                        'confidence': confidence,
                        'learned_from': filename,
                        'season': season,
                        'episode': episode,
                        'series': series_name
                    })
                    
                    xbmc.log(f"PatternLearner: Naučen nový vzor '{pattern}' z '{filename}' → S{season:02d}E{episode:02d}", xbmc.LOGINFO)
                
                # Zvyš počítadlo úspěšnosti
                self.learned_patterns['success_count'][pattern] = self.learned_patterns['success_count'].get(pattern, 0) + 1
            
            # Přidej specifický vzor pro seriál
            if series_name:
                if series_name not in self.learned_patterns['series_patterns']:
                    self.learned_patterns['series_patterns'][series_name] = []
                
                series_pattern = self._create_series_pattern(filename, series_name, season, episode)
                if series_pattern:
                    self.learned_patterns['series_patterns'][series_name].append(series_pattern)
            
            self._save_patterns()
            
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při učení vzoru: {e}", xbmc.LOGERROR)
    
    def _extract_patterns(self, cleaned_filename, season, episode):
        """Extrahuje možné vzory z názvu souboru"""
        patterns = []
        
        # Hledej různé způsoby, jak se season/episode objevují v názvu
        
        # 1. Římské číslice + závorky: velkolepe-stoleti-iii-(43) nebo III-(43)
        roman_match = re.search(rf'-([ivxlcIVXLC]+)-\(({episode})\)', cleaned_filename)
        if roman_match:
            patterns.append({
                'pattern': r'-([ivxlcIVXLC]+)-\((\d+)\)',
                'confidence': 98  # Vyšší priorita pro přesný formát
            })
        
        # 1a. Římské číslice přímo se závorkami: velkolepe-stoleti-iii(43)  
        roman_direct_match = re.search(rf'-([ivxlcIVXLC]+)\(({episode})\)', cleaned_filename)
        if roman_direct_match:
            patterns.append({
                'pattern': r'-([ivxlcIVXLC]+)\((\d+)\)',
                'confidence': 95
            })

        # 1b. Římské číslice + mezera + číslo: velkolepe-stoleti-iii 43 nebo iii   43
        roman_space_match = re.search(rf'([ivxlc]+)\s{{1,5}}({episode})', cleaned_filename)
        if roman_space_match:
            patterns.append({
                'pattern': r'([ivxlc]+)\s{1,5}(\d+)',
                'confidence': 93
            })

        # 2. Římské číslice + pomlčka + závorky: -iii-(43) 
        roman_dash_match = re.search(rf'-([ivxlc]+)-\(({episode})\)', cleaned_filename)
        if roman_dash_match:
            patterns.append({
                'pattern': r'-([ivxlc]+)-\((\d+)\)',
                'confidence': 90
            })

        # 3. Podtržítka: _iii_(43) nebo _iii_43
        underscore_match = re.search(rf'_([ivxlc]+)_\(?({episode})\)?', cleaned_filename)
        if underscore_match:
            patterns.append({
                'pattern': r'_([ivxlc]+)_\(?(\d+)\)?',
                'confidence': 85
            })

        # 4. Římské číslice + pomlčka + číslo (bez závorek): velkolepe-stoleti-iii-43
        roman_direct_match = re.search(rf'-([ivxlc]+)-({episode})(?:-|$)', cleaned_filename)
        if roman_direct_match:
            patterns.append({
                'pattern': r'-([ivxlc]+)-(\d+)(?:-|$)',
                'confidence': 80
            })

        # 5. E-formát (jako E53): velkolepe.stoleti.E53.cz.avi
        if re.search(rf'[.\s_-]e{episode}[.\s_-]', cleaned_filename, re.IGNORECASE):
            patterns.append({
                'pattern': r'[.\s_-]e(\d+)[.\s_-]',
                'confidence': 85
            })
        
        # 5b. E-formát na konci: series.E53.avi
        if re.search(rf'\.e{episode}(?:\.|$)', cleaned_filename, re.IGNORECASE):
            patterns.append({
                'pattern': r'\.e(\d+)(?:\.|$)',
                'confidence': 80
            })

        # 6. Klasické formáty
        if re.search(rf's0?{season}e0?{episode}', cleaned_filename):
            patterns.append({
                'pattern': r's(\d+)e(\d+)',
                'confidence': 100
            })

        if re.search(rf'{season}x0?{episode}', cleaned_filename):
            patterns.append({
                'pattern': r'(\d+)x(\d+)',
                'confidence': 95
            })
        
        return patterns
    
    def _create_series_pattern(self, filename, series_name, season, episode):
        """Vytvoří specifický vzor pro seriál"""
        try:
            # Normalizuj název seriálu a souboru
            clean_series = self._standardize_name(series_name)
            clean_filename = self._standardize_name(filename)
            
            # Najdi společné části
            series_words = re.findall(r'\w+', clean_series)
            
            # Vytvoř vzor specifický pro tento seriál
            if len(series_words) >= 2:
                base_pattern = '.*'.join(series_words[:2])  # První dvě slova
                
                return {
                    'base_pattern': base_pattern,
                    'season': season,
                    'episode': episode,
                    'full_filename': filename,
                    'confidence': 80
                }
        except Exception:
            pass
        
        return None
    
    def detect_episode(self, filename):
        """
        Pokusí se rozpoznat epizodu pomocí naučených vzorů
        
        Returns:
            (season, episode) nebo (None, None)
        """
        try:
            cleaned = self._standardize_name(filename)
            
            # Rozšířená mapa římských číslic (do 50) - včetně velkých písmen
            roman_to_arabic = {
                # Malá písmena
                'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5,
                'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10,
                'xi': 11, 'xii': 12, 'xiii': 13, 'xiv': 14, 'xv': 15,
                'xvi': 16, 'xvii': 17, 'xviii': 18, 'xix': 19, 'xx': 20,
                'xxi': 21, 'xxii': 22, 'xxiii': 23, 'xxiv': 24, 'xxv': 25,
                'xxvi': 26, 'xxvii': 27, 'xxviii': 28, 'xxix': 29, 'xxx': 30,
                'xxxi': 31, 'xxxii': 32, 'xxxiii': 33, 'xxxiv': 34, 'xxxv': 35,
                'xxxvi': 36, 'xxxvii': 37, 'xxxviii': 38, 'xxxix': 39, 'xl': 40,
                'xli': 41, 'xlii': 42, 'xliii': 43, 'xliv': 44, 'xlv': 45,
                'xlvi': 46, 'xlvii': 47, 'xlviii': 48, 'xlix': 49, 'l': 50,
                # Velká písmena  
                'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5,
                'VI': 6, 'VII': 7, 'VIII': 8, 'IX': 9, 'X': 10,
                'XI': 11, 'XII': 12, 'XIII': 13, 'XIV': 14, 'XV': 15,
                'XVI': 16, 'XVII': 17, 'XVIII': 18, 'XIX': 19, 'XX': 20,
                'XXI': 21, 'XXII': 22, 'XXIII': 23, 'XXIV': 24, 'XXV': 25,
                'XXVI': 26, 'XXVII': 27, 'XXVIII': 28, 'XXIX': 29, 'XXX': 30,
                'XXXI': 31, 'XXXII': 32, 'XXXIII': 33, 'XXXIV': 34, 'XXXV': 35,
                'XXXVI': 36, 'XXXVII': 37, 'XXXVIII': 38, 'XXXIX': 39, 'XL': 40,
                'XLI': 41, 'XLII': 42, 'XLIII': 43, 'XLIV': 44, 'XLV': 45,
                'XLVI': 46, 'XLVII': 47, 'XLVIII': 48, 'XLIX': 49, 'L': 50
            }

            # NEJDŘÍVE: Zkus naučené vzory (seřazené podle úspěšnosti) - VYŠŠÍ PRIORITA
            general_patterns = sorted(
                self.learned_patterns.get('general_patterns', []),
                key=lambda p: self.learned_patterns['success_count'].get(p['pattern'], 0),
                reverse=True
            )
            
            for pattern_info in general_patterns:
                pattern = pattern_info['pattern']
                match = re.search(pattern, cleaned)
                
                if match and len(match.groups()) == 2:
                    try:
                        season_str = match.group(1).lower()
                        episode_str = match.group(2)
                        
                        # Převeď římské číslice (do 50)
                        if season_str in roman_to_arabic:
                            season = roman_to_arabic[season_str]
                        else:
                            season = int(season_str)
                        
                        episode = int(episode_str)
                        
                        if 1 <= season <= 50 and 1 <= episode <= 150:  # Rozšířený limit pro dlouhé seriály
                            # Zvyš počítadlo úspěšnosti
                            self.learned_patterns['success_count'][pattern] = self.learned_patterns['success_count'].get(pattern, 0) + 1
                            self._save_patterns()
                            
                            xbmc.log(f"PatternLearner: Použit naučený vzor '{pattern}' → S{season:02d}E{episode:02d} pro '{filename}'", xbmc.LOGINFO)
                            return season, episode
                            
                    except (ValueError, KeyError):
                        continue
                        
            # FALLBACK: E-formáty jako poslední možnost (když naučené vzory selžou)
            e_patterns = [
                (r'[.\s_-]e(\d+)[.\s_-]', 'E-format with separators'),
                (r'\.e(\d+)(?:\.|$)', 'E-format at end'),
                (r'^(.+)\.e(\d+)', 'E-format before extension'),
                (r'e(\d+)\.', 'Simple E-format'),
                (r'e(\d+)(?:\D|$)', 'E-format followed by non-digit or end'),
                # UNIVERZÁLNÍ patterny pro různé formáty souborů
                (r'-(\d+)\.(?:avi|mkv|mp4|divx)', 'Dash-number before extension'),
                (r'\.(\d+)\.(?:avi|mkv|mp4|divx)', 'Dot-number before extension'),
                (r'-\((\d+)\)\.(?:avi|mkv|mp4|divx)', 'Dash-parentheses-number before extension'),
                (r'[a-z]+-\((\d+)\)\.(?:avi|mkv|mp4|divx)', 'Letters-dash-parentheses-number before extension'),
                (r'\((\d+)\)\.(?:avi|mkv|mp4|divx)', 'Parentheses-number before extension'),
                (r'[.\s_-](\d+)\.(?:avi|mkv|mp4|divx)$', 'Any separator followed by number before extension'),
            ]
            
            for pattern, desc in e_patterns:
                match = re.search(pattern, cleaned, re.IGNORECASE)
                if match:
                    try:
                        episode = int(match.group(1))
                        if 1 <= episode <= 150:
                            # Určení sezóny podle kontextu (E1-24=S1, E25-48=S2, atd.)
                            season = ((episode - 1) // 24) + 1
                            if season > 10:  # Rozumný limit
                                season = 1
                            
                            xbmc.log(f"PatternLearner: FALLBACK {desc} rozpoznal E{episode} → S{season:02d}E{episode:02d} pro '{filename}'", xbmc.LOGINFO)
                            return season, episode
                    except (ValueError, IndexError):
                        continue
            
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při detekci: {e}", xbmc.LOGWARNING)
        
        return None, None
    
    def get_statistics(self):
        """Vrátí statistiky naučených vzorů"""
        general_count = len(self.learned_patterns.get('general_patterns', []))
        series_count = len(self.learned_patterns.get('series_patterns', {}))
        success_total = sum(self.learned_patterns.get('success_count', {}).values())
        
        return {
            'general_patterns': general_count,
            'series_patterns': series_count,  
            'total_successes': success_total,
            'last_updated': self.learned_patterns.get('last_updated')
        }