# -*- coding: utf-8 -*-
"""
Specializované filmové vyhledávání pro Tshare plugin
"""

import logging
import re
import xbmc  # type: ignore
import xbmcgui  # type: ignore
import xbmcplugin  # type: ignore
from xml.etree import ElementTree as ET

# VYLEPŠENÉ vzory pro filmy (rozlišení od seriálů)
MOVIE_INDICATORS = [
    r'\b(19|20)\d{2}\b',  # Rok vydání
    r'\b(dvdrip|brrip|webrip|hdtv|bluray|web-dl)\b',  # Formáty typické pro filmy
    r'\b(cam|ts|dvdscr|r5|r6)\b',  # Kvalita typická pro filmy
]

SERIES_EXCLUSION_PATTERNS = [
    r's\d+e\d+',           # S01E01
    r's\d+\s*e\d+',       # S01 E01
    r'\d+x\d+',           # 1x01  
    r'\d+\.\s*d[íi]l',    # 01. díl
    r'-\s*\d+\.\s*d[íi]l', # - 01. díl
    r'[Ee]pisode\s*\d+',   # Episode 1
    r'[Ee]p\s*\d+',       # Ep 1
]

def is_movie_result(filename):
    """Rozhodni, jestli je výsledek film nebo seriál"""
    if not filename:
        return True  # Default k filmu
        
    name_lower = filename.lower()
    
    # Pokud obsahuje vzory seriálů, není to film
    for pattern in SERIES_EXCLUSION_PATTERNS:
        if re.search(pattern, name_lower):
            try:
                xbmc.log(f'Movie filter: "{filename}" excluded as series (pattern: {pattern})', xbmc.LOGDEBUG)
            except:
                pass  # Ignoruj Unicode chyby
            return False
            
    # Pokud obsahuje vzory filmů, je to film
    for pattern in MOVIE_INDICATORS:
        if re.search(pattern, name_lower):
            try:
                xbmc.log(f'Movie filter: "{filename}" confirmed as movie (pattern: {pattern})', xbmc.LOGDEBUG)
            except:
                pass  # Ignoruj Unicode chyby
            return True
            
    # Default: pokud není jasné, považuj za film
    return True

def search_movie(token, what, category, sort, limit, offset, tmdb_id=None, cz_title=None, original_title=None, year=None):
    """Specializované vyhledávání filmů s DVOUSTUPŇOVÝM vyhledáváním CZ -> originaltitle"""
    logging.info(f'=== MOVIE SEARCH: "{what}" ===')
    
    # Import hlavních funkcí
    import Tshare
    
    try:
        # KROK 1: Hledání podle českého názvu (cz_title nebo what)
        cz_query = cz_title or what
        if year and year not in cz_query:
            cz_query = f"{cz_query} {year}"
            
        logging.info(f'Movie search - KROK 1 (CZ): "{cz_query}"')
        
        cz_results = {}
        original_results = {}
        
        # API volání pro český název
        Tshare.popinfo(f'Hledám film (CZ): {cz_title or what}', icon=xbmcgui.NOTIFICATION_INFO)
        response = Tshare.api('search', {
            'what': cz_query,
            'category': category,
            'sort': sort,
            'limit': limit,
            'offset': offset,
            'wst': token,
            'maybe_removed': 'true'
        })

        if response is not None:
            try:
                xml = ET.fromstring(response.content)
                if Tshare.is_ok(xml):
                    for file in xml.iter('file'):
                        try:
                            item = Tshare.todict(file)
                            filename = item.get('name', '')
                            
                            # FILTRUJ pouze filmy (ne seriály)
                            if not is_movie_result(filename):
                                continue
                            
                            # SJEDNOCENÍ: Přidej název filtraci jako v dosearch
                            if not Tshare.is_relevant_result(filename, cz_query, 'tmdb_czech'):
                                logging.debug(f'CZ movie filter: Skipping irrelevant result: {filename} for query: {cz_query}')
                                continue
                                
                            if 'ident' in item:
                                cz_results[item['ident']] = item
                                
                        except Exception as e:
                            logging.error(f'CZ search item error: {e}')
                            continue
                            
            except ET.ParseError as e:
                logging.error(f'CZ search XML parse error: {e}')
        
        # KROK 2: Pokud méně než 20 výsledků a máme original_title, hledej i podle něj
        if len(cz_results) < 20 and original_title and original_title != (cz_title or what):
            original_query = original_title
            if year and year not in original_query:
                original_query = f"{original_title} {year}"
                
            logging.info(f'Movie search - KROK 2 (Original): "{original_query}" (CZ našlo {len(cz_results)} výsledků)')
            
            # API volání pro originální název
            Tshare.popinfo(f'Hledám film (Original): {original_title}', icon=xbmcgui.NOTIFICATION_INFO)
            response = Tshare.api('search', {
                'what': original_query,
                'category': category,
                'sort': sort,
                'limit': limit,
                'offset': offset,
                'wst': token,
                'maybe_removed': 'true'
            })

            if response is not None:
                try:
                    xml = ET.fromstring(response.content)
                    if Tshare.is_ok(xml):
                        for file in xml.iter('file'):
                            try:
                                item = Tshare.todict(file)
                                filename = item.get('name', '')
                                
                                # FILTRUJ pouze filmy (ne seriály)
                                if not is_movie_result(filename):
                                    continue
                                
                                # SJEDNOCENÍ: Přidej název filtraci jako v dosearch
                                if not Tshare.is_relevant_result(filename, original_query, 'tmdb_original'):
                                    logging.debug(f'Original movie filter: Skipping irrelevant result: {filename} for query: {original_query}')
                                    continue
                                    
                                if 'ident' in item and item['ident'] not in cz_results:  # Nedup
                                    original_results[item['ident']] = item
                                    
                            except Exception as e:
                                logging.error(f'Original search item error: {e}')
                                continue
                                
                except ET.ParseError as e:
                    logging.error(f'Original search XML parse error: {e}')
        
        # KROK 3: Finální řazení a zobrazení - NEJDŘÍVE CZ, PAK ORIGINAL
        if cz_results:
            sorted_cz = Tshare.intelligent_sort_files(cz_results, search_year=year)
            logging.info(f'Zobrazuji {len(sorted_cz)} CZ výsledků')
            
            for ident, item in sorted_cz.items():
                try:
                    listitem = Tshare.tolistitem(item, tmdb_id=tmdb_id, media_type='movie')
                    
                    url_params = {
                        'action': 'play',
                        'ident': ident,
                        'name': item.get('name', ''),
                        'tmdb_id': tmdb_id,
                        'cz_title': cz_title,
                        'year': year
                    }
                    
                    url = Tshare.get_url(**url_params)
                    xbmcplugin.addDirectoryItem(Tshare._handle, url, listitem, False)
                    
                except Exception as e:
                    logging.error(f'CZ movie display error: {e}')
                    continue
        
        if original_results:
            sorted_original = Tshare.intelligent_sort_files(original_results, search_year=year)
            logging.info(f'Zobrazuji {len(sorted_original)} originálních výsledků')
            
            for ident, item in sorted_original.items():
                try:
                    listitem = Tshare.tolistitem(item, tmdb_id=tmdb_id, media_type='movie')
                    
                    url_params = {
                        'action': 'play',
                        'ident': ident,
                        'name': item.get('name', ''),
                        'tmdb_id': tmdb_id,
                        'cz_title': cz_title,
                        'year': year
                    }
                    
                    url = Tshare.get_url(**url_params)
                    xbmcplugin.addDirectoryItem(Tshare._handle, url, listitem, False)
                    
                except Exception as e:
                    logging.error(f'Original movie display error: {e}')
                    continue
                
        total_count = len(cz_results) + len(original_results)
        logging.info(f'Movie search celkem: {total_count} filmů (CZ: {len(cz_results)}, Original: {len(original_results)})')
        
        if total_count == 0:
            Tshare.popinfo('Nenalezeny žádné filmy', icon=xbmcgui.NOTIFICATION_WARNING)

    except Exception as e:
        logging.error(f'Movie search error: {e}')
        Tshare.popinfo(f'Chyba při hledání filmu: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
        
    xbmcplugin.endOfDirectory(Tshare._handle)
