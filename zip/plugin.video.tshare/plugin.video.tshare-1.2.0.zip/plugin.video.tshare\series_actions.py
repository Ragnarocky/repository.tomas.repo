# -*- coding: utf-8 -*-
# Series Actions Handler
# Author: Tomas for friends
# Created on: 10.9.2025

import xbmc
import xbmcgui
import xbmcplugin

def handle_delete_series(series_manager, series_name, handle):
    """Obsluha mazání seriálu s potvrzením"""
    try:
        # Zobraz potvrzovací dialog
        dialog = xbmcgui.Dialog()
        if dialog.yesno('Odstranit seriál', f'Opravdu chcete odstranit seriál "{series_name}"?\n\nTato akce je nevratná!'):
            # Smaž seriál
            if series_manager.delete_series(series_name):
                xbmcgui.Dialog().notification('Tshare', f'Seriál "{series_name}" byl odstraněn', xbmcgui.NOTIFICATION_INFO, 3000)
                # Refresh obsahu
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification('Tshare', 'Chyba při mazání seriálu', xbmcgui.NOTIFICATION_ERROR, 3000)
        return True
    except Exception as e:
        xbmc.log(f'Error in handle_delete_series: {str(e)}', level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Tshare', 'Chyba při mazání seriálu', xbmcgui.NOTIFICATION_ERROR, 3000)
        return False