# -*- coding: utf-8 -*-
# Module: series_manager
# Author: Tomas for friends
# Created on: 2.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html
# pylint: disable=import-error  # Kodi modules

import os
import io
import re
import json
import logging
import requests  # type: ignore
import xbmc  # type: ignore
import xbmcaddon  # type: ignore
import xbmcgui  # type: ignore
import xml.etree.ElementTree as ET
import unidecode  # type: ignore
import traceback
import xbmcplugin  # type: ignore

from pattern_learner import PatternLearner

try:
    from urllib import urlencode  # type: ignore
    from urlparse import parse_qsl  # type: ignore
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl

try:
    from xbmc import translatePath  # type: ignore
except ImportError:
    from xbmcvfs import translatePath  # type: ignore

# Regular expressions for detecting episode patterns - ROZŠÍŘENÉ FORMÁTY
EPISODE_PATTERNS = [
    # ZÁKLADNÍ S/E FORMÁTY  
    r'[Ss](\d+)[Ee](\d+)',      # S01E01, s1e1 format
    r'[Ss](\d+)\s*[Ee](\d+)',   # S01 E01 (s mezerou)
    r'[Ss](\d{1,2})\.?[Ee](\d{1,2})',  # S1E1, S01.E01
    
    # SEASON x EPISODE FORMÁTY
    r'(\d+)x(\d+)',             # 1x01, 15x23 format  
    r'(\d+)\s*x\s*(\d+)',       # 1 x 01 (s mezerami)
    r'(\d+)\.x\.?(\d+)',        # 1.x.01, 1.x01 format
    
    # ČESKÉ FORMÁTY
    r'(\d+)\.\s*d[íi]l',        # 01.díl, 02.díl format 
    r'-\s*(\d+)\.\s*d[íi]l',    # - 01.díl format
    r'(\d+)\s+d[íi]l',          # 01 díl format (bez tečky)
    r'(\d+)\.\s*cast',          # 01.cast, 02.cast format
    r'd[íi]l\s*(\d+)',          # díl 01, dil 15
    
    # ANGLICKÉ FORMÁTY
    r'[Ee]pisode\s*(\d+)',      # Episode 1, Episode 15
    r'[Ee]p\.?\s*(\d+)',        # Ep 1, Ep.15 format
    r'[Ee](\d+)\b',             # E1, E15 format (s word boundary)
    
    # SPECIÁLNÍ WEBSHARE FORMÁTY
    r'-([ivxlc]+)-(\d+)',       # -iii-43 format (Velkolepé-století-iii-43)
    r'_([ivxlc]+)_\(?(\d+)\)?', # _iii_(15) format pro pokračování
    r'\.([ivxlc]+)\.(\d+)',     # .iii.15 format
    
    # ROZŠÍŘENÉ FORMÁTY (uploadery často používají)
    r'[Ss]eason\s*(\d+).*?[Ee]pisode\s*(\d+)',  # Season 1 Episode 5
    r'[Ss](\d+)[-_\.](\d+)',    # S01-05, S1_15, S01.05
    r'(\d+)[-_](\d+)',          # 01-05, 1_15 (bez S/E)
    r'\[(\d+)x(\d+)\]',         # [1x05] format v závorkách
    r'\((\d+)x(\d+)\)',         # (1x05) format v závorkách
    r'\s([ivxlc]+)\s\(?(\d+)\)?',  # iii (15) format
]

# Mapování římských čísel na arabské (pro detekci sezón)
ROMAN_TO_ARABIC = {
    'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5,
    'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10,
    'xi': 11, 'xii': 12, 'xiii': 13, 'xiv': 14, 'xv': 15
}

class SeriesManager:
    def __init__(self, addon, profile):
        self.addon = addon
        self.profile = profile
        self.profile_path = profile  # Pro kompatibilitu
        self.series_db_path = os.path.join(profile, 'series_db')
        self.preferences_path = os.path.join(profile, 'series_preferences.json')
        
        # In-memory cache pro vyhledávací dotazy
        self._query_cache = {}
        self._keywords_cache = {}
        
        # Načti preference a inicializuj pattern learner
        self.load_preferences()
        self.pattern_learner = PatternLearner(profile)

    # Bezpečný název souboru pro DB/Cache
    def _safe_filename(self, name):
        try:
            n = unidecode.unidecode(name or '').strip().lower()
            n = re.sub(r'[^a-z0-9\-_]+', '_', n)
            n = re.sub(r'_+', '_', n).strip('_')
            return n or 'series'
        except Exception:
            return 'series'

    # Uložení/načtení dat seriálu (series_db/<safe>.json)
    def load_series_data(self, series_name):
        try:
            self.ensure_db_exists()
            path = os.path.join(self.series_db_path, f'{self._safe_filename(series_name)}.json')
            if os.path.exists(path):
                with io.open(path, 'r', encoding='utf8') as f:
                    return json.load(f)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: load_series_data error: {e}', level=xbmc.LOGERROR)
        return None

    def _save_series_data(self, series_name, series_data):
        try:
            self.ensure_db_exists()
            path = os.path.join(self.series_db_path, f'{self._safe_filename(series_name)}.json')
            with io.open(path, 'w', encoding='utf8') as f:
                json.dump(series_data or {}, f, indent=2)
            xbmc.log(f'Tshare Series Manager: series "{series_name}" saved (seasons={len(series_data.get("seasons", {}))})', level=xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: _save_series_data error: {e}', level=xbmc.LOGERROR)

    # Získání streamů pro epizodu
    def get_streams_for_episode(self, series_name, season, episode):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}
            se = str(season)
            ep = str(episode)
            return (seasons.get(se, {}).get(ep, {}) or {}).get('episodes', []) or []
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_streams_for_episode error: {e}', level=xbmc.LOGERROR)
            return []

    # Historie seriálů (playback)
    def _series_history_path(self):
        return os.path.join(self.profile, 'series_history.json')

    def get_series_history(self):
        try:
            path = self._series_history_path()
            if os.path.exists(path):
                with io.open(path, 'r', encoding='utf8') as f:
                    return json.load(f)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_series_history error: {e}', level=xbmc.LOGERROR)
        return []

    def save_history(self, history):
        try:
            with io.open(self._series_history_path(), 'w', encoding='utf8') as f:
                json.dump(history or [], f, indent=2)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: save_history error: {e}', level=xbmc.LOGERROR)

    def add_to_history(self, series_name, season, episode, episode_title, year=None, plot=None, poster=None, tmdb_id=None, stream_url=None):
        try:
            h = self.get_series_history()
            entry = {
                'series_name': str(series_name),
                'season': str(season),
                'episode': str(episode),
                'episode_title': episode_title,
                'year': year,
                'plot': plot,
                'poster': poster,
                'tmdb_id': tmdb_id,
                'stream_url': stream_url,
                'timestamp': int(__import__('time').time())
            }
            # odstranit starou shodu (duplicitní záznam téže epizody)
            h = [e for e in h if not (e.get('series_name') == entry['series_name'] and e.get('season') == entry['season'] and e.get('episode') == entry['episode'])]
            h.insert(0, entry)
            self.save_history(h[:800])
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: add_to_history error: {e}', level=xbmc.LOGERROR)

    # Nově: poslední shlédnutá epizoda (pro zvýraznění v seznamu)
    def get_last_watched_episode(self, series_name):
        """Vrátí poslední zhlédnutou epizodu jako (season, episode) nebo (None, None)."""
        try:
            history = self.get_series_history()
            series_episodes = [h for h in history if h.get('series_name') == series_name]
            if not series_episodes:
                return (None, None)
            latest = max(series_episodes, key=lambda x: x.get('timestamp', 0) or 0)
            return (latest.get('season'), latest.get('episode'))
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_last_watched_episode error: {e}', level=xbmc.LOGERROR)
            return (None, None)

    # Vrátí další díl v rámci celého seriálu (podle historie) + nejlepší stream
    def get_next_episode(self, series_name):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}
            if not seasons:
                return (None, None, None)
            # seřadit sezóny a epizody numericky
            def sort_int_keys(d):
                return sorted(d.keys(), key=lambda x: int(x) if str(x).isdigit() else x)
            season_keys = sort_int_keys(seasons)

            last_s, last_e = self.get_last_watched_episode(series_name)
            # start: první epizoda v prvním dostupném seznamu
            def first_available():
                s0 = season_keys[0]
                ep_keys = sort_int_keys(seasons[s0])
                if not ep_keys:
                    return (None, None, None)
                e0 = ep_keys[0]
                streams = (seasons[s0][e0] or {}).get('episodes') or []
                if not streams:
                    return (None, None, None)
                best = self._sort_streams(streams, series_name, s0, e0)[0]
                return (str(s0), str(e0), best)

            if not last_s or not last_e:
                return first_available()

            # najít další epizodu po poslední shlédnuté
            last_s = str(last_s)
            last_e = str(last_e)
            if last_s in seasons:
                ep_keys = sort_int_keys(seasons[last_s])
                try:
                    idx = ep_keys.index(last_e)
                except ValueError:
                    return first_available()
                # další v rámci stejné sezóny
                if idx + 1 < len(ep_keys):
                    next_e = ep_keys[idx + 1]
                    streams = (seasons[last_s][next_e] or {}).get('episodes') or []
                    if streams:
                        best = self._sort_streams(streams, series_name, last_s, next_e)[0]
                        return (str(last_s), str(next_e), best)
                # první epizoda v další sezóně
                try:
                    sidx = season_keys.index(last_s)
                except ValueError:
                    return first_available()
                if sidx + 1 < len(season_keys):
                    ns = season_keys[sidx + 1]
                    neps = seasons[ns]
                    nep_keys = sort_int_keys(neps)
                    if nep_keys:
                        ne = nep_keys[0]
                        streams = (neps[ne] or {}).get('episodes') or []
                        if streams:
                            best = self._sort_streams(streams, series_name, ns, ne)[0]
                            return (str(ns), str(ne), best)
            # fallback
            return first_available()
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_next_episode error: {e}', level=xbmc.LOGERROR)
            return (None, None, None)

    # Vrátí další díl v rámci konkrétní řady + nejlepší stream
    def get_next_episode_in_season(self, series_name, season):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}
            s = str(season)
            if s not in seasons:
                return (None, None, None)
            def sort_int_keys(d):
                return sorted(d.keys(), key=lambda x: int(x) if str(x).isdigit() else x)
            ep_keys = sort_int_keys(seasons[s])
            if not ep_keys:
                return (None, None, None)

            last_s, last_e = self.get_last_watched_episode(series_name)
            if str(last_s) == s and last_e and str(last_e) in ep_keys:
                idx = ep_keys.index(str(last_e))
                if idx + 1 < len(ep_keys):
                    next_e = ep_keys[idx + 1]
                    streams = (seasons[s][next_e] or {}).get('episodes') or []
                    if streams:
                        best = self._sort_streams(streams, series_name, s, next_e)[0]
                        return (s, str(next_e), best)
            # jinak první epizoda v řadě
            first_e = ep_keys[0]
            streams = (seasons[s][first_e] or {}).get('episodes') or []
            if streams:
                best = self._sort_streams(streams, series_name, s, first_e)[0]
                return (s, str(first_e), best)
            return (None, None, None)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_next_episode_in_season error: {e}', level=xbmc.LOGERROR)
            return (None, None, None)

    # Zruší nucený pattern (pro obnovu chytrého řazení)


    # Smazání seriálu (pro menu akci)
    def delete_series(self, series_name):
        try:
            ok = True
            # DB
            db_path = os.path.join(self.series_db_path, f'{self._safe_filename(series_name)}.json')
            if os.path.exists(db_path):
                try:
                    os.remove(db_path)
                except Exception:
                    ok = False
            # Cache - smaž všechny možné cache soubory
            try:
                # Zkus smazat všechny možné cache varianty
                cache_patterns = [
                    self.get_series_cache_path(series_name),  # Aktuální způsob
                    # Starý způsob pro zpětnou kompatibilitu
                    os.path.join(self.get_cache_dir(), f"{self._safe_filename(series_name)}.json")
                ]
                
                for cache_path in cache_patterns:
                    if os.path.exists(cache_path):
                        try:
                            os.remove(cache_path)
                        except Exception:
                            ok = False
            except Exception:
                ok = False
            # Preference
            if series_name in self.preferences:
                try:
                    self.preferences.pop(series_name, None)
                    self.save_preferences()
                except Exception:
                    ok = False
            return ok
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: delete_series error: {e}', level=xbmc.LOGERROR)
            return False

    # Najde chybějící díly podle existujících epizod v DB (1..max zjištěné)
    def find_missing_episodes(self, series_name):
        missing = []
        try:
            data = self.load_series_data(series_name) or {}
            for s, eps in (data.get('seasons') or {}).items():
                nums = sorted(int(n) for n in eps.keys() if str(n).isdigit())
                if not nums: 
                    continue
                max_ep = max(nums)
                for e in range(1, max_ep + 1):
                    if str(e) not in eps:
                        missing.append((int(s), int(e)))
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: find_missing_episodes error: {e}', level=xbmc.LOGERROR)
        return missing



    # Vyhledá a doplní chybějící díly (vrátí počet přidaných)
    def search_missing_episodes(self, series_name, api_function, token, missing_episodes):
        """NOVÁ EFEKTIVNÍ VERZE: Široké hledání + lokální filtrování chybějících dílů"""
        added = 0
        try:
            import time
            start_time = time.time()
            MAX_SEARCH_TIME = 20  # Kratší - jen 2 široké dotazy
            
            xbmc.log(f'SeriesManager: NEW APPROACH - Searching for {len(missing_episodes)} missing episodes via broad search + filtering', level=xbmc.LOGINFO)
            
            # Vytvoř set chybějících dílů pro rychlé vyhledávání
            missing_set = set(missing_episodes)
            xbmc.log(f'Missing episodes: {missing_set}', level=xbmc.LOGINFO)
            
            # Získej originaltitle
            originaltitle = self._get_originaltitle(series_name)
            
            data = self.load_series_data(series_name) or {'name': series_name, 'seasons': {}}

            # KROK 1: Široké hledání českým názvem
            xbmc.log(f'MISSING: Broad search with Czech name: "{series_name}"', level=xbmc.LOGINFO)
            czech_results = self._perform_multi_search(series_name, api_function, token)
            
            # KROK 2: INTELIGENTNÍ ROZHODNUTÍ - hledej anglicky JEN když je potřeba
            english_results = []
            if originaltitle and originaltitle != series_name:
                # Zkontroluj, kolik chybějících dílů jsme našli v českých výsledcích
                czech_found_count = 0
                for item in czech_results:
                    for keyword_source in [series_name]:
                        season_num, episode_num = self._detect_episode_info(item['name'], keyword_source)
                        if (season_num, episode_num) in missing_set:
                            czech_found_count += 1
                            break
                
                # Pokud jsme našli méně než 50% chybějících, hledej anglicky
                found_percentage = (czech_found_count / len(missing_set)) * 100 if missing_set else 0
                
                if found_percentage < 50:
                    xbmc.log(f'MISSING: Czech found {czech_found_count}/{len(missing_set)} ({found_percentage:.1f}%), searching English', level=xbmc.LOGINFO)
                    english_results = self._perform_multi_search(originaltitle, api_function, token)
                else:
                    xbmc.log(f'MISSING: Czech found {czech_found_count}/{len(missing_set)} ({found_percentage:.1f}%), SKIPPING English search', level=xbmc.LOGINFO)
            
            # KROK 2.5: ROZŠÍŘENÉ HLEDÁNÍ - různé varianty názvu pro více hits
            extended_results = []
            if time.time() - start_time < MAX_SEARCH_TIME - 5:  # Pokud máme čas
                # Zkus varianty názvu (tvůj návrh na odhalení dalších dílů)
                variants = []
                
                # OPATRNÉ VARIANTY: Jen nejbezpečnější a nejefektivnější
                variants.extend([
                    f'{series_name} cz',           # "Simpsonovi cz" (nejbezpečnější)
                    f'{series_name} czech'         # "Simpsonovi czech" (druhá nejbezpečnější)
                ])
                
                # ANGLICKÝ NÁZEV: Jen TOP varianty
                if originaltitle and len(originaltitle.split()) <= 3:  # BEZPEČNOST: Jen krátké názvy
                    variants.extend([
                        f'{originaltitle} 1080p',      # "The Simpsons 1080p" (nejčastější)
                        f'{originaltitle} web-dl'      # "The Simpsons web-dl" (druhá nejčastější)
                    ])
                
                xbmc.log(f'MISSING: Extended search with {len(variants)} variants', level=xbmc.LOGINFO)
                for variant in variants[:2]:  # OMEZENO: Max 2 varianty (bezpečnější)
                    if time.time() - start_time > MAX_SEARCH_TIME - 3:
                        break
                    variant_results = self._perform_search(variant, api_function, token)
                    extended_results.extend(variant_results[:30])  # OMEZENO: Max 30 per variant (místo 50)
            
            # KROK 3: Sloučení všech výsledků
            all_results = czech_results + english_results + extended_results
            xbmc.log(f'MISSING: Total results from broad search: {len(all_results)}', level=xbmc.LOGINFO)
            
            # KROK 4: Filtrování jen chybějících dílů
            found_missing = {}  # {(season, episode): [list_of_items]}
            
            for item in all_results:
                # Zkus detekci s českým i anglickým názvem
                for keyword_source in [series_name, originaltitle]:
                    if not keyword_source:
                        continue
                        
                    season_num, episode_num = self._detect_episode_info(item['name'], keyword_source)
                    
                    if (season_num, episode_num) in missing_set:
                        # Je to chybějící díl!
                        if self._is_likely_episode(item['name'], keyword_source, season_num, episode_num):
                            key = (season_num, episode_num)
                            if key not in found_missing:
                                found_missing[key] = []
                            
                            # OPRAVA: Přiřaď prioritu podle jazyka (jako v merge)
                            priority = 1 if keyword_source == series_name else 2
                            item_with_priority = dict(item)
                            item_with_priority['priority'] = priority
                            
                            found_missing[key].append(item_with_priority)
                            break  # Už jsme našli match, nekontroluj druhý název
            
            xbmc.log(f'MISSING: Found {len(found_missing)} missing episodes from broad search', level=xbmc.LOGINFO)
            
            # KROK 5: Zpracování nalezených chybějících dílů
            for (s, e), items in found_missing.items():
                # Ulož do databáze
                seasons = data.setdefault('seasons', {})
                seasons.setdefault(str(s), {})
                seasons[str(s)].setdefault(str(e), {'episodes': []})
                episode_list = seasons[str(s)][str(e)]['episodes']
                
                # OPRAVA: Přidej VŠECHNY nalezené streamy (max 8), ne jen nejlepší
                items_sorted = sorted(items, key=lambda it: int(it.get('size') or '0'), reverse=True)
                added_count = 0
                
                for item in items_sorted:
                    # Skip pokud už máme 8 verzí
                    if len(episode_list) >= 8:
                        break
                    
                    # Dedup podle ident
                    if not any(ep.get('ident') == item.get('ident') for ep in episode_list):
                        episode_list.append({
                            'name': item.get('name'),
                            'ident': item.get('ident'),
                            'size': item.get('size') or '0',
                            'priority': item.get('priority', 999)  # DŮLEŽITÉ: zachovat prioritu
                        })
                        added_count += 1
                
                # Seřaď podle preferencí
                if added_count > 0:
                    seasons[str(s)][str(e)]['episodes'] = self._sort_streams(episode_list, series_name, str(s), str(e))
                    added += 1
                    xbmc.log(f'MISSING: Added S{s}E{e}: {added_count} stream(s), best: {items_sorted[0]["name"][:50]}...', level=xbmc.LOGINFO)

            # Výsledkové hlášení
            elapsed_time = time.time() - start_time
            xbmc.log(f'TShare: Search completed - Added {added} episodes in {elapsed_time:.1f}s', xbmc.LOGINFO)
            
            if added:
                self._save_series_data(series_name, data)
                # OPRAVA: Získej originaltitle z dat pro správné uložení cache
                originaltitle_from_data = data.get('originaltitle')
                self.save_series_cache(series_name, data, originaltitle_from_data)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: search_missing_episodes error: {e}', level=xbmc.LOGERROR)
        return added

    def cleanup_series_cache(self, max_files=50):
        """Ponechá pouze max_files nejnovějších cache souborů v každém cache adresáři."""
        try:
            # Vyčisti root cache adresář
            root_cache_dir = self.get_cache_dir()
            if os.path.exists(root_cache_dir):
                files = []
                for item in os.listdir(root_cache_dir):
                    item_path = os.path.join(root_cache_dir, item)
                    if os.path.isfile(item_path) and item.endswith('.json'):
                        files.append(item_path)
                
                if files:
                    files = sorted(files, key=lambda f: os.path.getmtime(f), reverse=True)
                    for f in files[max_files:]:
                        try:
                            os.remove(f)
                        except Exception:
                            pass
                
                # Vyčisti také rozdělené adresáře
                for subdir in os.listdir(root_cache_dir):
                    subdir_path = os.path.join(root_cache_dir, subdir)
                    if os.path.isdir(subdir_path):
                        sub_files = [os.path.join(subdir_path, f) for f in os.listdir(subdir_path) if f.endswith('.json')]
                        if sub_files:
                            sub_files = sorted(sub_files, key=lambda f: os.path.getmtime(f), reverse=True)
                            for f in sub_files[max_files:]:
                                try:
                                    os.remove(f)
                                except Exception:
                                    pass
        except Exception as e:
            xbmc.log(f'Cache cleanup error: {e}', level=xbmc.LOGWARNING)
    def get_cache_dir(self, series_name=None):
        """Vrací cache adresář, volitelně rozdělený podle první písmena série"""
        base_cache_dir = os.path.join(self.profile, 'series_cache')
        
        if series_name:
            # Rozdělení cache podle prvního písmena pro lepší performance
            first_char = self._safe_filename(series_name)[:1].lower()
            if not first_char or first_char not in 'abcdefghijklmnopqrstuvwxyz0123456789':
                first_char = 'other'
            cache_dir = os.path.join(base_cache_dir, first_char)
        else:
            cache_dir = base_cache_dir
            
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        return cache_dir

    def _get_canonical_cache_key(self, series_name, originaltitle=None):
        """Vytvoří kanonický klíč pro cache z series_name a originaltitle"""
        # PRIMÁRNÍ je vždy čeština (series_name/showname)
        # originaltitle jen jako fallback nebo pro rozlišení
        primary_key = self._safe_filename(series_name)
        
        # Pokud máme originaltitle a je jiný než series_name, přidej jako suffix pro jedinečnost
        if originaltitle and originaltitle != series_name:
            original_key = self._safe_filename(originaltitle)
            # Kombinuj oba klíče pro jedinečnost
            primary_key = f"{primary_key}_{original_key}"
        
        # Normalizuj klíč (odstraň diakritiku, lowercase, atd.)
        normalized = unidecode.unidecode(primary_key).lower()
        normalized = re.sub(r'[^a-z0-9_-]', '_', normalized)
        normalized = re.sub(r'_+', '_', normalized).strip('_')
        
        return normalized or 'unknown_series'

    def get_series_cache_path(self, series_name, originaltitle=None):
        """Vrátí cestu k cache souboru s použitím kanonického klíče a rozděleného adresáře"""
        canonical_key = self._get_canonical_cache_key(series_name, originaltitle)
        return os.path.join(self.get_cache_dir(series_name), f"{canonical_key}.json")

    def load_series_cache(self, series_name, max_age_days=7, originaltitle=None):
        """Načte cache seriálu, pokud existuje a není starší než max_age_days."""
        import time
        
        # Zkus různé možnosti pro načtení cache (PRIMÁRNÍ je vždy čeština)
        cache_paths = []
        
        # 1. Primární: Kanonický klíč s českým názvem
        cache_paths.append(self.get_series_cache_path(series_name))
        
        # 2. Kombinovaný klíč (český + originaltitle)
        if originaltitle and originaltitle != series_name:
            cache_paths.append(self.get_series_cache_path(series_name, originaltitle))
        
        # 3. Starý způsob - český název (pro zpětnou kompatibilitu) - root adresář
        old_safe_name = self._safe_filename(series_name)
        old_path = os.path.join(self.get_cache_dir(), f"{old_safe_name}.json")  # bez series_name parametru = root
        cache_paths.append(old_path)
        
        # 4. Fallback: starý způsob s originaltitle (pokud někdo hledal anglicky) - root adresář
        if originaltitle and originaltitle != series_name:
            old_original_safe = self._safe_filename(originaltitle)
            old_original_path = os.path.join(self.get_cache_dir(), f"{old_original_safe}.json")  # bez series_name parametru = root
            cache_paths.append(old_original_path)
        
        for path in cache_paths:
            if not os.path.exists(path):
                continue
                
            try:
                mtime = os.path.getmtime(path)
                age_days = (time.time() - mtime) / 86400
                if age_days > max_age_days:
                    # Smaž starý cache soubor
                    try:
                        os.remove(path)
                    except Exception:
                        pass
                    continue
                    
                with io.open(path, 'r', encoding='utf8') as file:
                    cached_data = json.load(file)
                    xbmc.log(f'Series cache loaded from: {path}', level=xbmc.LOGDEBUG)
                    return cached_data
            except (IOError, ValueError, json.JSONDecodeError) as e:
                xbmc.log(f'Series cache error for {path}: {str(e)}', level=xbmc.LOGWARNING)
                # Smaž poškozený cache soubor
                try:
                    os.remove(path)
                except Exception:
                    pass
                continue
                
        # Žádná cache nebyla nalezena
        return None

    def save_series_cache(self, series_name, series_data, originaltitle=None):
        """Uloží výsledky hledání seriálu do cache s použitím kanonického klíče."""
        # Použij kanonický klíč pro uložení
        path = self.get_series_cache_path(series_name, originaltitle)
        try:
            # Porovnej s existující cache
            existing = None
            if os.path.exists(path):
                try:
                    with io.open(path, 'r', encoding='utf8') as file:
                        existing = json.load(file)
                except Exception:
                    pass
            
            # Spočítej kvalitu nových dat
            new_seasons = len(series_data.get('seasons', {}))
            new_episodes = sum(len(season) for season in series_data.get('seasons', {}).values())
            
            should_save = True
            if existing:
                old_seasons = len(existing.get('seasons', {}))
                old_episodes = sum(len(season) for season in existing.get('seasons', {}).values())
                
                # Ulož jen pokud jsou nové výsledky lepší
                if new_seasons > old_seasons or (new_seasons == old_seasons and new_episodes > old_episodes):
                    xbmc.log(f'Cache update pro {series_name}: {old_seasons}→{new_seasons} sezón, {old_episodes}→{new_episodes} epizod', level=xbmc.LOGINFO)
                else:
                    should_save = False
                    xbmc.log(f'Cache pro {series_name} nezměněna: nové výsledky nejsou lepší ({new_seasons} sezón, {new_episodes} epizod)', level=xbmc.LOGINFO)
            else:
                xbmc.log(f'Nová cache pro {series_name}: {new_seasons} sezón, {new_episodes} epizod', level=xbmc.LOGINFO)
            
            if should_save:
                with io.open(path, 'w', encoding='utf8') as file:
                    json.dump(series_data, file, indent=2)
                self.cleanup_series_cache(max_files=10)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error saving series cache: {str(e)}', level=xbmc.LOGERROR)
    
    def ensure_db_exists(self):
        """Ensure that the series database directory exists"""
        try:
            if not os.path.exists(self.profile):
                os.makedirs(self.profile)
            if not os.path.exists(self.series_db_path):
                os.makedirs(self.series_db_path)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error creating directories: {str(e)}', level=xbmc.LOGERROR)
    
    def load_preferences(self):
        """Načte preference ze souboru"""
        self.preferences = {}
        if os.path.exists(self.preferences_path):
            try:
                with io.open(self.preferences_path, 'r', encoding='utf8') as file:
                    self.preferences = json.load(file)
            except Exception as e:
                xbmc.log(f'Error loading preferences: {str(e)}', level=xbmc.LOGERROR)

    def save_preferences(self):
        """Uloží preference do souboru"""
        try:
            with io.open(self.preferences_path, 'w', encoding='utf8') as file:
                json.dump(self.preferences, file, indent=2)
        except Exception as e:
            xbmc.log(f'Error saving preferences: {str(e)}', level=xbmc.LOGERROR)

    def set_preferred_stream_position(self, series_name, position):
        """NOVÝ SYSTÉM: Nastaví preferovanou POZICI streamu (1., 2., 3., ...) pro celý seriál"""
        if series_name not in self.preferences:
            self.preferences[series_name] = {}
        
        # Ulož preferovanou pozici
        self.preferences[series_name]['preferred_stream_position'] = position
        xbmc.log(f'SeriesManager: Set preferred stream position {position} for "{series_name}"', level=xbmc.LOGINFO)
        
        self.save_preferences()
        
        # Vynuluj staré episode_patterns (pokud existují) protože nově používáme pozice
        if 'episode_patterns' in self.preferences[series_name]:
            del self.preferences[series_name]['episode_patterns']
            self.save_preferences()
    
    def set_episode_stream_position(self, series_name, season, episode, position):
        """NOVÝ SYSTÉM: Nastaví preferovanou pozici streamu pro konkrétní epizodu"""
        if series_name not in self.preferences:
            self.preferences[series_name] = {}
        if 'episode_stream_positions' not in self.preferences[series_name]:
            self.preferences[series_name]['episode_stream_positions'] = {}
        
        episode_key = f"S{season}E{episode}"
        self.preferences[series_name]['episode_stream_positions'][episode_key] = position
        xbmc.log(f'SeriesManager: Set stream position {position} for "{series_name}" {episode_key}', level=xbmc.LOGINFO)
        
        self.save_preferences()
    
    def get_preferred_stream_position(self, series_name, season=None, episode=None):
        """NOVÝ SYSTÉM: Získá preferovanou pozici streamu pro seriál nebo epizodu"""
        if series_name not in self.preferences:
            return None
        
        # Nejprve zkontroluj specifické nastavení epizody
        if season is not None and episode is not None:
            episode_key = f"S{season}E{episode}"
            episode_positions = self.preferences[series_name].get('episode_stream_positions', {})
            if episode_key in episode_positions:
                return episode_positions[episode_key]
        
        # Pak zkontroluj nastavení pro celý seriál
        return self.preferences[series_name].get('preferred_stream_position')



    def _sort_streams(self, episodes, series_name, season=None, episode=None):
        """Seřadí streamy s prioritou: preferred position > chytré řazení"""
        episodes = list(episodes)
        
        # Zkontroluj preferovanou POZICI
        preferred_position = self.get_preferred_stream_position(series_name, season, episode)
        
        if preferred_position is not None:
            # Máme preferovanou pozici - nejdřív chytře seřadíme a pak přesuneme N-tý stream nahoru
            sorted_episodes = self._smart_sort_episodes(episodes, series_name)
            
            # Pokud existuje stream na požadované pozici, přesuň ho na začátek
            if len(sorted_episodes) >= preferred_position:
                preferred_stream = sorted_episodes[preferred_position - 1]  # 1-based -> 0-based
                sorted_episodes.remove(preferred_stream)
                sorted_episodes.insert(0, preferred_stream)
                xbmc.log(f'SeriesManager: Using position {preferred_position} stream for "{series_name}" S{season}E{episode}', level=xbmc.LOGDEBUG)
            else:
                xbmc.log(f'SeriesManager: Preferred position {preferred_position} not available (only {len(sorted_episodes)} streams), using smart sort', level=xbmc.LOGDEBUG)
            
            return sorted_episodes
        
        # Default: smart sorting
        return self._smart_sort_episodes(episodes, series_name)
    
    def _smart_sort_episodes(self, episodes, series_name):
        """Chytré řazení streamů podle priority, češtiny a velikosti"""
        def sort_key(episode):
            name = episode.get('name', '').lower()
            size = int(episode.get('size', '0'))
            
            # 1. MERGE PRIORITY (czech=1, english=2)
            merge_priority = episode.get('priority', 999)
            
            # 2. Czech patterns bonus (lower = better)
            czech_bonus = 0
            czech_patterns = [
                'cz', 'czech', 'cesky', 'ceska', 'ceske',
                'sk', 'slovak', 'slovensky', 'slovenska',
                '.cz.', '-cz-', '_cz_', '[cz]', '(cz)',
                'cz.tit', 'cz.sub', 'cz.dab', 'cz.avi', 'cz.mkv',
                'czech.sub', 'czech.dub', 'czech.tit',
                'ceske.titulky', 'cestina', 'slovenčina'
            ]
            
            # Check for any Czech pattern
            if any(pattern in name for pattern in czech_patterns):
                czech_bonus = 1000000  # High priority for Czech content
            
            # NOVÉ ŘAZENÍ: merge_priority > czech_bonus > size
            # (merge priority 1=czech search, 2=english search)
            return (merge_priority, -czech_bonus, -size)
        
        return sorted(episodes, key=sort_key)
    
    def search_series(self, series_name, api_function, token, originaltitle=None, tmdb_id=None):
        """Search for episodes of a series with automatic Czech+English merge"""
        try:
            xbmc.log(f'Series Manager: Starting search for "{series_name}" + originaltitle="{originaltitle}" + tmdb_id="{tmdb_id}"', level=xbmc.LOGINFO)
            
            # OPTIMALIZACE: Nejdřív zkontroluj cache (7 dní platnost)
            cached_data = self.load_series_cache(series_name, max_age_days=7, originaltitle=originaltitle)
            if cached_data and cached_data.get('seasons'):
                total_cached_episodes = sum(len(season) for season in cached_data['seasons'].values())
                xbmc.log(f'Series Manager: Using CACHED data for "{series_name}" ({len(cached_data["seasons"])} seasons, {total_cached_episodes} episodes)', level=xbmc.LOGINFO)
                
                # Ulož do DB (pokud tam není)
                existing_db = self.load_series_data(series_name)
                if not existing_db or not existing_db.get('seasons'):
                    self._save_series_data(series_name, cached_data)
                    xbmc.log(f'Series Manager: Saved cached data to DB for "{series_name}"', level=xbmc.LOGINFO)
                
                return cached_data
            
            xbmc.log(f'Series Manager: No valid cache found, starting AUTO-MERGE search for "{series_name}"', level=xbmc.LOGINFO)
            
            # AUTOMATICKÉ ZÍSKÁNÍ TMDB ID pokud chybí
            if not tmdb_id:
                try:
                    from urllib.parse import quote
                    api_key = self.addon.getSetting('tmdb_api_key').strip() or '4219e299c89411838049ab0dab19ebd5'
                    search_query = originaltitle if originaltitle else series_name
                    url = f'https://api.themoviedb.org/3/search/tv?api_key={api_key}&query={quote(search_query)}&language=cs-CZ'
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        results = response.json().get('results', [])
                        if results:
                            tmdb_id = results[0]['id']
                            xbmc.log(f'Series Manager: Auto-found TMDB ID {tmdb_id} for "{series_name}"', level=xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f'Series Manager: Failed to auto-find TMDB ID: {e}', level=xbmc.LOGDEBUG)
            
            series_data = {
                'name': series_name,
                'last_updated': xbmc.getInfoLabel('System.Date'),
                'tmdb_id': tmdb_id,  # Uložit TMDB ID pro Trakt.tv
                'seasons': {},
                'metadata': {}  # NOVÉ: Metadata z TMDB
            }
            
            # NOVÉ: Získat informace o počtu epizod z TMDB + metadata (pokud máme tmdb_id)
            tmdb_season_info = {}  # {season_num: max_episode_count}
            if tmdb_id:
                try:
                    from urllib.parse import quote
                    api_key = self.addon.getSetting('tmdb_api_key').strip() or '4219e299c89411838049ab0dab19ebd5'
                    url = f'https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={api_key}&language=cs-CZ'
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        tv_data = response.json()
                        
                        # Uložit metadata
                        poster_path = tv_data.get('poster_path')
                        backdrop_path = tv_data.get('backdrop_path')
                        series_data['metadata'] = {
                            'title': tv_data.get('name'),
                            'originaltitle': tv_data.get('original_name'),
                            'plot': tv_data.get('overview'),
                            'rating': tv_data.get('vote_average'),
                            'votes': tv_data.get('vote_count'),
                            'year': tv_data.get('first_air_date', '')[:4] if tv_data.get('first_air_date') else None,
                            'genres': [g['name'] for g in tv_data.get('genres', [])],
                            'poster': f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else None,
                            'fanart': f"https://image.tmdb.org/t/p/original{backdrop_path}" if backdrop_path else None,
                            'status': tv_data.get('status'),
                            'networks': [n['name'] for n in tv_data.get('networks', [])],
                        }
                        
                        # Episode counts per season
                        for season in tv_data.get('seasons', []):
                            season_num = season.get('season_number')
                            episode_count = season.get('episode_count')
                            if season_num is not None and episode_count:
                                tmdb_season_info[season_num] = episode_count
                        
                        xbmc.log(f'Series Manager: TMDB data loaded for "{series_name}": {len(tmdb_season_info)} seasons, poster={bool(poster_path)}', level=xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f'Series Manager: Failed to get TMDB data: {e}', level=xbmc.LOGDEBUG)
            
            # 1. HLEDÁNÍ ČESKÝCH VÝSLEDKŮ
            czech_results = self._perform_multi_search(series_name, api_function, token)
            xbmc.log(f'AUTO-MERGE: Czech search found {len(czech_results)} results', level=xbmc.LOGINFO)
            
            # 2. INTELIGENTNÍ ROZHODNUTÍ: Spustit anglické hledání JEN když je potřeba
            english_results = []
            should_search_english = False
            
            if originaltitle and originaltitle != series_name:
                # KONTROLA: Máme dostatek českých výsledků?
                MIN_CZECH_RESULTS = 20  # Rozumný práh pro série
                
                if len(czech_results) < MIN_CZECH_RESULTS:
                    xbmc.log(f'AUTO-MERGE: Czech results insufficient ({len(czech_results)} < {MIN_CZECH_RESULTS}), starting English search', level=xbmc.LOGINFO)
                    should_search_english = True
                else:
                    # Zkontroluj kvalitu českých výsledků (kolik je relevantních epizod)
                    detected_episodes = 0
                    for item in czech_results[:100]:  # Zkontroluj prvních 100
                        s, e = self._detect_episode_info(item['name'], series_name)
                        if s and e:
                            detected_episodes += 1
                    
                    # Pokud méně než 30% výsledků jsou platné epizody, hledej anglicky
                    if detected_episodes < len(czech_results[:100]) * 0.3:
                        xbmc.log(f'AUTO-MERGE: Low episode detection rate ({detected_episodes}/{len(czech_results[:100])}), starting English search', level=xbmc.LOGINFO)
                        should_search_english = True
                    else:
                        xbmc.log(f'AUTO-MERGE: Czech results sufficient ({len(czech_results)} results, {detected_episodes} episodes), SKIPPING English search', level=xbmc.LOGINFO)
            
            if should_search_english:
                xbmc.log(f'AUTO-MERGE: Starting English search for "{originaltitle}"', level=xbmc.LOGINFO)
                english_results = self._perform_multi_search(originaltitle, api_function, token)
                xbmc.log(f'AUTO-MERGE: English search found {len(english_results)} results', level=xbmc.LOGINFO)
            
            # 3. INTELIGENTNÍ SLOUČENÍ výsledků s českou prioritou
            if english_results:
                all_results = self._merge_search_results(czech_results, english_results, series_name)
                search_used_originaltitle = True  # Pro keyword detection
            else:
                all_results = czech_results
                search_used_originaltitle = False
            
            if not all_results:
                xbmc.log(f'Series Manager: No results found for "{series_name}" or "{originaltitle}"', level=xbmc.LOGINFO)
                return None
                
            # Process and organize results
            processed_count = 0
            filtered_count = 0
            accepted_count = 0
            MAX_PROCESSED_ITEMS = 800   # Rozumný limit - není třeba přehánět
            MAX_ACCEPTED_EPISODES = 500  # Stačí pro většinu seriálů
            
            # Progress reporting pro velké serie
            total_items = len(all_results)
            xbmc.log(f'SeriesManager: Processing {total_items} items for "{series_name}"', level=xbmc.LOGINFO)
            
            import time
            start_time = time.time()
            MAX_PROCESSING_TIME = 30  # Rozumný kompromis mezi rychlostí a úplností
            
            for i, item in enumerate(all_results):
                # ČASOVÝ LIMIT: Zabránění zamrznutí Kodi
                if time.time() - start_time > MAX_PROCESSING_TIME:
                    xbmc.log(f'SeriesManager: Dosažen časový limit {MAX_PROCESSING_TIME}s - ukončuji zpracování po {i} položkách', xbmc.LOGWARNING)
                    break
                # RYCHLÝ EXIT: Zabráníme zpracování tisíců souborů
                if processed_count >= MAX_PROCESSED_ITEMS:
                    xbmc.log(f'SeriesManager: Dosažen limit {MAX_PROCESSED_ITEMS} zpracovaných souborů pro {series_name}', xbmc.LOGINFO)
                    break
                
                # DALŠÍ BEZPEČNOST: Limit pro přijaté epizody
                if accepted_count >= MAX_ACCEPTED_EPISODES:
                    xbmc.log(f'SeriesManager: Dosažen limit {MAX_ACCEPTED_EPISODES} přijatých epizod pro {series_name}', xbmc.LOGINFO)
                    break
                
                # Progress každých 50 položek + garbage collection (méně často kvůli výkonu)
                if i > 0 and i % 50 == 0:
                    elapsed = time.time() - start_time
                    xbmc.log(f'SeriesManager: Progress {i}/{total_items} - Accepted: {accepted_count}, Time: {elapsed:.1f}s', level=xbmc.LOGINFO)
                    # Garbage collection každých 100 položek (optimalizováno)
                    if i % 100 == 0:
                        import gc
                        gc.collect()
                    
                # Pokud používáme originaltitle results, použij originaltitle pro keywords
                keyword_source = originaltitle if search_used_originaltitle else series_name
                season_num, episode_num = self._detect_episode_info(item['name'], keyword_source)
                
                if season_num is not None and episode_num is not None:
                    processed_count += 1
                    
                    # NOVÁ KONTROLA: Ověř, že epizoda nepřesahuje TMDB maximum
                    if tmdb_season_info:
                        tmdb_max_episodes = tmdb_season_info.get(season_num)
                        if tmdb_max_episodes and episode_num > tmdb_max_episodes:
                            xbmc.log(f'Series Manager: REJECT S{season_num:02d}E{episode_num:02d} - exceeds TMDB max ({tmdb_max_episodes}): {item["name"][:80]}', level=xbmc.LOGINFO)
                            filtered_count += 1
                            continue
                    
                    if self._is_likely_episode(item['name'], keyword_source, season_num, episode_num):
                        accepted_count += 1
                        
                        # 🔍 DETEKCE ŘÍMSKÝCH ČÍSEL V NÁZVU SOUBORU - mapuj na vyšší sezóny
                        filename_lower = item['name'].lower()
                        roman_match = re.search(r'-([ivx]+)-', filename_lower)
                        
                        if roman_match:
                            # Římská čísla mapuj na vyšší sezóny (100+)
                            roman_numeral = roman_match.group(1)
                            original_roman_season = ROMAN_TO_ARABIC.get(roman_numeral, 1)
                            # Mapuj II->102, III->103, IV->104, atd.
                            season_num = 100 + original_roman_season
                            
                        season_num_str = str(season_num)
                        episode_num_str = str(episode_num)
                        
                        if season_num_str not in series_data['seasons']:
                            series_data['seasons'][season_num_str] = {}
                            xbmc.log(f'Creating new season {season_num_str} for {series_name}', level=xbmc.LOGDEBUG)
                        
                        if episode_num_str not in series_data['seasons'][season_num_str]:
                            series_data['seasons'][season_num_str][episode_num_str] = {
                                'episodes': []
                            }
                        
                        # LIMIT: Max 8 alternativ na epizodu (rozumný kompromis)
                        episode_list = series_data['seasons'][season_num_str][episode_num_str]['episodes']
                        if len(episode_list) < 8:
                            # Přidej informaci o zdroji pro debug
                            source_info = item.get('source', 'unknown')
                            priority = item.get('priority', 999)
                            episode_list.append({
                                'name': item['name'],
                                'ident': item['ident'],
                                'size': item.get('size', '0'),
                                'source': source_info,
                                'priority': priority
                            })
                        else:
                            # Pokud už máme 8 verzí, přeskoč
                            continue
                        
                        # Debug: log přijaté epizody (zvýšený limit pro debug)
                        if accepted_count <= 50 or (season_num == 1 and episode_num <= 10):
                            xbmc.log(f'ACCEPTED S{season_num:02d}E{episode_num:02d}: {item["name"][:80]}', level=xbmc.LOGINFO)
                    else:
                        filtered_count += 1
                        xbmc.log(f'Tshare Series Manager: Filtered out: {item["name"]} (S{season_num}E{episode_num})', level=xbmc.LOGDEBUG)
            
            xbmc.log(f'Tshare Series Manager: Processing complete - Processed: {processed_count}, Accepted: {accepted_count}, Filtered: {filtered_count}', level=xbmc.LOGINFO)
            
            # DŮLEŽITÉ DEBUG INFO pro sledování limitů
            final_elapsed = time.time() - start_time
            total_episodes_found = sum(len(season) for season in series_data['seasons'].values())
            xbmc.log(f'SEARCH STATS: Time={final_elapsed:.1f}s, Seasons={len(series_data["seasons"])}, Episodes={total_episodes_found}, API_results={len(all_results)}', level=xbmc.LOGWARNING)
            
            # Originaltitle logika už byla provedena na začátku funkce
            
            xbmc.log(f'Tshare Series Manager: Final seasons before save: {list(series_data["seasons"].keys())}', level=xbmc.LOGINFO)
            
            # Sort episodes by enhanced priority (merge priority + Czech preference + size)
            czech_count = 0
            english_count = 0
            for season in series_data['seasons'].values():
                for episode_data in season.values():
                    # Debug: spočítej zdroje před řazením
                    for ep in episode_data['episodes']:
                        if ep.get('source') == 'czech':
                            czech_count += 1
                        elif ep.get('source') == 'english':
                            english_count += 1
                    episode_data['episodes'] = self._sort_streams(episode_data['episodes'], series_name)
            
            xbmc.log(f'AUTO-MERGE final stats: Czech streams={czech_count}, English streams={english_count}', level=xbmc.LOGINFO)
            
            # OPRAVA: ZACHOVEJ 'priority' metadata (česká priorita) - potřebné pro správné řazení
            # Vyčisti pouze 'source' debug informace před uložením
            for season in series_data['seasons'].values():
                for episode_data in season.values():
                    for ep in episode_data['episodes']:
                        ep.pop('source', None)
                        # DŮLEŽITÉ: ep.pop('priority', None) - NEMAZAT! Zachovat pro sort_streams
            
            # Ulož originaltitle do metadat pro budoucí použití
            if originaltitle and originaltitle != series_name:
                series_data['originaltitle'] = originaltitle
                xbmc.log(f'Series Manager: Saving originaltitle "{originaltitle}" to series data', level=xbmc.LOGINFO)
            
            # Save the series data
            self._save_series_data(series_name, series_data)
            # Ulož i do cache s originaltitle pro sjednocení
            self.save_series_cache(series_name, series_data, originaltitle)
            return series_data
        except Exception as e:
            xbmc.log(f'Error in search_series: {str(e)}', level=xbmc.LOGERROR)
            return None
    
    # Helper: normalize filename to a comparable key (for dedup)
    def _normalize_key(self, name):
        try:
            n = unidecode.unidecode(name or '').lower()
            # remove common quality / lang tokens
            n = re.sub(r'\b(uhd|4k|2160p|1080p|720p|480p|hdr|x265|h265|x264|h264|hevc|dvdrip|brrip|webrip|web-dl|bluray|remux)\b', ' ', n)
            n = re.sub(r'\b(cz|czech|czdab|dabing|sk|slovak|tit|sub|subs|czsub|cz-tit)\b', ' ', n)
            # remove dots/underscores/dashes and years
            n = re.sub(r'\b(19|20)\d{2}\b', ' ', n)
            n = re.sub(r'[^a-z0-9]+', '', n)
            return n.strip()
        except Exception:
            return (name or '').strip().lower()

    # Helper: pick better result (by size desc)
    def _prefer_better(self, current, candidate):
        def _sz(it):
            try:
                return int(it.get('size') or '0')
            except Exception:
                return 0
        return candidate if _sz(candidate) > _sz(current) else current

    # Formát velikosti v MB/GB
    def _format_size(self, size_value):
        try:
            size = int(size_value or 0)
        except Exception:
            return ''
        if size <= 0:
            return ''
        gb = size / float(1024 ** 3)
        if gb >= 1:
            return f'{gb:.2f} GB'
        mb = size / float(1024 ** 2)
        return f'{mb:.0f} MB'

    # Vyčistí text na slovní název epizody z názvu souboru
    def _clean_title(self, raw_name, series_name):
        try:
            name = str(raw_name or '')
            # odstranění přípon a tagů v závorkách
            name = re.sub(r'\.[a-z0-9]{2,4}$', '', name, flags=re.I)
            name = re.sub(r'[\[\(\{].*?[\]\)\}]', ' ', name)
            # odstranit epizodní patterny
            patts = [
                r'[Ss]\d{1,2}[Ee]\d{1,2}',
                r'\b\d{1,2}x\d{1,2}\b',
                r'\b[Ee][Pp]?\s?\d{1,2}\b',
                r'\b\d{1,2}\s*d[íi]l\b',
                r'\b\d{1,2}\.\s*d[íi]l\b',
                r'\b\d{1,2}\.\s*cast\b',
                r'\bcast\s*\d{1,2}\b',
                r'\bseason\s*\d{1,2}\b',
                r'\bepisode\s*\d{1,2}\b',
            ]
            for p in patts:
                name = re.sub(p, ' ', name, flags=re.I)
            # odstranit kvalitu/jazyk/codec tagy
            name = re.sub(
                r'\b(uhd|4k|2160p|1080p|720p|480p|hdr|x265|h265|x264|h264|hevc|dvdrip|brrip|webrip|web[-_. ]?dl|bluray|remux|aac|mp3|dts|atmos|10bit|10b|cz|czech|czdab|dabing|sk|slovak|tit|sub|subs|czsub|cz[-_. ]?tit|c4u)\b',
                ' ',
                name,
                flags=re.I
            )
            # odstranit klíčová slova názvu seriálu
            for kw in self._series_keywords(series_name):
                name = re.sub(rf'\b{re.escape(kw)}\b', ' ', name, flags=re.I)
            # sjednotit oddělovače
            name = re.sub(r'[._\-]+', ' ', name)
            name = re.sub(r'\s+', ' ', name).strip(' -–—\u2022').strip()
            # fallback pokud nic nezůstalo
            return name or str(raw_name or '').strip()
        except Exception:
            return str(raw_name or '').strip()

    # Sestaví jednotný název: "Díl X — <slovní název> • <velikost>"
    def _build_episode_label(self, series_name, raw_stream_name, size_value, season=None, episode=None):
        title = self._clean_title(raw_stream_name, series_name)
        # prefix "Díl X —" pokud známe číslo epizody
        prefix = ''
        try:
            if episode is not None:
                prefix = f'Díl {int(str(episode))} — '
        except Exception:
            prefix = ''
        size_str = self._format_size(size_value)
        base = (prefix + title).strip() if title else (prefix[:-3] if prefix.endswith(' — ') else (raw_stream_name or ''))
        return base + (f' • {size_str}' if size_str else '')



    def _sort_by_year_preference(self, items):
        """Řadí výsledky podle velikosti souboru"""
        def _size(item):
            try:
                return int(item.get('size') or '0')
            except (ValueError, TypeError):
                return 0
        return sorted(items, key=lambda it: -_size(it))

    def _perform_search(self, search_query, api_function, token, max_retries=2):
        """Perform the actual search using the provided API function with pagination and retry logic + in-memory cache"""
        # Serve from cache if available
        if search_query in getattr(self, '_query_cache', {}):
            results = list(self._query_cache[search_query])
            return self._sort_by_year_preference(results)

        all_results = []
        limit = 100   # Zvýšeno pro lepší pokrytí
        offset = 0
        max_pages = 15  # Zvýšeno na 15 × 100 = 1500 výsledků max pro komplexnější seriály
        current_page = 0

        while current_page < max_pages:
            retry_count = 0
            while retry_count < max_retries:
                try:
                    response = api_function('search', {
                        'what': search_query,
                        'category': 'video',
                        'sort': '',  # Výchozí řazení místo 'recent' pro lepší pokrytí epizod
                        'limit': limit,
                        'offset': offset,
                        'wst': token,
                        'maybe_removed': 'true'
                    })
                    if not response or not response.content:
                        retry_count += 1
                        xbmc.sleep(300)
                        continue
                    try:
                        xml = ET.fromstring(response.content)
                        status = xml.find('status')
                        if status is None or status.text != 'OK':
                            break
                        results_in_page = 0
                        for file in xml.iter('file'):
                            item = {}
                            for elem in file:
                                item[elem.tag] = elem.text
                            if item:
                                all_results.append(item)
                                results_in_page += 1
                                # EMERGENCY EXIT: příliš mnoho výsledků (zvýšeno pro velké série)
                                if len(all_results) >= 2000:
                                    xbmc.log(f'TShare: Emergency exit - too many results ({len(all_results)})', xbmc.LOGWARNING)
                                    self._query_cache[search_query] = list(all_results)
                                    return self._sort_by_year_preference(all_results)
                        if results_in_page < limit:
                            # Cache before returning
                            self._query_cache[search_query] = list(all_results)
                            return self._sort_by_year_preference(all_results)
                        break
                    except ET.ParseError:
                        if retry_count == max_retries - 1:
                            self._query_cache[search_query] = list(all_results)
                            return self._sort_by_year_preference(all_results)
                        retry_count += 1
                        xbmc.sleep(300)
                except Exception:
                    if retry_count == max_retries - 1:
                        self._query_cache[search_query] = list(all_results)
                        return self._sort_by_year_preference(all_results)
                    retry_count += 1
                    xbmc.sleep(300)
            offset += limit
            current_page += 1

        # Cache full result (surová data), řazení až při návratu
        self._query_cache[search_query] = list(all_results)
        return self._sort_by_year_preference(all_results)

    def _merge_search_results(self, czech_results, english_results, series_name):
        """Sloučí výsledky s prioritou pro české názvy - OPRAVA: Použij správné series_name pro každý zdroj"""
        from collections import defaultdict
        
        # Mapa epizod: (season, episode) -> [seznam_streamů]
        episode_map = defaultdict(list)
        
        # Získej originaltitle pro anglické výsledky
        originaltitle = self._get_originaltitle(series_name)
        
        xbmc.log(f'Merge: Czech results={len(czech_results)}, English results={len(english_results)}, originaltitle="{originaltitle}"', level=xbmc.LOGINFO)
        
        # 1. ZPRACUJ ČESKÉ VÝSLEDKY (priorita 1) - používej český název
        czech_episodes = 0
        for item in czech_results:
            season, episode = self._detect_episode_info(item['name'], series_name)
            if season and episode:
                key = (season, episode)
                episode_map[key].append({**item, 'source': 'czech', 'priority': 1})
                czech_episodes += 1
        
        # 2. PŘIDEJ ANGLICKÉ VÝSLEDKY (priorita 2) - používej originaltitle
        english_episodes = 0
        english_new = 0
        for item in english_results:
            # OPRAVA: Použij originaltitle pro detekci anglických epizod
            season, episode = self._detect_episode_info(item['name'], originaltitle or series_name)
            if season and episode:
                key = (season, episode)
                if key not in episode_map:
                    english_new += 1  # Nová epizoda jen z anglického searche
                episode_map[key].append({**item, 'source': 'english', 'priority': 2})
                english_episodes += 1
        
        # 3. SEŘAĎ každou epizodu podle priority (české první) a velikosti
        for episode_streams in episode_map.values():
            episode_streams.sort(key=lambda x: (x['priority'], -int(x.get('size', '0'))))
        
        # Převeď zpět na plochý seznam pro kompatibilitu
        merged_results = []
        for streams in episode_map.values():
            merged_results.extend(streams)
        
        xbmc.log(f'Merge complete: Czech eps={czech_episodes}, English eps={english_episodes} (new={english_new}), Total={len(merged_results)}', level=xbmc.LOGINFO)
        return merged_results

    def _perform_multi_search(self, series_name, api_function, token):
        """Fáze 1: jednoduchý dotaz s AGRESIVNÍ RANOU filtrací (Webshare má hloupé vyhledávání)"""
        search_queries = [series_name.strip()]
        
        # Získej klíčová slova pro ranou filtraci
        keywords = self._series_keywords(series_name)
        xbmc.log(f'Tshare Series Manager: _perform_multi_search using query: "{search_queries[0]}"', level=xbmc.LOGINFO)
        xbmc.log(f'Tshare Series Manager: Keywords for STRICT filtering: {keywords}', level=xbmc.LOGINFO)
        
        all_results = []
        seen_idents = set()
        grouped = {}
        from collections import defaultdict
        season_coverage = defaultdict(set)
        
        rejected_count = 0  # Počítadlo odmítnutých
        
        def register_item(item):
            name = item.get('name') or ''
            key = self._normalize_key(name)
            if not key:
                return False
            if key in grouped:
                best = self._prefer_better(grouped[key], item)
                if best is not grouped[key]:
                    grouped[key] = best
                    return True
                return False
            grouped[key] = item
            return True
            
        def update_coverage(item):
            try:
                fn = item.get('name') or ''
                s, e = self._detect_episode_info(fn, series_name)
                if s is not None and e is not None:
                    season_coverage[str(s)].add(int(e))
            except Exception:
                pass
                
        def early_filter(item_name):
            """AGRESIVNÍ RANÁ FILTRACE: Webshare vrací i 1-slovné shody, musíme být přísní!"""
            nonlocal rejected_count
            
            if not keywords:
                return True  # Nemáme klíčová slova, nemůžeme filtrovat
            
            # Normalizuj název souboru
            normalized = unidecode.unidecode(item_name or '').lower()
            normalized = re.sub(r'[^a-z0-9 ]+', ' ', normalized).replace('  ', ' ').strip()
            tokens = set(normalized.split())
            tokens_list = normalized.split()  # Seznam pro kontrolu vzdálenosti
            
            # Počet shod klíčových slov
            matches = 0
            matched_keywords = []
            keyword_positions = {}  # Pozice každého klíčového slova
            
            for k in keywords:
                found_at = None
                if k in tokens or k + 's' in tokens or (k.endswith('s') and k[:-1] in tokens):
                    matches += 1
                    matched_keywords.append(k)
                    # Najdi pozici
                    for i, token in enumerate(tokens_list):
                        if k == token or k + 's' == token or (k.endswith('s') and k[:-1] == token):
                            found_at = i
                            break
                    if found_at is not None:
                        keyword_positions[k] = found_at
            
            # KRITÉRIUM 1: Pro VŠECHNY názvy (krátké i dlouhé) vyžaduj VŠECHNA klíčová slova!
            # Důvod: Webshare vrací i 1-slovné shody, takže musíme být maximálně přísní
            if matches < len(keywords):
                if rejected_count < 10:  # Log prvních 10 odmítnutí pro debug
                    xbmc.log(f'Early filter REJECT: "{item_name[:60]}" - matched only {matched_keywords} out of {keywords}', level=xbmc.LOGDEBUG)
                rejected_count += 1
                return False
            
            # KRITÉRIUM 2: Pro krátké názvy (1-2 slova) - speciální kontrola
            if len(keywords) == 2:
                # Speciální případ: jedno klíčové slovo je "v" (může být římská číslice)
                if 'v' in keywords:
                    v_idx = keyword_positions.get('v')
                    other_keyword = [k for k in keywords if k != 'v'][0]
                    other_idx = keyword_positions.get(other_keyword)
                    
                    if v_idx is not None and other_idx is not None:
                        # Zkontroluj, jestli "v" není součást římské číslice (stojí izolovaně nebo za číslem)
                        # Příklad: "Star Trek Nová generace V (23)" - "V" je římská číslice, NE součást názvu
                        # Příklad: "Generace V S01E05" - "V" JE součást názvu
                        
                        # Kontrola: pokud před nebo za "v" je číslo, pravděpodobně je to římská číslice
                        if v_idx > 0 and tokens_list[v_idx - 1].isdigit():
                            # "... generace V (23)" - odmítnout
                            if rejected_count < 10:
                                xbmc.log(f'Early filter REJECT: "{item_name[:60]}" - "v" looks like Roman numeral (after digit)', level=xbmc.LOGDEBUG)
                            rejected_count += 1
                            return False
                        
                        if v_idx < len(tokens_list) - 1 and re.match(r'^\(?\d+\)?$', tokens_list[v_idx + 1]):
                            # "... generace V (23)" - odmítnout
                            if rejected_count < 10:
                                xbmc.log(f'Early filter REJECT: "{item_name[:60]}" - "v" looks like Roman numeral (before digit)', level=xbmc.LOGDEBUG)
                            rejected_count += 1
                            return False
                        
                        # Kontrola vzdálenosti - klíčová slova musí být blízko (ale ne PŘÍLIŠ daleko)
                        distance = abs(v_idx - other_idx)
                        # Pro názvy jako "Star Trek Nová generace" je vzdálenost mezi "nova" a "generace" = 1 (OK)
                        # ale pro "Generace V" je vzdálenost = 1 (také OK), takže musíme být chytřejší
                        
                        # Pokud je vzdálenost > 2 A před/za "v" jsou jiná slova než klíčové, pravděpodobně to není shoda
                        if distance > 2:
                            # Zkontroluj, jestli mezi klíčovými slovy jsou jiná významná slova
                            min_idx = min(v_idx, other_idx)
                            max_idx = max(v_idx, other_idx)
                            between_words = tokens_list[min_idx + 1:max_idx]
                            # Pokud mezi nimi jsou 2+ slova, pravděpodobně nejde o správný název
                            if len(between_words) >= 2:
                                if rejected_count < 10:
                                    xbmc.log(f'Early filter REJECT: "{item_name[:60]}" - keywords too far ({distance} tokens, {len(between_words)} words between)', level=xbmc.LOGDEBUG)
                                rejected_count += 1
                                return False
                
                else:
                    # Obecná kontrola vzdálenosti pro 2-slovné názvy (bez "v")
                    k1_idx = keyword_positions.get(keywords[0])
                    k2_idx = keyword_positions.get(keywords[1])
                    
                    if k1_idx is not None and k2_idx is not None:
                        distance = abs(k1_idx - k2_idx)
                        if distance > 3:
                            if rejected_count < 10:
                                xbmc.log(f'Early filter REJECT: "{item_name[:60]}" - keywords too far ({distance} tokens apart)', level=xbmc.LOGDEBUG)
                            rejected_count += 1
                            return False
            
            return True
        
        def should_stop():
            return False
            
        for query in search_queries:
            xbmc.log(f'Tshare Series Manager: Searching for "{query}"', level=xbmc.LOGINFO)
            results = self._perform_search(query, api_function, token)
            xbmc.log(f'Tshare Series Manager: Results for "{query}": {len(results)} (before filtering)', level=xbmc.LOGINFO)
            
            filtered_count = 0
            for item in results:
                ident = item.get('ident')
                item_name = item.get('name') or ''
                
                # Aplikuj early_filter
                if not early_filter(item_name):
                    continue  # Skip rejected items
                
                filtered_count += 1
                ident = item.get('ident')
                if not ident or ident in seen_idents:
                    continue
                
                added_or_improved = register_item(item)
                if added_or_improved:
                    seen_idents.add(ident)
                    update_coverage(item)
            
            # Debug info
            total_eps_debug = sum(len(v) for v in season_coverage.values())
            s1_debug = len(season_coverage.get('1', set()))
            s2_debug = len(season_coverage.get('2', set()))
            xbmc.log(f'Tshare Series Manager: Query "{query}" - API returned: {len(results)}, After filter: {filtered_count}, Rejected: {rejected_count}, Unique files: {len(grouped)}, Episodes: S1={s1_debug}, S2={s2_debug}, Total={total_eps_debug}', level=xbmc.LOGINFO)
            if should_stop():
                break
                
        all_results = list(grouped.values())
        final_total = sum(len(v) for v in season_coverage.values())
        final_s1 = len(season_coverage.get('1', set()))
        final_s2 = len(season_coverage.get('2', set()))
        xbmc.log(f'Tshare Series Manager: Final results for "{series_name}": {len(all_results)} files (rejected {rejected_count}), S1={final_s1} eps, S2={final_s2} eps, Total={final_total} eps', level=xbmc.LOGINFO)
        return all_results

    # Uvolněné limity pro detekci S/E (méně false-negative)
    def _detect_episode_info(self, filename, series_name=None):
        """Try to detect season and episode numbers from filename using learned patterns first, then fallback.
        VYLEPŠENO: Detekce římských číslic i bez pattern learneru.
        """
        cleaned = unidecode.unidecode(filename).lower()
        # Pattern learner jen jako doplněk, ne primární metoda
        pattern_learner_result = None
        try:
            season, episode = self.pattern_learner.detect_episode(filename)
            if season and episode:
                pattern_learner_result = (season, episode)
        except Exception as e:
            xbmc.log(f"Tshare: Chyba v pattern learner: {e}", level=xbmc.LOGWARNING)
        # Nejprve zkus regexy pro římské číslice explicitně (vyšší priorita)
        roman_patterns = [
            r'-([ivxlc]+)-(\d+)',         # -iii-43
            r'_([ivxlc]+)_\(?(\d+)\)?',   # _iii_(15)
            r'\.([ivxlc]+)\.(\d+)',       # .iii.15
            r'\s([ivxlc]+)\s\(?(\d+)\)?', # iii (15)
        ]
        for pattern in roman_patterns:
            match = re.search(pattern, cleaned)
            if match:
                roman = match.group(1).lower()
                episode = int(match.group(2))
                season = ROMAN_TO_ARABIC.get(roman)
                if season and 1 <= season <= 50 and 1 <= episode <= 100:
                    # Nauč se tento vzor (přidá do learned_patterns.json) včetně patternu
                    self._learn_successful_pattern(filename, season, episode, series_name, pattern=pattern)
                    return season, episode
        for i, pattern in enumerate(EPISODE_PATTERNS):
            match = re.search(pattern, cleaned)
            if match:
                groups = match.groups()
                try:
                    if len(groups) == 2:
                        season_str = groups[0].lower()
                        if season_str in ROMAN_TO_ARABIC:
                            season = ROMAN_TO_ARABIC[season_str]
                            episode = int(groups[1])
                            if 1 <= season <= 50 and 1 <= episode <= 100:
                                # self._learn_successful_pattern(filename, season, episode, series_name)  # stále vypnuto
                                return season, episode
                        else:
                            season = int(groups[0])
                            episode = int(groups[1])
                            if 1 <= season <= 50 and 1 <= episode <= 100:
                                # self._learn_successful_pattern(filename, season, episode, series_name)  # stále vypnuto
                                return season, episode
                    elif len(groups) == 1:
                        episode = int(groups[0])
                        if 1 <= episode <= 100:
                            # self._learn_successful_pattern(filename, 1, episode, series_name)  # stále vypnuto
                            return 1, episode
                except ValueError:
                    continue
        # Nově: detekce samostatné číslovky (1–99) v názvu, pokud jsou splněna klíčová slova
        # Použij správný series_name místo filename pro keywords
        keywords = self._series_keywords(series_name) if series_name else self._series_keywords(filename)
        norm_fn = re.sub(r'[^a-z0-9 ]', ' ', cleaned).replace('  ', ' ').strip()
        fn_tokens = set(norm_fn.split())
        # Pokud jsou v názvu klíčová slova seriálu (KONZERVATIVNÍ pro přesnost)
        if keywords:
            # PŘÍSNÉ MINIMUM - zabránění false positive
            if len(keywords) == 1:
                required = 1  # Single word: "Simpsonovi" → potřeba 1 hit
            else:
                required = max(2, int(round(0.6 * len(keywords))))  # Multi-word: 60% klíčových slov (přísnější)
                
            hits = sum(1 for k in keywords if k in fn_tokens)
            if hits >= required:
                # Hledej samostatné číslo 1–100
                num_match = re.search(r'\b(\d{1,3})\b', norm_fn)
                if num_match:
                    episode = int(num_match.group(1))
                    if 1 <= episode <= 100:
                        return 1, episode
        
        # Fallback: použij pattern learner výsledek, pokud standardní metody selhaly
        if pattern_learner_result:
            return pattern_learner_result
            
        return None, None

    def _learn_successful_pattern(self, filename, season, episode, series_name, pattern=None):
        """Naučí se úspěšný vzor pro budoucí rozpoznávání, volitelně s patternem"""
        try:
            self.pattern_learner.learn_pattern(filename, season, episode, series_name, pattern=pattern)
        except Exception as e:
            xbmc.log(f"Tshare: Chyba při učení vzoru: {e}", level=xbmc.LOGWARNING)

    def _create_season_label(self, season_num, episode_count, series_name):
        """Vytvoří chytrý label pro sezónu s rozlišením klasických a římských"""
        try:
            season_int = int(season_num)
            
            # 🎯 DETEKCE ŘÍMSKÝCH SEZÓN (100+)
            if season_int >= 100:
                # Římská sezóna - mapuj zpět na římské číslo
                original_roman = season_int - 100
                arabic_to_roman = {
                    1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 
                    6: 'VI', 7: 'VII', 8: 'VIII', 9: 'IX', 10: 'X'
                }
                roman_num = arabic_to_roman.get(original_roman, str(original_roman))
                return f'[COLOR gold]Řada {roman_num}[/COLOR] — {episode_count} dílů'
            
            # Mapování na římské číslice pro klasické sezóny 
            arabic_to_roman = {
                1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 
                6: 'VI', 7: 'VII', 8: 'VIII', 9: 'IX', 10: 'X'
            }
            
            # Detekce typu sezóny na základě obsahu dílů
            season_data = self.load_series_data(series_name)
            if season_data and 'seasons' in season_data:
                season_episodes = season_data['seasons'].get(season_num, {})
                
                # Zkontroluj vzory názvů v této sezóně  
                roman_pattern_count = 0
                classic_pattern_count = 0
                
                for episode_data in season_episodes.values():
                    episodes_list = episode_data.get('episodes', [])
                    for episode in episodes_list:
                        filename = episode.get('name', '').lower()
                        
                        # Detekce římských vzorů (obsahuje -ii-, -iii-, apod.)
                        if re.search(r'-[ivxlc]+-\d+', filename):
                            roman_pattern_count += 1
                        # Detekce klasických vzorů (s01e01, 1x01, apod.)  
                        elif re.search(r'(s\d+e\d+|\d+x\d+)', filename):
                            classic_pattern_count += 1
                
                # Rozhodnutí na základě převažujícího vzoru
                xbmc.log(f"Tshare DEBUG: Season {season_num} analysis - Roman: {roman_pattern_count}, Classic: {classic_pattern_count}", level=xbmc.LOGINFO)
                
                if roman_pattern_count > classic_pattern_count:
                    # Římský styl - přidej římské číslo a zvýraznění
                    roman_num = arabic_to_roman.get(season_int, str(season_int))
                    xbmc.log(f"Tshare DEBUG: Season {season_num} labeled as ROMAN ({roman_num})", level=xbmc.LOGINFO)
                    return f'[COLOR gold]Řada {season_int} ({roman_num})[/COLOR] — {episode_count} dílů'
                else:
                    # Klasický styl
                    xbmc.log(f"Tshare DEBUG: Season {season_num} labeled as CLASSIC", level=xbmc.LOGINFO)
                    return f'Řada {season_int} ({episode_count} dílů)'
                    
        except (ValueError, Exception):
            pass
            
        # Fallback pro neočekávané případy
        return f'Řada {season_num} ({episode_count} dílů)'

    # Klíčová slova ze jména seriálu (bez diakritiky, min. délka 3, bez obecných slov)
    def _series_keywords(self, series_name):
        s = unidecode.unidecode(series_name or '').lower()
        s = re.sub(r'[^a-z0-9 ]+', ' ', s)
        all_words = s.split()
        
        # OPRAVA: Zachovej jednopísmenné tokeny pokud je série krátká (důležité pro "Generace V" apod.)
        # Pro dlouhé série (4+ slova) ignoruj krátká slova
        if len(all_words) <= 3:
            words = [w for w in all_words if len(w) >= 1]  # Zachovej všechna slova včetně jednopísmenných
        else:
            words = [w for w in all_words if len(w) >= 3]  # Standardní filtrování pro dlouhé názvy
        
        stop = {
            'tshare','the','and','und','der','die','das',
            'cz','czech','cesky','sk','slovak',
            'episode','ep','dil','cast','serie','serial','season','sezona','rada'
        }
        keywords = [w for w in words if w not in stop]
        
        # DEBUG LOG
        xbmc.log(f'_series_keywords: "{series_name}" -> all_words={all_words} -> keywords={keywords}', level=xbmc.LOGINFO)
        
        return keywords

    def _get_originaltitle(self, series_name):
        """Získá originaltitle z uložených TMDB dat seriálu"""
        try:
            data = self.load_series_data(series_name)
            if data:
                # Zkus najít originaltitle v metadatech
                originaltitle = data.get('originaltitle')
                if originaltitle and originaltitle != series_name:
                    return originaltitle
        except Exception as e:
            xbmc.log(f'TShare: Error getting originaltitle for {series_name}: {e}', xbmc.LOGWARNING)
        return None

    # Přísná verze: musí sedět klíčová slova názvu seriálu a jasný epizodní pattern
    def _is_likely_episode(self, filename, series_name, season_num, episode_num):
        """Mírnější verze: pokud adaptive search našel epizodu, pravděpodobně je to správné."""
        normalized_filename = unidecode.unidecode(filename or '').lower()
        def normalize(s):
            return re.sub(r'[^a-z0-9 ]', ' ', s).replace('  ', ' ').strip()
        norm_fn = normalize(normalized_filename)

        # 1) RYCHLÁ CACHE pro klíčová slova - zabráníme tisícům volání _series_keywords
        if not hasattr(self, '_keywords_cache'):
            self._keywords_cache = {}
        if series_name not in self._keywords_cache:
            self._keywords_cache[series_name] = self._series_keywords(series_name)
        keywords = self._keywords_cache[series_name]
        
        # 🎯 ORIGINALTITLE SUPPORT: Pokud soubor neobsahuje klíčová slova série, zkus originaltitle
        # Detekuj zda filename obsahuje anglický název místo českého
        fn_tokens = set(norm_fn.split())
        keyword_matches = 0
        for k in keywords:
            if k in fn_tokens or k + 's' in fn_tokens or (k.endswith('s') and k[:-1] in fn_tokens):
                keyword_matches += 1
        
        # Pokud standard keywords nesedí, zkus originaltitle
        if keyword_matches == 0:
            originaltitle = self._get_originaltitle(series_name)
            if originaltitle and originaltitle != series_name:
                originaltitle_keywords = self._series_keywords(originaltitle)
                xbmc.log(f'_is_likely_episode: Trying originaltitle keywords {originaltitle_keywords} for {filename[:50]}', level=xbmc.LOGDEBUG)
                
                # Použij originaltitle keywords místo původních
                keywords = originaltitle_keywords
                keyword_matches = 0
                for k in keywords:
                    if k in fn_tokens or k + 's' in fn_tokens or (k.endswith('s') and k[:-1] in fn_tokens):
                        keyword_matches += 1
        fn_tokens = set(norm_fn.split())
        if keywords:
            # FLEXIBILNÍ MATCHING: přesná shoda, plural/singular, zkrácené verze
            keyword_matches = 0
            for k in keywords:
                # Zkus přesnou shodu
                if k in fn_tokens:
                    keyword_matches += 1
                # Zkus plural/singular (s/bez 's' na konci)
                elif k + 's' in fn_tokens or (k.endswith('s') and k[:-1] in fn_tokens):
                    keyword_matches += 1
                # Zkrácené verze: pokud je klíčové slovo delší než 5 znaků,
                # povolí zkrácení o 1-2 znaky na konci (velkolep ~ velkolepe)
                elif len(k) > 5:
                    for token in fn_tokens:
                        if len(token) >= 5 and k.startswith(token) and len(k) - len(token) <= 2:
                            keyword_matches += 1
                            break
            
            # ZPŘÍSNĚNÁ LOGIKA: Lepší rozlišení mezi sériemi
            if len(keywords) == 1:
                required_matches = 1  # Jedno slovo -> stačí 1 shoda
            elif len(keywords) == 2:
                required_matches = 2  # Dvě slova -> OBĚ musí sedět (přísné ale správné)
            elif len(keywords) == 3:
                required_matches = 2  # Tři slova -> min. 2 shody (67%)
            else:
                required_matches = max(2, int(round(0.5 * len(keywords))))  # 4+ slov -> min. 50% (mírnější)
            
            # NOVÉ: EXTRA ZPŘÍSNĚNÍ pro krátké názvy (1-2 klíčová slova)
            # Příklad: "Generace V" má keywords=['generace', 'v'], musí sedět OBĚ
            if len(keywords) <= 2:
                # Pro krátké názvy vyžaduj VŠECHNY klíčová slova + dodatečnou kontrolu
                if keyword_matches < len(keywords):
                    xbmc.log(f'_is_likely_episode: REJECT {filename} - krátký název vyžaduje všechna klíčová slova. Found {keyword_matches}/{len(keywords)}. Keywords: {keywords}', level=xbmc.LOGDEBUG)
                    return False
                
                # Dodatečná kontrola: klíčová slova musí být blízko sebe (max 3 tokeny mezi nimi)
                if len(keywords) == 2:
                    fn_tokens_list = norm_fn.split()  # Seznam pro indexování
                    k1_idx = None
                    k2_idx = None
                    for i, token in enumerate(fn_tokens_list):
                        if keywords[0] == token or (keywords[0] + 's' == token) or (keywords[0].endswith('s') and keywords[0][:-1] == token):
                            k1_idx = i
                        if keywords[1] == token or (keywords[1] + 's' == token) or (keywords[1].endswith('s') and keywords[1][:-1] == token):
                            k2_idx = i
                    
                    if k1_idx is not None and k2_idx is not None:
                        distance = abs(k1_idx - k2_idx)
                        if distance > 4:  # Pokud jsou klíčová slova příliš daleko, pravděpodobně to není ta série
                            xbmc.log(f'_is_likely_episode: REJECT {filename} - klíčová slova příliš vzdálená ({distance} tokenů). Keywords: {keywords}', level=xbmc.LOGDEBUG)
                            return False
            
            # DODATEČNÁ KONTROLA: Pokud série má víc než 2 slova, zkontroluj specifičnost
            if len(keywords) >= 3 and keyword_matches >= required_matches:
                # Pro série jako "Život s walterovic kluky" vyžaduj alespoň jedno specifické slovo
                common_words = {'zivot', 'life', 'muj', 'my', 'the', 'a', 'an', 'of', 'with', 's', 'se'}
                specific_matches = 0
                for k in keywords:
                    if k not in common_words and (k in fn_tokens or 
                        any(token for token in fn_tokens if len(token) >= 5 and k.startswith(token) and len(k) - len(token) <= 2)):
                        specific_matches += 1
                
                # Vyžaduj alespoň jedno specifické slovo
                if specific_matches == 0:
                    xbmc.log(f'_is_likely_episode: REJECT {filename} - pouze obecná slova. Keywords: {keywords}, tokens: {sorted(fn_tokens)}', level=xbmc.LOGDEBUG)
                    return False
            
            if keyword_matches < required_matches:
                xbmc.log(f'_is_likely_episode: REJECT {filename} - insufficient keyword match. Found {keyword_matches}/{len(keywords)}, required {required_matches}. Keywords: {keywords}', level=xbmc.LOGDEBUG)
                return False

        # 2) Preferuj jasné patterny, ale nejsou povinné
        s_e_pattern = f"s{season_num:02d}e{episode_num:02d}"
        x_x_pattern = f"{season_num}x{episode_num:02d}"
        ep_pattern1 = f"ep{episode_num:02d}"
        ep_pattern2 = f"e{episode_num:02d}"
        dot_pattern = f"{season_num}.{episode_num:02d}"
        patterns = [s_e_pattern, x_x_pattern, ep_pattern1, ep_pattern2, dot_pattern]
        if any(p in norm_fn for p in patterns):
            return True

        # 3) Inteligentní finální kontrola
        if keywords:
            keyword_matches = sum(1 for k in keywords if k in fn_tokens)
            
            # ZMĚNA: Stejná logika jako výše - pro 2 slova vyžadovat obě shody
            if len(keywords) == 1:
                required_matches = 1  # Jedno slovo -> stačí 1 shoda
            elif len(keywords) == 2:
                required_matches = 2  # Dvě slova -> obě musí sedět
            else:
                required_matches = max(2, int(round(0.5 * len(keywords))))  # 3+ slov -> min. 50%
            
            if keyword_matches >= required_matches:
                # Kontrola že to není úplně jiný seriál
                unwanted_patterns = ['trailer', 'sample', 'preview', 'subtitle', 'titulky']
                if not any(pattern in norm_fn for pattern in unwanted_patterns):
                    return True

        return False

    # Zjistí, zda má seriál/řada chybějící díly (mezery v intervalu 1..max)
    def has_missing(self, series_name, season=None):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}

            def season_has_gap(eps_dict):
                nums = sorted(int(n) for n in eps_dict.keys() if str(n).isdigit())
                if not nums:
                    return False
                mx = max(nums)
                # chybí-li cokoliv mezi 1..max, je mezera
                return any(str(i) not in eps_dict for i in range(1, mx + 1))

            if season is None:
                for _, eps in seasons.items():
                    if season_has_gap(eps):
                        return True
                return False
            else:
                return season_has_gap(seasons.get(str(season)) or {})
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: has_missing error: {e}', level=xbmc.LOGERROR)
            return False

    def migrate_old_cache_if_needed(self):
        """Migrace starých cache souborů na nový systém s kanonickými klíči"""
        try:
            cache_dir = self.get_cache_dir()
            if not os.path.exists(cache_dir):
                return
                
            migrated_count = 0
            for filename in os.listdir(cache_dir):
                if not filename.endswith('.json'):
                    continue
                    
                old_path = os.path.join(cache_dir, filename)
                try:
                    with io.open(old_path, 'r', encoding='utf8') as f:
                        cache_data = json.load(f)
                    
                    series_name = cache_data.get('name')
                    if not series_name:
                        continue
                    
                    # Zkus získat originaltitle z cache dat
                    originaltitle = cache_data.get('originaltitle')
                    
                    # Vytvoř nový kanonický klíč (PRIMÁRNÍ je český název)
                    new_canonical_key = self._get_canonical_cache_key(series_name, originaltitle)
                    new_path = os.path.join(cache_dir, f"{new_canonical_key}.json")
                    
                    # Pokud se nová cesta liší od staré, migrace
                    old_key = filename[:-5]  # odstranit .json
                    if new_canonical_key != old_key and not os.path.exists(new_path):
                        # Zkopíruj do nového umístění
                        with io.open(new_path, 'w', encoding='utf8') as f:
                            json.dump(cache_data, f, indent=2)
                        migrated_count += 1
                        xbmc.log(f'Migrated cache: {old_key} -> {new_canonical_key}', level=xbmc.LOGDEBUG)
                        
                except (IOError, ValueError, json.JSONDecodeError) as e:
                    xbmc.log(f'Error migrating cache file {filename}: {e}', level=xbmc.LOGWARNING)
                    continue
            
            if migrated_count > 0:
                xbmc.log(f'Cache migration completed: {migrated_count} files migrated', level=xbmc.LOGINFO)
                
        except Exception as e:
            xbmc.log(f'Error in cache migration: {e}', level=xbmc.LOGERROR)

    def search_series_originaltitle_only(self, originaltitle, api_function, token):
        """Vyhledej seriál POUZE pomocí originaltitle (anglického názvu)"""
        try:
            xbmc.log(f'SeriesManager: searching ONLY by originaltitle: "{originaltitle}"', level=xbmc.LOGINFO)
            
            series_data = {
                'name': originaltitle,  # Dočasně, bude změněno v hlavní funkci
                'last_updated': xbmc.getInfoLabel('System.Date'),
                'seasons': {}
            }
            
            # Hledej POUZE pomocí originaltitle
            all_results = self._perform_multi_search(originaltitle, api_function, token)
            if not all_results:
                xbmc.log(f'SeriesManager: No results found for originaltitle: "{originaltitle}"', level=xbmc.LOGINFO)
                return None
                
            # Process a organize výsledky
            processed_count = 0
            accepted_count = 0
            MAX_PROCESSED_ITEMS = 800   # Sjednoceno s hlavní search funkcí
            
            for item in all_results:
                if processed_count >= MAX_PROCESSED_ITEMS:
                    xbmc.log(f'SeriesManager: Dosažen limit {MAX_PROCESSED_ITEMS} zpracovaných souborů pro originaltitle "{originaltitle}"', xbmc.LOGINFO)
                    break
                    
                season_num, episode_num = self._detect_episode_info(item['name'], originaltitle)
                
                if season_num is not None and episode_num is not None:
                    processed_count += 1
                    # Použij originaltitle pro kontrolu relevance
                    if self._is_likely_episode(item['name'], originaltitle, season_num, episode_num):
                        accepted_count += 1
                        
                        # Detekce římských čísel (stejná logika jako v search_series)
                        filename_lower = item['name'].lower()
                        roman_match = re.search(r'-([ivx]+)-', filename_lower)
                        
                        if roman_match:
                            roman_numeral = roman_match.group(1)
                            original_roman_season = ROMAN_TO_ARABIC.get(roman_numeral, 1)
                            season_num = 100 + original_roman_season
                            
                        season_num_str = str(season_num)
                        episode_num_str = str(episode_num)
                        
                        if season_num_str not in series_data['seasons']:
                            series_data['seasons'][season_num_str] = {}
                            
                        if episode_num_str not in series_data['seasons'][season_num_str]:
                            series_data['seasons'][season_num_str][episode_num_str] = {'episodes': []}
                            
                        series_data['seasons'][season_num_str][episode_num_str]['episodes'].append({
                            'name': item['name'],
                            'ident': item['ident'],
                            'size': item.get('size', '0')
                        })
                        
                        # Debug: log první několik přijatých epizod
                        if accepted_count <= 10:
                            xbmc.log(f'ACCEPTED (originaltitle) S{season_num}E{episode_num}: {item["name"][:50]}...', level=xbmc.LOGINFO)
            
            xbmc.log(f'SeriesManager originaltitle search: Processed: {processed_count}, Accepted: {accepted_count}', level=xbmc.LOGINFO)
            
            # Řazení epizod podle kvality
            for season in series_data['seasons'].values():
                for episode_data in season.values():
                    episode_data['episodes'] = self._sort_streams(episode_data['episodes'], originaltitle)
            
            xbmc.log(f'SeriesManager originaltitle search final: {len(series_data["seasons"])} seasons found', level=xbmc.LOGINFO)
            return series_data
            
        except Exception as e:
            xbmc.log(f'Error in search_series_originaltitle_only: {str(e)}', level=xbmc.LOGERROR)
            return None

# Pomocná funkce pro tvorbu plugin URL (bez závislosti na Tshare.get_url)
def _plugin_url(**kwargs):
    try:
        import sys
        base = sys.argv[0]
    except Exception:
        base = ''
    try:
        return f'{base}?{urlencode(kwargs, doseq=True)}'
    except TypeError:
        # Fallback bez doseq pro starší Python/Kodi
        return f'{base}?{urlencode(kwargs)}'

# --- UI funkce volané z Tshare.py ---

def create_series_menu(sm, handle):
    """
    Hlavní menu seriálů:
    - Vyhledávání seriálu
    - Seznam uložených seriálů (z DB)
    """
    try:
        # 1) Vyhledávání
        li = xbmcgui.ListItem(label='Vyhledat seriál')
        li.setArt({'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'})
        xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_search'), li, True)

        # 2) Seznam seriálů z DB
        if not os.path.exists(sm.series_db_path):
            xbmcplugin.endOfDirectory(handle)
            return

        for fname in sorted(os.listdir(sm.series_db_path)):
            if not fname.endswith('.json'):
                continue
            try:
                fpath = os.path.join(sm.series_db_path, fname)
                with io.open(fpath, 'r', encoding='utf8') as f:
                    data = json.load(f)
                series_name = data.get('name') or os.path.splitext(fname)[0]
                
                # Načti metadata pokud existují
                metadata = data.get('metadata', {})
                series_poster = metadata.get('poster')
                series_fanart = metadata.get('fanart')
                series_plot = metadata.get('plot', '')
                series_rating = metadata.get('rating')
                series_year = metadata.get('year')
                series_genres = metadata.get('genres', [])
                
                label = series_name

                li = xbmcgui.ListItem(label=label)
                
                # Nastav artwork
                art_dict = {'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'}
                if series_poster:
                    art_dict['poster'] = series_poster
                    art_dict['thumb'] = series_poster
                if series_fanart:
                    art_dict['fanart'] = series_fanart
                
                li.setArt(art_dict)
                
                # Nastav info labels
                info_labels = {
                    'mediatype': 'tvshow',
                    'title': series_name,
                    'tvshowtitle': series_name,
                }
                if series_plot:
                    info_labels['plot'] = series_plot
                if series_rating:
                    info_labels['rating'] = series_rating
                if series_year:
                    info_labels['year'] = int(series_year)
                if series_genres:
                    info_labels['genre'] = ', '.join(series_genres)
                
                li.setInfo('video', info_labels)

                # Připrav přímý URL na další díl (pokud existuje)
                ns, ne, best = sm.get_next_episode(series_name)
                if best:
                    play_url = _plugin_url(
                        action='play',
                        ident=best.get('ident'),
                        name=best.get('name'),
                        series_name=series_name,
                        season=str(ns) if ns is not None else '',
                        episode=str(ne) if ne is not None else '',
                        episode_title=best.get('name')
                    )
                    play_next_cm = ('Přehrát další díl', f'RunPlugin({play_url})')
                else:
                    play_next_cm = ('Přehrát další díl', f'Container.Update({_plugin_url(action="series_detail", series_name=series_name)})')

                # Kontextové menu včetně chybějících (vždy k dispozici na úrovni seriálu)
                cm = [
                    play_next_cm,
                    ('Aktualizovat seriál', f'Container.Update({_plugin_url(action="series_refresh", series_name=series_name)})'),
                ]
                if sm.has_missing(series_name):
                    cm.append(('Hledat chybějící díly', f'Container.Update({_plugin_url(action="search_missing_episodes", series_name=series_name)})'))
                cm.append(('Smazat seriál', f'RunPlugin({_plugin_url(action="delete_series", series_name=series_name)})'))
                li.addContextMenuItems(cm)

                xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_detail', series_name=series_name), li, True)
            except Exception as e:
                xbmc.log(f'SeriesManager menu: skip file {fname}: {e}', level=xbmc.LOGWARNING)

        # 3) Historie
        li = xbmcgui.ListItem(label='Historie seriálů')
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_history'), li, True)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_series_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_seasons_menu_from_data(sm, handle, series_name, series_data):
    """Výpis řad ze zadaných dat (cache)."""
    try:
        seasons = (series_data or {}).get('seasons') or {}
        if not seasons:
            xbmcgui.Dialog().notification('Tshare', 'Pro tento seriál nejsou k dispozici žádné řady', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        xbmc.log(f'Tshare DEBUG: Creating seasons menu for "{series_name}" with seasons: {list(seasons.keys())}', level=xbmc.LOGINFO)

        # Načti TMDB metadata pokud existují
        metadata = series_data.get('metadata', {}) if series_data else {}
        series_poster = metadata.get('poster')
        series_fanart = metadata.get('fanart')
        series_plot = metadata.get('plot', '')
        series_rating = metadata.get('rating')
        series_year = metadata.get('year')
        series_genres = metadata.get('genres', [])

        # Přehrát další díl (přímo přes action=play)
        ns, ne, best = sm.get_next_episode(series_name)
        if best:
            play_next = xbmcgui.ListItem(label='Přehrát další díl')
            play_next.setProperty('IsPlayable', 'true')
            # Přelož special:// cestu a najdi ikonu
            addon_path = translatePath(sm.addon.getAddonInfo('path'))
            play_icon = os.path.join(addon_path, 'resources', 'media', 'play.png')
            if not os.path.exists(play_icon):
                play_icon = 'DefaultVideo.png'
            
            # Použij series poster pokud existuje
            art_dict = {'icon': play_icon, 'thumb': play_icon}
            if series_poster:
                art_dict['poster'] = series_poster
                art_dict['thumb'] = series_poster
            if series_fanart:
                art_dict['fanart'] = series_fanart
            
            play_next.setArt(art_dict)
            try:
                play_next.setIconImage(play_icon)  # kompatibilita se staršími skiny
            except Exception:
                pass
            # ZMĚNA: vlastní ikona přehrávání
            # play_icon = os.path.join(sm.addon.getAddonInfo('path'), 'resource', 'media', 'play.png')
           
            # if os.path.exists(play_icon):
            #     play_next.setArt({'icon': play_icon, 'thumb': play_icon})
            play_url = _plugin_url(
                action='play',
                ident=best.get('ident'),
                name=best.get('name'),
                series_name=series_name,
                season=str(ns) if ns is not None else '',
                episode=str(ne) if ne is not None else '',
                episode_title=best.get('name')
            )
            label_norm = sm._build_episode_label(series_name, best.get('name'), best.get('size'), season=ns, episode=ne)
            # Dříve: play_next.setLabel(f'> Přehrát další díl — {label_norm}')
            play_next.setLabel(f'• [B][COLOR cyan]Přehrát další díl[/COLOR][/B] — {label_norm}')
            xbmcplugin.addDirectoryItem(handle, play_url, play_next, False)

        for season in sorted(seasons.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
            ep_count = len(seasons[season])
            xbmc.log(f'Tshare DEBUG: Creating menu item for season {season} with {ep_count} episodes', level=xbmc.LOGINFO)
            
            # 🎯 VYLEPŠENÉ ZOBRAZENÍ: Přidej římské číslice pro lepší rozlišení
            season_label = sm._create_season_label(season, ep_count, series_name)
            li = xbmcgui.ListItem(label=season_label)
            
            # Nastav artwork - preferuj TMDB poster
            addon_path = translatePath(sm.addon.getAddonInfo('path'))
            season_icon = os.path.join(addon_path, 'resources', 'media', 'season.png')
            if not os.path.exists(season_icon):
                season_icon = 'DefaultTVShows.png'
            
            art_dict = {'icon': season_icon, 'thumb': season_icon}
            if series_poster:
                art_dict['poster'] = series_poster
                art_dict['thumb'] = series_poster
            if series_fanart:
                art_dict['fanart'] = series_fanart
            
            li.setArt(art_dict)
            
            # Nastav info labels pro lepší zobrazení
            info_labels = {
                'mediatype': 'season',
                'tvshowtitle': series_name,
                'season': int(season) if str(season).isdigit() else -1,
            }
            if series_plot:
                info_labels['plot'] = series_plot
            if series_rating:
                info_labels['rating'] = series_rating
            if series_year:
                info_labels['year'] = int(series_year)
            if series_genres:
                info_labels['genre'] = ', '.join(series_genres)
            
            li.setInfo('video', info_labels)
            
            try:
                li.setIconImage(season_icon)  # compatibility with older skins
            except Exception:
                pass
            cm = [
                (f'Aktualizovat řadu {season}', f'Container.Update({_plugin_url(action="series_refresh", series_name=series_name, season=season)})'),
            ]
            if sm.has_missing(series_name, season=season):
                cm.insert(0, (f'Hledat chybějící díly v řadě {season}', f'Container.Update({_plugin_url(action="search_missing_episodes", series_name=series_name, season=season)})'))
            # nově: obnovit chytré řazení pro tuto řadu
            cm.append((f'Obnovit chytré řazení streamů (řada {season})', f'RunPlugin({_plugin_url(action="restore_smart_ordering", series_name=series_name, season=season)})'))
            li.addContextMenuItems(cm)

            # Připrav URL s tmdb_id pokud je dostupné
            season_url_params = {
                'action': 'series_season', 
                'series_name': series_name, 
                'season': season
            }
            tmdb_id = series_data.get('tmdb_id')
            if tmdb_id:
                season_url_params['tmdb_id'] = tmdb_id
            
            xbmcplugin.addDirectoryItem(handle, _plugin_url(**season_url_params), li, True)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_seasons_menu_from_data error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_seasons_menu(sm, handle, series_name, originaltitle=None):
    """Výpis řad načtením z DB."""
    try:
        data = sm.load_series_data(series_name)
        if not data:
            xbmcgui.Dialog().notification('Tshare', 'Data seriálu nenalezena', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        create_seasons_menu_from_data(sm, handle, series_name, data)
    except Exception as e:
        xbmc.log(f'create_seasons_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_episodes_menu(sm, handle, series_name, season, tmdb_id=None):
    """Výpis epizod v dané řadě, položky jsou přehrávatelné (preferovaný/první stream)."""
    try:
        data = sm.load_series_data(series_name) or {}
        seasons = data.get('seasons') or {}
        eps = (seasons.get(str(season)) or {})
        
        # Načti TMDB metadata
        metadata = data.get('metadata', {})
        series_poster = metadata.get('poster')
        series_fanart = metadata.get('fanart')
        series_plot = metadata.get('plot', '')
        
        # Získej tmdb_id z parametru nebo ze série dat
        if not tmdb_id:
            tmdb_id = data.get('tmdb_id')
            
        if not eps:
            xbmcgui.Dialog().notification('Tshare', f'Řada {season} nemá žádné epizody', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        # Akce pro řadu – nahoře, “Hledat chybějící” jen pokud je co dohledat
        li_update = xbmcgui.ListItem(label='Aktualizovat řadu')
        li_update.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li_update.addContextMenuItems([
            ('Obnovit chytré řazení (tato řada)', f'RunPlugin({_plugin_url(action="restore_smart_ordering", series_name=series_name, season=str(season))})')
        ])
        xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_refresh', series_name=series_name, season=str(season)), li_update, True)

        if sm.has_missing(series_name, season=season):
            li_missing = xbmcgui.ListItem(label='Hledat chybějící díly v řadě')
            li_missing.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle, _plugin_url(action='search_missing_episodes', series_name=series_name, season=str(season)), li_missing, True)

        # Prepare addon path for per-item icons (fallback to DefaultVideo.png)
        addon_path = translatePath(sm.addon.getAddonInfo('path'))
        episode_icon_path = os.path.join(addon_path, 'resources', 'media', 'episode.png')
        if not os.path.exists(episode_icon_path):
            episode_icon_path = 'DefaultVideo.png'

        # Přehrát další díl v řadě – přímo přes action=play
        ns, ne, nbest = sm.get_next_episode_in_season(series_name, season)
        if nbest:
            label_norm = sm._build_episode_label(series_name, nbest.get('name'), nbest.get('size'), season=ns, episode=ne)
            play_next_s = xbmcgui.ListItem(label=f'• [B][COLOR cyan]Přehrát další díl v této řadě[/COLOR][/B] — {label_norm}')
            play_next_s.setProperty('IsPlayable', 'true')
            # Přelož special:// cestu a najdi ikonu
            addon_path = translatePath(sm.addon.getAddonInfo('path'))
            play_icon = os.path.join(addon_path, 'resources', 'media', 'play.png')
            if not os.path.exists(play_icon):
                play_icon = os.path.join(addon_path, 'resource', 'media', 'play.png')
            
            art_dict_play = {'icon': play_icon if os.path.exists(play_icon) else 'DefaultVideo.png', 'thumb': play_icon if os.path.exists(play_icon) else 'DefaultVideo.png'}
            if series_poster:
                art_dict_play['poster'] = series_poster
                art_dict_play['thumb'] = series_poster
            if series_fanart:
                art_dict_play['fanart'] = series_fanart
            
            play_next_s.setArt(art_dict_play)
            try:
                if os.path.exists(play_icon):
                    play_next_s.setIconImage(play_icon)  # kompatibilita se staršími skiny
            except Exception:
                pass
            play_next_url_params = {
                'action': 'play',
                'ident': nbest.get('ident'),
                'name': nbest.get('name'),
                'series_name': series_name,
                'season': str(ns) if ns is not None else '',
                'episode': str(ne) if ne is not None else '',
                'episode_title': nbest.get('name')
            }
            # Přidej tmdb_id pro Trakt.tv scrobbling pokud je dostupné
            if tmdb_id:
                play_next_url_params['tmdb_id'] = tmdb_id
            
            play_next_s_url = _plugin_url(**play_next_url_params)
            xbmcplugin.addDirectoryItem(handle, play_next_s_url, play_next_s, False)

        # Získat poslední shlédnutou epizodu kvůli označení
        last_s, last_e = sm.get_last_watched_episode(series_name)
        try:
            last_s = str(last_s) if last_s is not None else None
            last_e = str(last_e) if last_e is not None else None
        except Exception:
            last_s = last_s
            last_e = last_e

        for ep_num in sorted(eps.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
            ep_data = eps[ep_num] or {}
            streams = list(ep_data.get('episodes') or [])
            if not streams:
                continue
            streams = sm._sort_streams(streams, series_name, str(season), str(ep_num))
            best = streams[0]
            is_last_watched = (str(season) == str(last_s) and str(ep_num) == str(last_e))
            base_label = sm._build_episode_label(series_name, best.get('name'), best.get('size'), season=season, episode=ep_num)
            label = f'[COLOR yellow]★shlédnuto[/COLOR] | {base_label}' if is_last_watched else base_label

            li = xbmcgui.ListItem(label=label)
            # Nastav artwork - preferuj TMDB poster
            art_dict_ep = {'icon': episode_icon_path, 'thumb': episode_icon_path}
            if series_poster:
                art_dict_ep['poster'] = series_poster
                art_dict_ep['thumb'] = series_poster
            if series_fanart:
                art_dict_ep['fanart'] = series_fanart
            
            li.setArt(art_dict_ep)
            try:
                li.setIconImage(episode_icon_path)  # compatibility with older skins
            except Exception:
                pass
            li.setProperty('IsPlayable', 'true')
            try:
                info_labels = {
                    'title': base_label,
                    'tvshowtitle': series_name,
                    'season': int(season) if str(season).isdigit() else season,
                    'episode': int(ep_num) if str(ep_num).isdigit() else ep_num,
                    'playcount': 1 if is_last_watched else 0,
                    'overlay': 7 if is_last_watched else 0,
                    'mediatype': 'episode'
                }
                if series_plot:
                    info_labels['plot'] = series_plot
                li.setInfo('video', info_labels)
            except Exception:
                pass

            # rozšířený kontext pro epizodu
            li.addContextMenuItems([
                ('Vybrat jiný stream…', f'RunPlugin({_plugin_url(action="select_stream", series_name=series_name, season=str(season), episode=str(ep_num))})'),
                ('Obnovit chytré řazení streamů (tato řada)', f'RunPlugin({_plugin_url(action="restore_smart_ordering", series_name=series_name, season=str(season))})')
            ])

            url_params = {
                'action': 'play',
                'ident': best.get('ident'),
                'name': best.get('name'),
                'series_name': series_name,
                'season': str(season),
                'episode': str(ep_num),
                'episode_title': best.get('name')
            }
            # Přidej tmdb_id pro Trakt.tv scrobbling pokud je dostupné
            if tmdb_id:
                url_params['tmdb_id'] = tmdb_id
            
            url = _plugin_url(**url_params)
            xbmcplugin.addDirectoryItem(handle, url, li, False)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_episodes_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_series_history_menu(sm, handle):
    """Zobrazení historie přehrávání seriálů."""
    try:
        history = sm.get_series_history()
        if not history:
            xbmcgui.Dialog().notification('Tshare', 'Historie seriálů je prázdná', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        for i, entry in enumerate(history):
            series_name = entry.get('series_name', 'Seriál')
            season = entry.get('season', '?')
            episode = entry.get('episode', '?')
            title = entry.get('episode_title') or f'S{season}E{episode}'

            label = f'{series_name} — S{season}E{episode} — {title}'
            li = xbmcgui.ListItem(label=label)
            li.setProperty('IsPlayable', 'true')

            # Kontext: odstranit z historie (Tshare.delete_series_history očekává history_index)
            li.addContextMenuItems([
                ('Odstranit z historie', f'RunPlugin({_plugin_url(action="delete_series_history", history_index=i, series_label=label)})')
            ])

            # Pokud máme uložený stream_url, přehrát přímo; jinak přehrát přes ident/heuristiku v Tshare
            params = {
                'action': 'play_series_history',
                'series_name': series_name,
                'season': season,
                'episode': episode
            }
            if entry.get('stream_url'):
                params['stream_url'] = entry['stream_url']

            xbmcplugin.addDirectoryItem(handle, _plugin_url(**params), li, False)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_series_history_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)