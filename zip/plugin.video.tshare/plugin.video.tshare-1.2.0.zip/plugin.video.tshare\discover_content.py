# -*- coding: utf-8 -*-
# Module: discover_content
# Author: Tomas for friends
# Created on: 15.12.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import os
import io
import json
import time
import re
import requests # type: ignore
import xbmc  # type: ignore
import xbmcaddon  # type: ignore
from datetime import datetime, timedelta

class DiscoverManager:
    """
    Správce pro objevování nového obsahu s CZ dabingem/titulky
    - Cachování: Filmy 3 dny, Seriály 7 dní
    - Oddělené filmy a seriály
    - TMDB obohacení (postery, rating, popis)
    """
    
    def __init__(self, addon, profile_path):
        self.addon = addon
        self.profile_path = profile_path
        self.cache_file = os.path.join(profile_path, 'discover_cache.json')
        self.movie_cache_duration = 3 * 24 * 3600  # 3 dny v sekundách
        self.series_cache_duration = 7 * 24 * 3600  # 7 dní v sekundách
        
        # CZ klíčová slova pro filtraci
        self.cz_keywords = ['cz', 'czech', 'cesky', 'ceská', 'dabing', 'czaudio', 'czdab', 'titulky']
    
    def get_new_cz_movies(self, force_refresh=False):
        """
        Získá seznam nových filmů s CZ dabingem z Webshare
        
        Args:
            force_refresh: Vynutit refresh i když je platná cache
            
        Returns:
            List filmů s TMDB metadaty
        """
        try:
            # Zkontroluj cache
            if not force_refresh:
                cached_data = self._load_cache()
                if cached_data and 'movies' in cached_data:
                    if time.time() < cached_data.get('movies_expires', 0):
                        xbmc.log('DiscoverManager: Using cached movies data', xbmc.LOGDEBUG)
                        return cached_data['movies']
            
            xbmc.log('DiscoverManager: Fetching new movies from Webshare', xbmc.LOGINFO)
            
            # Aktuální rok
            current_year = datetime.now().year
            
            # Vyhledej na Webshare - PŘÍMO přes API
            token = self.addon.getSetting('token')
            
            xbmc.log(f'DiscoverManager: Searching Webshare for year {current_year}', xbmc.LOGINFO)
            
            # Přímé API volání
            try:
                import Tshare
                response = Tshare.api('search', {
                    'what': str(current_year),
                    'category': 'video',
                    'sort': 'latest',
                    'limit': 500,
                    'offset': 0,
                    'wst': token,
                    'maybe_removed': 'true'
                })
                
                if response is None:
                    xbmc.log('DiscoverManager: API response is None', xbmc.LOGWARNING)
                    return []
                
                # Parse XML response
                from xml.etree import ElementTree as ET
                xml = ET.fromstring(response.content)
                
                if not Tshare.is_ok(xml):
                    xbmc.log(f'DiscoverManager: API returned error: {xml.find("status").text if xml.find("status") is not None else "Unknown"}', xbmc.LOGWARNING)
                    return []
                
                # Extract files
                results = []
                for file_elem in xml.iter('file'):
                    item = Tshare.todict(file_elem)
                    results.append(item)
                
                xbmc.log(f'DiscoverManager: Got {len(results)} raw results from Webshare', xbmc.LOGINFO)
                
            except Exception as e:
                xbmc.log(f'DiscoverManager: Error calling Webshare API: {str(e)}', xbmc.LOGERROR)
                import traceback
                traceback.print_exc()
                return []
            
            # Filtruj pouze filmy (ne seriály) s CZ
            movies = []
            for item in results:
                name = item.get('name', '').lower()
                
                # Musí obsahovat CZ klíčové slovo
                if not any(kw in name for kw in self.cz_keywords):
                    continue
                
                # NESMÍ být seriál (detekce S01E01)
                if self._is_series(item.get('name', '')):
                    continue
                
                # NESMÍ být sport/hudba/awards
                if self._is_excluded_content(item.get('name', '')):
                    continue
                
                movies.append(item)
            
            xbmc.log(f'DiscoverManager: Filtered to {len(movies)} CZ movies from {current_year}', xbmc.LOGINFO)
            
            # Vezmi prvních 100
            top_movies = movies[:100]
            
            # Obohacej z TMDB
            enriched_movies = self._enrich_with_tmdb(top_movies, current_year)
            
            # VYŘAĎ filmy bez TMDB ID (sport, utkání, odpad)
            valid_movies = [m for m in enriched_movies if m.get('tmdb_id')]
            xbmc.log(f'DiscoverManager: {len(enriched_movies)} -> {len(valid_movies)} movies with TMDB ID (removed {len(enriched_movies) - len(valid_movies)} without ID)', xbmc.LOGINFO)
            
            # Deduplikuj podle TMDB ID (vyber nejlepší verzi každého filmu)
            unique_movies = self._deduplicate_movies(valid_movies)
            
            # Ulož do cache
            self._save_cache({'movies': unique_movies}, cache_type='movies')
            
            return unique_movies
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error getting new movies: {str(e)}', xbmc.LOGERROR)
            return []
    
    def get_new_cz_series(self, force_refresh=False):
        """
        Získá seznam nových seriálů s CZ dabingem z Webshare
        
        Args:
            force_refresh: Vynutit refresh i když je platná cache
            
        Returns:
            List seriálů s aggregovanými metadaty (sezóny, epizody, TMDB data)
        """
        try:
            # Zkontroluj cache
            if not force_refresh:
                cached_data = self._load_cache()
                if cached_data and 'series' in cached_data:
                    if time.time() < cached_data.get('series_expires', 0):
                        xbmc.log('DiscoverManager: Using cached series data', xbmc.LOGDEBUG)
                        return cached_data['series']
            
            xbmc.log('DiscoverManager: Fetching new series from Webshare', xbmc.LOGINFO)
            
            # Import Tshare zde, abychom se vyhnuli circular import
            import Tshare
            
            # Token pro přihlášení
            token = Tshare.login()
            if not token:
                xbmc.log('DiscoverManager: Login failed', xbmc.LOGERROR)
                return []
            
            # Parametry pro vyhledávání
            # Hledáme "e" což vrátí všechny epizody, pak vyfiltrujeme E01
            # sort=recent zajistí správné řazení od nejnovějších
            params = {
                'what': 'e',
                'category': 'video',
                'sort': 'recent',  # Seřadit podle data přidání (nejnovější první)
                'offset': 0,
                'limit': 1000,  # Větší limit pro více výsledků
                'wst': token,
                'maybe_removed': 'true'
            }
            
            # Získej XML odpověď přímo přes Tshare.api()
            response = Tshare.api('search', params)
            
            if not response:
                xbmc.log('DiscoverManager: No response from Webshare API', xbmc.LOGERROR)
                return []
            
            # Parsuj XML
            try:
                from xml.etree import ElementTree as ET
                root = ET.fromstring(response.content)
                
                if not Tshare.is_ok(root):
                    xbmc.log('DiscoverManager: API returned error status', xbmc.LOGERROR)
                    return []
                    
            except Exception as e:
                xbmc.log(f'DiscoverManager: XML parsing error: {str(e)}', xbmc.LOGERROR)
                return []
            
            # Extrahuj všechny soubory
            all_files = []
            for idx, item in enumerate(root.findall('.//file')):
                name = item.find('name')
                ident = item.find('ident')
                size = item.find('size')
                
                if name is not None and ident is not None:
                    all_files.append({
                        'name': name.text,
                        'ident': ident.text,
                        'size': size.text if size is not None else '0',
                        'order': idx  # Pořadí = recency (0 = nejnovější)
                    })
            
            xbmc.log(f'DiscoverManager: Found {len(all_files)} total files', xbmc.LOGINFO)
            
            # Debug: Zobraz několik prvních souborů
            if all_files:
                xbmc.log(f'DiscoverManager: Sample files (first 5):', xbmc.LOGINFO)
                for i, f in enumerate(all_files[:5]):
                    xbmc.log(f'  {i+1}. {f["name"]}', xbmc.LOGINFO)
            
            # Filtruj jen seriály s CZ dabingem/titulky
            # e01 už garantuje že je to seriál, nemusíme kontrolovat _is_series()
            series_files = []
            for file in all_files:
                filename = file['name'].lower()
                
                # Musí být E01 (první epizoda)
                if not re.search(r'[se]01', filename, re.IGNORECASE):
                    continue
                
                # Musí obsahovat CZ klíčové slovo
                has_cz = any(keyword in filename for keyword in self.cz_keywords)
                is_excluded = self._is_excluded_content(filename)
                
                # Debug pro první soubor
                if len(series_files) < 3:
                    xbmc.log(f'DiscoverManager: Checking "{file["name"][:80]}" - E01=True, CZ={has_cz}, Excluded={is_excluded}', xbmc.LOGINFO)
                
                if not has_cz:
                    continue
                
                # Vyřaď nežádoucí obsah
                if is_excluded:
                    continue
                
                series_files.append(file)
            
            xbmc.log(f'DiscoverManager: Filtered to {len(series_files)} CZ E01 files', xbmc.LOGINFO)
            
            # Seskup podle názvu seriálu
            series_dict = {}
            for file in series_files:
                series_name, season, episode = self._parse_series_name(file['name'])
                
                # Debug
                if len(series_dict) < 3:
                    xbmc.log(f'DiscoverManager: Parsed "{file["name"][:80]}" -> name="{series_name}", S{season}E{episode}', xbmc.LOGINFO)
                
                if not series_name:
                    xbmc.log(f'DiscoverManager: Failed to parse series name from "{file["name"][:80]}"', xbmc.LOGWARNING)
                    continue
                
                # Normalizovaný klíč pro seskupení
                normalized_key = self._normalize_title(series_name)
                
                # Jeden záznam per unikátní seriál (deduplikace)
                # Použij pořadí prvního výskytu jako "recency" (nižší = novější)
                if normalized_key not in series_dict:
                    series_dict[normalized_key] = {
                        'name': series_name,
                        'normalized_name': normalized_key,
                        'order': file.get('order', 999999)  # Pořadí z API (recent)
                    }
            
            xbmc.log(f'DiscoverManager: Grouped into {len(series_dict)} unique series', xbmc.LOGINFO)
            
            # Převeď na list a obohať o TMDB data
            series_list = list(series_dict.values())
            enriched_series = self._enrich_series_with_tmdb(series_list)
            
            # Vyřaď seriály bez TMDB ID (nelze je pak vyhledat)
            valid_series = [s for s in enriched_series if s.get('tmdb_id')]
            xbmc.log(f'DiscoverManager: {len(enriched_series)} -> {len(valid_series)} series with TMDB ID (removed {len(enriched_series) - len(valid_series)} without ID)', xbmc.LOGINFO)
            
            # Deduplikuj podle TMDB ID (různé parsované názvy mohou mít stejný TMDB)
            seen_tmdb_ids = {}
            unique_series = []
            for series in valid_series:
                tmdb_id = series.get('tmdb_id')
                if tmdb_id not in seen_tmdb_ids:
                    seen_tmdb_ids[tmdb_id] = True
                    unique_series.append(series)
                else:
                    xbmc.log(f'DiscoverManager: Skipping duplicate TMDB ID {tmdb_id}: {series.get("title")}', xbmc.LOGDEBUG)
            
            xbmc.log(f'DiscoverManager: {len(valid_series)} -> {len(unique_series)} unique series after TMDB deduplication', xbmc.LOGINFO)
            
            # Seřaď podle recency (order: 0 = nejnovější)
            unique_series.sort(key=lambda x: x.get('order', 999999))
            
            # Ulož do cache (oddělená sekce od filmů)
            cache_data = self._load_cache() or {}
            cache_data['series'] = unique_series
            self._save_cache(cache_data, cache_type='series')
            
            return unique_series
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error getting new series: {str(e)}', xbmc.LOGERROR)
            import traceback
            xbmc.log(f'DiscoverManager: Traceback: {traceback.format_exc()}', xbmc.LOGERROR)
            return []
    
    def _is_series(self, filename):
        """Detekuje jestli je soubor seriál (obsahuje S01E01 pattern)"""
        # Použij existující funkci z Tshare.py
        pattern = r'[Ss](\d{1,2})[Ee](\d{1,3})'
        match = re.search(pattern, filename)
        return match is not None
    
    def _is_excluded_content(self, filename):
        """Detekuje nežádoucí obsah - sport, hudba, awards apod."""
        filename_lower = filename.lower()
        
        # Exclude patterns
        exclude_patterns = [
            r'\bms\s*\d{4}\b',  # MS 2025 (mistrovství světa)
            r'\bme\s*\d{4}\b',  # ME 2025 (mistrovství Evropy)
            r'\b(uefa|fifa|nhl|nba|nfl)\b',  # Sportovní organizace
            r'\b(fotbal|hokej|tenis|box|zápas|házená|volejbal)\b',  # České sportovní termíny
            r'\b(football|hockey|basketball|soccer|match|game|handball)\b',  # Anglické sportovní
            r'\bmusic\s*mix\b',  # Hudební mixy
            r'\b(concert|live\s*performance|mtv|vma)\b',  # Hudební události
            r'\bawards?\s*\d{4}\b',  # Award shows (Awards 2025, Award 2025)
            r'\b(oscar|emmy|golden.?globe|bafta|grammy|chainsaw)\b',  # Konkrétní awards
            r'\.mp3$',  # Audio soubory
            r'\b(best\s*remixes|party\s*club|dance\s*mix)\b',  # Hudební kompilace
            r'\b(finále|semifinále|čtvrtfinále)\b',  # České sportovní termíny (finále, semifinále)
        ]
        
        return any(re.search(pattern, filename_lower) for pattern in exclude_patterns)
    
    def _parse_movie_name(self, filename):
        """
        Extrahuje název filmu a rok z názvu souboru
        
        Příklad: "Avatar.3.2025.CZ.DABING.1080p.BluRay.mkv" -> ("Avatar 3", 2025)
        """
        try:
            # Odstraň příponu
            name = os.path.splitext(filename)[0]
            
            # Najdi rok (4 číslice)
            year_match = re.search(r'(19\d{2}|20\d{2})', name)
            year = int(year_match.group(1)) if year_match else None
            
            if year_match:
                # Vezmi vše před rokem jako název
                name_part = name[:year_match.start()].strip()
            else:
                # Pokud není rok, vezmi vše před kvalitou/CZ klíčovými slovy
                quality_pattern = r'(1080p|720p|2160p|4K|BluRay|WEB|HDTV|DVDRip|CZ|DABING|Czech)'
                quality_match = re.search(quality_pattern, name, re.IGNORECASE)
                if quality_match:
                    name_part = name[:quality_match.start()].strip()
                else:
                    name_part = name
            
            # Nahraď tečky a podtržítka mezerami
            clean_name = re.sub(r'[._]', ' ', name_part)
            # Odstraň multiple mezery
            clean_name = re.sub(r'\s+', ' ', clean_name).strip()
            
            return clean_name, year
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error parsing movie name "{filename}": {str(e)}', xbmc.LOGDEBUG)
            return filename, None
    
    def _parse_series_name(self, filename):
        """
        Extrahuje název seriálu, sezónu a epizodu z názvu souboru
        
        Podporované formáty:
        - S01E01, s01e01
        - 1x01
        - E01, e01 (předpokládá S01)
        
        Příklad: "Breaking.Bad.S05E16.CZ.DABING.1080p.mkv" -> ("Breaking Bad", 5, 16)
        """
        try:
            season = None
            episode = None
            match = None
            
            # Zkus S##E## pattern
            pattern1 = r'[Ss](\d{1,2})[Ee](\d{1,3})'
            match = re.search(pattern1, filename)
            
            if match:
                season = int(match.group(1))
                episode = int(match.group(2))
            else:
                # Zkus ##x## pattern (např. 1x01)
                pattern2 = r'(\d{1,2})x(\d{1,3})'
                match = re.search(pattern2, filename, re.IGNORECASE)
                
                if match:
                    season = int(match.group(1))
                    episode = int(match.group(2))
                else:
                    # Zkus jen E## pattern (předpokládej S01)
                    pattern3 = r'[Ee](\d{1,3})'
                    match = re.search(pattern3, filename)
                    
                    if match:
                        season = 1  # Default sezóna 1
                        episode = int(match.group(1))
            
            if not match:
                return None, None, None
            
            # Vezmi vše před S##E##/##x##/E## jako název
            name_part = filename[:match.start()].strip()
            
            # Odstraň příponu
            name_part = os.path.splitext(name_part)[0]
            
            # Nahraď tečky a podtržítka mezerami
            clean_name = re.sub(r'[._]', ' ', name_part)
            # Odstraň multiple mezery
            clean_name = re.sub(r'\s+', ' ', clean_name).strip()
            
            # Odstraň trailing rok pokud existuje
            clean_name = re.sub(r'\s+(19|20)\d{2}$', '', clean_name)
            
            return clean_name, season, episode
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error parsing series name "{filename}": {str(e)}', xbmc.LOGDEBUG)
            return None, None, None
    
    def _deduplicate_movies(self, movies):
        """
        Seskupí podobné filmy dohromady
        
        Filmy se stejným TMDB ID nebo 80%+ podobností názvu jsou duplicity.
        Všechny varianty se uloží do 'variants' pro pozdější výběr.
        """
        try:
            seen_tmdb_ids = {}
            seen_titles = {}
            unique_movies = []
            
            for movie in movies:
                tmdb_id = movie.get('tmdb_id')
                title = movie.get('title', '').lower().strip()
                original_title = movie.get('original_title', '').lower().strip()
                file_name = movie.get('name', '')
                
                xbmc.log(f'DiscoverManager: Processing "{title}" (TMDB: {tmdb_id}) from file "{file_name}"', xbmc.LOGDEBUG)
                
                # Seskupení podle TMDB ID (nejspolehlivější)
                if tmdb_id:
                    if tmdb_id in seen_tmdb_ids:
                        # Už máme tento film - přidej jako variantu
                        existing = seen_tmdb_ids[tmdb_id]
                        if 'variants' not in existing:
                            existing['variants'] = [existing.copy()]
                        existing['variants'].append(movie.copy())
                        xbmc.log(f'DiscoverManager: VARIANT (TMDB {tmdb_id}): Added "{file_name}" as variant #{len(existing["variants"])}', xbmc.LOGINFO)
                        continue  # Už zpracováno
                    else:
                        # První výskyt tohoto filmu
                        movie['variants'] = [movie.copy()]
                        seen_tmdb_ids[tmdb_id] = movie
                        unique_movies.append(movie)
                        xbmc.log(f'DiscoverManager: NEW (TMDB {tmdb_id}): "{title}" from "{file_name}"', xbmc.LOGDEBUG)
                        continue
                
                # Fallback seskupení podle podobnosti názvu (pro filmy bez TMDB ID)
                found_similar = False
                
                # Porovnej s už viděnými filmy
                for existing in unique_movies:
                    existing_title = existing.get('title', '')
                    existing_original = existing.get('original_title', '')
                    
                    # Vypočti podobnost
                    similarity1 = self._calculate_similarity(title, existing_title)
                    similarity2 = self._calculate_similarity(title, existing_original) if existing_original else 0
                    similarity3 = self._calculate_similarity(original_title, existing_title) if original_title else 0
                    similarity4 = self._calculate_similarity(original_title, existing_original) if original_title and existing_original else 0
                    
                    max_similarity = max(similarity1, similarity2, similarity3, similarity4)
                    
                    xbmc.log(f'DiscoverManager: Comparing "{title}" with "{existing_title}" = {max_similarity:.1f}% similarity', xbmc.LOGDEBUG)
                    
                    # Pokud je podobnost 80%+, seskup jako variantu
                    if max_similarity >= 80:
                        if 'variants' not in existing:
                            existing['variants'] = [existing.copy()]
                        existing['variants'].append(movie.copy())
                        xbmc.log(f'DiscoverManager: SIMILAR ({max_similarity:.0f}%): Added "{file_name}" as variant #{len(existing["variants"])}', xbmc.LOGINFO)
                        found_similar = True
                        break
                
                if not found_similar:
                    # Úplně nový film
                    movie['variants'] = [movie.copy()]
                    unique_movies.append(movie)
                    xbmc.log(f'DiscoverManager: NEW (no match): "{title}" from "{file_name}"', xbmc.LOGINFO)
            
            xbmc.log(f'DiscoverManager: Deduplicated {len(movies)} -> {len(unique_movies)} unique movies', xbmc.LOGINFO)
            return unique_movies
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error deduplicating movies: {str(e)}', xbmc.LOGERROR)
            import traceback
            traceback.print_exc()
            return movies  # Vrať originální seznam při chybě
    
    def _normalize_title(self, title):
        """
        Normalizuje název filmu pro porovnání duplicit
        
        Odstraní: mezery, diakritiku, speciální znaky, čísla, 'the', 'a'
        """
        if not title:
            return ''
        
        # Lowercase
        title = title.lower()
        
        # Odstraň běžné předpony
        title = re.sub(r'^(the|a|an)\s+', '', title)
        
        # Odstraň speciální znaky a čísla (kromě základních písmen)
        title = re.sub(r'[^a-z0-9]', '', title)
        
        return title
    
    def _calculate_similarity(self, str1, str2):
        """
        Vypočítá podobnost mezi dvěma řetězci (0-100%)
        Používá Levenshtein distance
        """
        if not str1 or not str2:
            return 0
        
        # Normalizuj oba řetězce
        s1 = self._normalize_title(str1)
        s2 = self._normalize_title(str2)
        
        if s1 == s2:
            return 100
        
        # Levenshtein distance
        len1, len2 = len(s1), len(s2)
        if len1 > len2:
            s1, s2 = s2, s1
            len1, len2 = len2, len1
        
        current_row = range(len1 + 1)
        for i in range(1, len2 + 1):
            previous_row, current_row = current_row, [i] + [0] * len1
            for j in range(1, len1 + 1):
                add, delete, change = previous_row[j] + 1, current_row[j-1] + 1, previous_row[j-1]
                if s1[j-1] != s2[i-1]:
                    change += 1
                current_row[j] = min(add, delete, change)
        
        distance = current_row[len1]
        max_len = max(len(s1), len(s2))
        similarity = ((max_len - distance) / max_len) * 100 if max_len > 0 else 0
        
        return similarity
    
    def _is_better_quality(self, movie1, movie2):
        """
        Porovná kvalitu dvou verzí stejného filmu
        
        Returns:
            True pokud movie1 má lepší kvalitu než movie2
        """
        try:
            name1 = movie1.get('name', '').lower()
            name2 = movie2.get('name', '').lower()
            
            # Quality scoring (vyšší = lepší)
            quality_scores = {
                '2160p': 40,
                '4k': 40,
                'uhd': 40,
                '1080p': 30,
                'fhd': 30,
                '720p': 20,
                'hd': 20,
                '480p': 10,
                'sd': 5,
                'dvdrip': 5,
                'hdtv': 8,
            }
            
            # Source scoring (BluRay > WEB-DL > WEB > HDTV)
            source_scores = {
                'bluray': 10,
                'bdrip': 10,
                'brrip': 10,
                'web-dl': 8,
                'webdl': 8,
                'webrip': 6,
                'web': 5,
                'hdtv': 3,
                'dvdrip': 1,
            }
            
            # Zjisti kvalitu
            score1 = 0
            score2 = 0
            
            for quality, score in quality_scores.items():
                if quality in name1:
                    score1 += score
                if quality in name2:
                    score2 += score
            
            # Přidej source scoring
            for source, score in source_scores.items():
                if source in name1:
                    score1 += score
                if source in name2:
                    score2 += score
            
            # Pokud mají stejnou kvalitu, preferuj větší soubor
            if score1 == score2:
                size1 = movie1.get('size', 0)
                size2 = movie2.get('size', 0)
                return size1 > size2
            
            return score1 > score2
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error comparing quality: {str(e)}', xbmc.LOGDEBUG)
            return False
    
    def _enrich_with_tmdb(self, movies, search_year):
        """
        Obohacuje filmy o TMDB metadata (poster, rating, plot)
        """
        enriched = []
        
        api_key = self.addon.getSetting('tmdb_api_key').strip() or '4219e299c89411838049ab0dab19ebd5'
        
        for movie in movies:
            try:
                # Parse název
                original_name = movie.get('name', '')
                movie_name, year = self._parse_movie_name(original_name)
                
                # Pokud nemáme rok z parsování, použij search_year
                if not year:
                    year = search_year
                
                xbmc.log(f'DiscoverManager: File: "{original_name}"', xbmc.LOGINFO)
                xbmc.log(f'DiscoverManager: Parsed: "{movie_name}" ({year})', xbmc.LOGINFO)
                xbmc.log(f'DiscoverManager: Searching TMDB for "{movie_name}" ({year})', xbmc.LOGDEBUG)
                
                # Hledej na TMDB
                search_url = 'https://api.themoviedb.org/3/search/movie'
                params = {
                    'api_key': api_key,
                    'query': movie_name,
                    'year': year,
                    'language': 'cs-CZ'
                }
                
                response = requests.get(search_url, params=params, timeout=5)
                
                if response.status_code == 200:
                    data = response.json()
                    results = data.get('results', [])
                    
                    xbmc.log(f'DiscoverManager: TMDB found {len(results)} results', xbmc.LOGINFO)
                    
                    if results:
                        # Vezmi první výsledek
                        tmdb_movie = results[0]
                        
                        xbmc.log(f'DiscoverManager: Selected: "{tmdb_movie.get("title")}" ({tmdb_movie.get("release_date", "")[:4]}) ID={tmdb_movie.get("id")}', xbmc.LOGINFO)
                        
                        # Přidej TMDB metadata
                        movie['tmdb_id'] = tmdb_movie.get('id')
                        movie['title'] = tmdb_movie.get('title')
                        movie['original_title'] = tmdb_movie.get('original_title')
                        movie['overview'] = tmdb_movie.get('overview')
                        movie['rating'] = tmdb_movie.get('vote_average')
                        movie['votes'] = tmdb_movie.get('vote_count')
                        movie['release_date'] = tmdb_movie.get('release_date')
                        
                        poster_path = tmdb_movie.get('poster_path')
                        if poster_path:
                            movie['poster'] = f"https://image.tmdb.org/t/p/w500{poster_path}"
                        
                        backdrop_path = tmdb_movie.get('backdrop_path')
                        if backdrop_path:
                            movie['fanart'] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
                        
                        xbmc.log(f'DiscoverManager: Found TMDB match for "{movie_name}": {tmdb_movie.get("title")}', xbmc.LOGDEBUG)
                    else:
                        xbmc.log(f'DiscoverManager: No TMDB match for "{movie_name}"', xbmc.LOGDEBUG)
                        movie['title'] = movie_name
                        movie['year'] = year
                
                enriched.append(movie)
                
                # Malé zpoždění mezi TMDB requesty
                time.sleep(0.1)
                
            except Exception as e:
                xbmc.log(f'DiscoverManager: Error enriching movie: {str(e)}', xbmc.LOGDEBUG)
                # Přidej i bez TMDB dat
                movie['title'] = movie.get('name', 'Unknown')
                enriched.append(movie)
        
        xbmc.log(f'DiscoverManager: Enriched {len(enriched)} movies with TMDB data', xbmc.LOGINFO)
        return enriched
    
    def _enrich_series_with_tmdb(self, series_list):
        """
        Obohacuje seriály o TMDB metadata (poster, rating, plot)
        """
        enriched = []
        
        api_key = self.addon.getSetting('tmdb_api_key').strip() or '4219e299c89411838049ab0dab19ebd5'
        
        for series in series_list:
            try:
                series_name = series.get('name', '')
                
                xbmc.log(f'DiscoverManager: Searching TMDB TV for "{series_name}"', xbmc.LOGDEBUG)
                
                # Hledej na TMDB (TV API)
                search_url = 'https://api.themoviedb.org/3/search/tv'
                params = {
                    'api_key': api_key,
                    'query': series_name,
                    'language': 'cs-CZ'
                }
                
                response = requests.get(search_url, params=params, timeout=5)
                
                if response.status_code == 200:
                    data = response.json()
                    results = data.get('results', [])
                    
                    if results:
                        # Vezmi první výsledek
                        tmdb_series = results[0]
                        
                        # Přidej TMDB metadata
                        series['tmdb_id'] = tmdb_series.get('id')
                        series['title'] = tmdb_series.get('name')
                        series['original_title'] = tmdb_series.get('original_name')
                        series['overview'] = tmdb_series.get('overview')
                        series['rating'] = tmdb_series.get('vote_average')
                        series['votes'] = tmdb_series.get('vote_count')
                        series['first_air_date'] = tmdb_series.get('first_air_date')
                        
                        poster_path = tmdb_series.get('poster_path')
                        if poster_path:
                            series['poster'] = f"https://image.tmdb.org/t/p/w500{poster_path}"
                        
                        backdrop_path = tmdb_series.get('backdrop_path')
                        if backdrop_path:
                            series['fanart'] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
                        
                        xbmc.log(f'DiscoverManager: Found TMDB TV match for "{series_name}": {tmdb_series.get("name")}', xbmc.LOGDEBUG)
                    else:
                        xbmc.log(f'DiscoverManager: No TMDB TV match for "{series_name}"', xbmc.LOGDEBUG)
                        series['title'] = series_name
                
                enriched.append(series)
                
                # Malé zpoždění mezi TMDB requesty
                time.sleep(0.1)
                
            except Exception as e:
                xbmc.log(f'DiscoverManager: Error enriching series: {str(e)}', xbmc.LOGDEBUG)
                # Přidej i bez TMDB dat
                series['title'] = series.get('name', 'Unknown')
                enriched.append(series)
        
        xbmc.log(f'DiscoverManager: Enriched {len(enriched)} series with TMDB data', xbmc.LOGINFO)
        return enriched
    
    def _load_cache(self):
        """Načte cache ze souboru"""
        try:
            if os.path.exists(self.cache_file):
                with io.open(self.cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error loading cache: {str(e)}', xbmc.LOGDEBUG)
        return None
    
    def _save_cache(self, data, cache_type='movies'):
        """
        Uloží cache do souboru
        
        Args:
            data: Data k uložení
            cache_type: 'movies' (3 dny) nebo 'series' (7 dní)
        """
        try:
            if not os.path.exists(self.profile_path):
                os.makedirs(self.profile_path)
            
            # Načti existující cache
            existing_cache = self._load_cache() or {}
            
            # Vyber správnou expiraci podle typu
            if cache_type == 'series':
                expires_key = 'series_expires'
                duration = self.series_cache_duration
            else:
                expires_key = 'movies_expires'
                duration = self.movie_cache_duration
            
            # Zachovej existující data
            cache_data = existing_cache.copy()
            cache_data['last_update'] = time.time()
            cache_data['last_update_human'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            cache_data[expires_key] = time.time() + duration
            cache_data.update(data)
            
            with io.open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
            
            xbmc.log(f'DiscoverManager: Cache saved successfully ({cache_type}, expires in {duration//86400} days)', xbmc.LOGDEBUG)
            
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error saving cache: {str(e)}', xbmc.LOGERROR)
    
    def clear_cache(self):
        """Smaže cache"""
        try:
            if os.path.exists(self.cache_file):
                os.remove(self.cache_file)
                xbmc.log('DiscoverManager: Cache cleared', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'DiscoverManager: Error clearing cache: {str(e)}', xbmc.LOGERROR)
