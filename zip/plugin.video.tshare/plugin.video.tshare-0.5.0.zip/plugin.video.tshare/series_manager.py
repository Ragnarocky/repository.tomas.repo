# -*- coding: utf-8 -*-
# Module: series_manager
# Author: Tomas for friends
# Created on: 2.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import os
import io
import re
import json
import logging
import xbmc
import xbmcaddon
import xbmcgui
import xml.etree.ElementTree as ET
import unidecode
import traceback
import xbmcplugin

try:
    from urllib import urlencode
    from urlparse import parse_qsl
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

# Regular expressions for detecting episode patterns - ZPŘÍSNĚNO
EPISODE_PATTERNS = [
    r'[Ss](\d+)[Ee](\d+)',      # S01E01 format
    r'(\d+)x(\d+)',             # 1x01 format
    r'(\d+)\.\s*d[íi]l',        # 01.díl, 02.díl format (český)
    r'-\s*(\d+)\.\s*d[íi]l',    # - 01.díl format
    r'(\d+)\s+d[íi]l',          # 01 díl format (bez tečky)
    r'(\d+)\.\s*cast',          # 01.cast, 02.cast format
    r'[Ee]pisode\s*(\d+)',      # Episode 1 format
    r'[Ee]p\s*(\d+)',           # Ep 1 format
    r'[Ee](\d+)\b',             # E1 format (s word boundary)
]

class SeriesManager:
    # Bezpečný název souboru pro DB/Cache
    def _safe_filename(self, name):
        try:
            n = unidecode.unidecode(name or '').strip().lower()
            n = re.sub(r'[^a-z0-9\-_]+', '_', n)
            n = re.sub(r'_+', '_', n).strip('_')
            return n or 'series'
        except Exception:
            return 'series'

    # Uložení/načtení dat seriálu (series_db/<safe>.json)
    def load_series_data(self, series_name):
        try:
            self.ensure_db_exists()
            path = os.path.join(self.series_db_path, f'{self._safe_filename(series_name)}.json')
            if os.path.exists(path):
                with io.open(path, 'r', encoding='utf8') as f:
                    return json.load(f)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: load_series_data error: {e}', level=xbmc.LOGERROR)
        return None

    def _save_series_data(self, series_name, series_data):
        try:
            self.ensure_db_exists()
            path = os.path.join(self.series_db_path, f'{self._safe_filename(series_name)}.json')
            with io.open(path, 'w', encoding='utf8') as f:
                json.dump(series_data or {}, f, indent=2)
            xbmc.log(f'Tshare Series Manager: series "{series_name}" saved (seasons={len(series_data.get("seasons", {}))})', level=xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: _save_series_data error: {e}', level=xbmc.LOGERROR)

    # Získání streamů pro epizodu
    def get_streams_for_episode(self, series_name, season, episode):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}
            se = str(season)
            ep = str(episode)
            return (seasons.get(se, {}).get(ep, {}) or {}).get('episodes', []) or []
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_streams_for_episode error: {e}', level=xbmc.LOGERROR)
            return []

    # Historie seriálů (playback)
    def _series_history_path(self):
        return os.path.join(self.profile, 'series_history.json')

    def get_series_history(self):
        try:
            path = self._series_history_path()
            if os.path.exists(path):
                with io.open(path, 'r', encoding='utf8') as f:
                    return json.load(f)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_series_history error: {e}', level=xbmc.LOGERROR)
        return []

    def save_history(self, history):
        try:
            with io.open(self._series_history_path(), 'w', encoding='utf8') as f:
                json.dump(history or [], f, indent=2)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: save_history error: {e}', level=xbmc.LOGERROR)

    def add_to_history(self, series_name, season, episode, episode_title, year=None, plot=None, poster=None, tmdb_id=None, stream_url=None):
        try:
            h = self.get_series_history()
            entry = {
                'series_name': str(series_name),
                'season': str(season),
                'episode': str(episode),
                'episode_title': episode_title,
                'year': year,
                'plot': plot,
                'poster': poster,
                'tmdb_id': tmdb_id,
                'stream_url': stream_url,
                'timestamp': int(__import__('time').time())
            }
            # odstranit starou shodu (duplicitní záznam téže epizody)
            h = [e for e in h if not (e.get('series_name') == entry['series_name'] and e.get('season') == entry['season'] and e.get('episode') == entry['episode'])]
            h.insert(0, entry)
            self.save_history(h[:500])
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: add_to_history error: {e}', level=xbmc.LOGERROR)

    # Nově: poslední shlédnutá epizoda (pro zvýraznění v seznamu)
    def get_last_watched_episode(self, series_name):
        """Vrátí poslední zhlédnutou epizodu jako (season, episode) nebo (None, None)."""
        try:
            history = self.get_series_history()
            series_episodes = [h for h in history if h.get('series_name') == series_name]
            if not series_episodes:
                return (None, None)
            latest = max(series_episodes, key=lambda x: x.get('timestamp', 0) or 0)
            return (latest.get('season'), latest.get('episode'))
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_last_watched_episode error: {e}', level=xbmc.LOGERROR)
            return (None, None)

    # Vrátí další díl v rámci celého seriálu (podle historie) + nejlepší stream
    def get_next_episode(self, series_name):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}
            if not seasons:
                return (None, None, None)
            # seřadit sezóny a epizody numericky
            def sort_int_keys(d):
                return sorted(d.keys(), key=lambda x: int(x) if str(x).isdigit() else x)
            season_keys = sort_int_keys(seasons)

            last_s, last_e = self.get_last_watched_episode(series_name)
            # start: první epizoda v prvním dostupném seznamu
            def first_available():
                s0 = season_keys[0]
                ep_keys = sort_int_keys(seasons[s0])
                if not ep_keys:
                    return (None, None, None)
                e0 = ep_keys[0]
                streams = (seasons[s0][e0] or {}).get('episodes') or []
                if not streams:
                    return (None, None, None)
                best = self._sort_streams(streams, series_name, s0, e0)[0]
                return (str(s0), str(e0), best)

            if not last_s or not last_e:
                return first_available()

            # najít další epizodu po poslední shlédnuté
            last_s = str(last_s)
            last_e = str(last_e)
            if last_s in seasons:
                ep_keys = sort_int_keys(seasons[last_s])
                try:
                    idx = ep_keys.index(last_e)
                except ValueError:
                    return first_available()
                # další v rámci stejné sezóny
                if idx + 1 < len(ep_keys):
                    next_e = ep_keys[idx + 1]
                    streams = (seasons[last_s][next_e] or {}).get('episodes') or []
                    if streams:
                        best = self._sort_streams(streams, series_name, last_s, next_e)[0]
                        return (str(last_s), str(next_e), best)
                # první epizoda v další sezóně
                try:
                    sidx = season_keys.index(last_s)
                except ValueError:
                    return first_available()
                if sidx + 1 < len(season_keys):
                    ns = season_keys[sidx + 1]
                    neps = seasons[ns]
                    nep_keys = sort_int_keys(neps)
                    if nep_keys:
                        ne = nep_keys[0]
                        streams = (neps[ne] or {}).get('episodes') or []
                        if streams:
                            best = self._sort_streams(streams, series_name, ns, ne)[0]
                            return (str(ns), str(ne), best)
            # fallback
            return first_available()
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_next_episode error: {e}', level=xbmc.LOGERROR)
            return (None, None, None)

    # Vrátí další díl v rámci konkrétní řady + nejlepší stream
    def get_next_episode_in_season(self, series_name, season):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}
            s = str(season)
            if s not in seasons:
                return (None, None, None)
            def sort_int_keys(d):
                return sorted(d.keys(), key=lambda x: int(x) if str(x).isdigit() else x)
            ep_keys = sort_int_keys(seasons[s])
            if not ep_keys:
                return (None, None, None)

            last_s, last_e = self.get_last_watched_episode(series_name)
            if str(last_s) == s and last_e and str(last_e) in ep_keys:
                idx = ep_keys.index(str(last_e))
                if idx + 1 < len(ep_keys):
                    next_e = ep_keys[idx + 1]
                    streams = (seasons[s][next_e] or {}).get('episodes') or []
                    if streams:
                        best = self._sort_streams(streams, series_name, s, next_e)[0]
                        return (s, str(next_e), best)
            # jinak první epizoda v řadě
            first_e = ep_keys[0]
            streams = (seasons[s][first_e] or {}).get('episodes') or []
            if streams:
                best = self._sort_streams(streams, series_name, s, first_e)[0]
                return (s, str(first_e), best)
            return (None, None, None)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: get_next_episode_in_season error: {e}', level=xbmc.LOGERROR)
            return (None, None, None)

    # Zruší nucený pattern (pro obnovu chytrého řazení)
    def disable_force_pattern(self, series_name):
        try:
            if series_name in self.preferences and self.preferences[series_name].get('force_pattern'):
                self.preferences[series_name]['force_pattern'] = False
                self.save_preferences()
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: disable_force_pattern error: {e}', level=xbmc.LOGERROR)

    # Smazání seriálu (pro menu akci)
    def delete_series(self, series_name):
        try:
            ok = True
            # DB
            db_path = os.path.join(self.series_db_path, f'{self._safe_filename(series_name)}.json')
            if os.path.exists(db_path):
                try:
                    os.remove(db_path)
                except Exception:
                    ok = False
            # Cache
            cache_path = self.get_series_cache_path(series_name)
            if os.path.exists(cache_path):
                try:
                    os.remove(cache_path)
                except Exception:
                    ok = False
            # Preference
            if series_name in self.preferences:
                try:
                    self.preferences.pop(series_name, None)
                    self.save_preferences()
                except Exception:
                    ok = False
            return ok
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: delete_series error: {e}', level=xbmc.LOGERROR)
            return False

    # Najde chybějící díly podle existujících epizod v DB (1..max zjištěné)
    def find_missing_episodes(self, series_name):
        missing = []
        try:
            data = self.load_series_data(series_name) or {}
            for s, eps in (data.get('seasons') or {}).items():
                nums = sorted(int(n) for n in eps.keys() if str(n).isdigit())
                if not nums: 
                    continue
                max_ep = max(nums)
                for e in range(1, max_ep + 1):
                    if str(e) not in eps:
                        missing.append((int(s), int(e)))
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: find_missing_episodes error: {e}', level=xbmc.LOGERROR)
        return missing

    # Vyhledá a doplní chybějící díly (vrátí počet přidaných)
    def search_missing_episodes(self, series_name, api_function, token, missing_episodes):
        added = 0
        try:
            base = unidecode.unidecode(series_name).lower()
            base = re.sub(r'[^a-z0-9& ]', '', base).strip()
            data = self.load_series_data(series_name) or {'name': series_name, 'seasons': {}}

            for (s, e) in missing_episodes:
                queries = [
                    f'{base} s{s:02d}e{e:02d}',
                    f'{base} {s}x{e:02d}',
                    f'{base} cz s{s:02d}e{e:02d}'
                ]
                found_items = []
                for q in queries:
                    results = self._perform_search(q, api_function, token)
                    for item in results:
                        name = item.get('name') or ''
                        ss, ee = self._detect_episode_info(name)
                        if ss == s and ee == e and self._is_likely_episode(name, series_name, s, e):
                            found_items.append(item)
                    if found_items:
                        break
                if not found_items:
                    continue
                # vyber nejlepší (největší) a zapiš
                best = max(found_items, key=lambda it: int(it.get('size') or '0'))
                seasons = data.setdefault('seasons', {})
                seasons.setdefault(str(s), {})
                seasons[str(s)].setdefault(str(e), {'episodes': []})
                episode_list = seasons[str(s)][str(e)]['episodes']
                # dedup podle ident
                if not any(ep.get('ident') == best.get('ident') for ep in episode_list):
                    episode_list.append({
                        'name': best.get('name'),
                        'ident': best.get('ident'),
                        'size': best.get('size') or '0'
                    })
                    # přerovnat dle preferencí
                    seasons[str(s)][str(e)]['episodes'] = self._sort_streams(episode_list, series_name, str(s), str(e))
                    added += 1

            if added:
                self._save_series_data(series_name, data)
                self.save_series_cache(series_name, data)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: search_missing_episodes error: {e}', level=xbmc.LOGERROR)
        return added

    def cleanup_series_cache(self, max_files=10):
        """Ponechá pouze max_files nejnovějších cache souborů v series_cache."""
        cache_dir = self.get_cache_dir()
        files = [os.path.join(cache_dir, f) for f in os.listdir(cache_dir) if f.endswith('.json')]
        files = sorted(files, key=lambda f: os.path.getmtime(f), reverse=True)
        for f in files[max_files:]:
            try:
                os.remove(f)
            except Exception:
                pass
    def get_cache_dir(self):
        cache_dir = os.path.join(self.profile, 'series_cache')
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        return cache_dir

    def get_series_cache_path(self, series_name):
        safe_name = self._safe_filename(series_name)
        return os.path.join(self.get_cache_dir(), f"{safe_name}.json")

    def load_series_cache(self, series_name, max_age_days=7):
        """Načte cache seriálu, pokud existuje a není starší než max_age_days."""
        import time
        path = self.get_series_cache_path(series_name)
        if not os.path.exists(path):
            return None
        
        try:
            mtime = os.path.getmtime(path)
            age_days = (time.time() - mtime) / 86400
            if age_days > max_age_days:
                # Smaž starý cache soubor
                try:
                    os.remove(path)
                except Exception:
                    pass
                return None
                
            with io.open(path, 'r', encoding='utf8') as file:
                return json.load(file)
        except (IOError, ValueError, json.JSONDecodeError) as e:
            xbmc.log(f'Series cache error for {series_name}: {str(e)}', level=xbmc.LOGWARNING)
            # Smaž poškozený cache soubor
            try:
                os.remove(path)
            except Exception:
                pass
            return None

    def save_series_cache(self, series_name, series_data):
        """Uloží výsledky hledání seriálu do cache a udržuje max. 10 souborů."""
        path = self.get_series_cache_path(series_name)
        try:
            with io.open(path, 'w', encoding='utf8') as file:
                json.dump(series_data, file, indent=2)
            self.cleanup_series_cache(max_files=10)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error saving series cache: {str(e)}', level=xbmc.LOGERROR)
    def __init__(self, addon, profile):
        self.addon = addon
        self.profile = profile
        self.profile_path = profile  # Přidat pro kompatibilitu
        self.series_db_path = os.path.join(profile, 'series_db')
        self.preferences_path = os.path.join(profile, 'series_preferences.json')
        self.load_preferences()
        # In-memory cache for search queries within current session
        self._query_cache = {}
    
    def ensure_db_exists(self):
        """Ensure that the series database directory exists"""
        try:
            if not os.path.exists(self.profile):
                os.makedirs(self.profile)
            if not os.path.exists(self.series_db_path):
                os.makedirs(self.series_db_path)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error creating directories: {str(e)}', level=xbmc.LOGERROR)
    
    def load_preferences(self):
        """Načte preference ze souboru"""
        self.preferences = {}
        if os.path.exists(self.preferences_path):
            try:
                with io.open(self.preferences_path, 'r', encoding='utf8') as file:
                    self.preferences = json.load(file)
            except Exception as e:
                xbmc.log(f'Error loading preferences: {str(e)}', level=xbmc.LOGERROR)

    def save_preferences(self):
        """Uloží preference do souboru"""
        try:
            with io.open(self.preferences_path, 'w', encoding='utf8') as file:
                json.dump(self.preferences, file, indent=2)
        except Exception as e:
            xbmc.log(f'Error saving preferences: {str(e)}', level=xbmc.LOGERROR)

    def set_preferred_pattern(self, series_name, pattern, api_function=None, token=None):
        """Nastaví preferovaný vzor pro celý seriál a ihned přeřadí všechny epizody"""
        if api_function and token:
            self.search_series(series_name, api_function, token)
        if series_name not in self.preferences:
            self.preferences[series_name] = {}
        self.preferences[series_name]['preferred_pattern'] = pattern
        self.preferences[series_name]['force_pattern'] = True
        # Smaž všechny per-episode preference pro tento seriál
        if 'episode_patterns' in self.preferences[series_name]:
            self.preferences[series_name]['episode_patterns'] = {}
        self.save_preferences()
        self.load_preferences()  # Důležité! Načti nové preference, aby byly použity při přeřazení
        # Načti a přeřaď všechny epizody podle nového vzoru (s ohledem na per-episode preference)
        series_data = self.load_series_data(series_name)
        if not series_data or 'seasons' not in series_data:
            return
        changed = False
        for season_num, season in series_data['seasons'].items():
            for episode_num, episode_data in season.items():
                # Vždy volat _sort_streams s konkrétní sezónou a epizodou (per-episode preference už jsou smazané)
                sorted_streams = self._sort_streams(
                    episode_data['episodes'],
                    series_name,
                    season=str(season_num),
                    episode=str(episode_num)
                )
                xbmc.log(f'Tshare SeriesManager: Resorting S{season_num}E{episode_num} for {series_name} (streams: {len(sorted_streams)})', level=xbmc.LOGDEBUG)
                if episode_data['episodes'] != sorted_streams:
                    episode_data['episodes'] = sorted_streams
                    changed = True
        if changed:
            self._save_series_data(series_name, series_data)

    def set_episode_stream(self, series_name, season, episode, pattern):
        """Nastaví preferovaný stream pro konkrétní epizodu a ihned přeřadí danou epizodu"""
        if series_name not in self.preferences:
            self.preferences[series_name] = {}
        if 'episode_patterns' not in self.preferences[series_name]:
            self.preferences[series_name]['episode_patterns'] = {}
        episode_key = f"S{season}E{episode}"
        self.preferences[series_name]['episode_patterns'][episode_key] = pattern
        self.save_preferences()
        # Ihned přeřaď danou epizodu
        series_data = self.load_series_data(series_name)
        if not series_data or 'seasons' not in series_data:
            return
        season_str = str(season)
        episode_str = str(episode)
        if season_str in series_data['seasons'] and episode_str in series_data['seasons'][season_str]:
            episode_data = series_data['seasons'][season_str][episode_str]
            sorted_streams = self._sort_streams(episode_data['episodes'], series_name, season_str, episode_str)
            if episode_data['episodes'] != sorted_streams:
                episode_data['episodes'] = sorted_streams
                self._save_series_data(series_name, series_data)

    def get_preferred_pattern(self, series_name, season=None, episode=None):
        """Získá preferovaný vzor pro seriál nebo konkrétní epizodu"""
        if series_name not in self.preferences:
            return ''
            
        # Nejprve zkontroluj specifické nastavení epizody
        if season is not None and episode is not None:
            episode_key = f"S{season}E{episode}"
            episode_patterns = self.preferences[series_name].get('episode_patterns', {})
            if episode_key in episode_patterns:
                return episode_patterns[episode_key]
        
        # Pokud není specifické nastavení, vrať obecný vzor
        return self.preferences[series_name].get('preferred_pattern', '')

    def _sort_streams(self, episodes, series_name, season=None, episode=None):
        """Seřadí streamy s prioritou: per-episode pattern > global pattern > velikost"""
        episodes = list(episodes)
        pattern = None
        # 1. Per-episode pattern
        if season is not None and episode is not None and series_name in self.preferences:
            episode_key = f"S{season}E{episode}"
            episode_patterns = self.preferences[series_name].get('episode_patterns', {})
            if episode_key in episode_patterns:
                pattern = episode_patterns[episode_key]
        # 2. Global pattern (if force_pattern is set and no per-episode pattern)
        if not pattern and series_name in self.preferences and self.preferences[series_name].get('force_pattern', False):
            pattern = self.preferences[series_name].get('preferred_pattern', '')
        # 3. If pattern found, move matching stream to front
        if pattern:
            for i, ep in enumerate(episodes):
                if pattern.lower() in ep['name'].lower():
                    if i > 0:
                        episodes.insert(0, episodes.pop(i))
                    break
            return episodes
        # 4. Default: sort by size descending
        return sorted(episodes, key=lambda e: (-int(e.get('size', '0'))))
    
    def search_series(self, series_name, api_function, token):
        """Search for episodes of a series with improved error handling"""
        try:
            series_data = {
                'name': series_name,
                'last_updated': xbmc.getInfoLabel('System.Date'),
                'seasons': {}
            }
            
            all_results = self._perform_multi_search(series_name, api_function, token)
            if not all_results:
                return None
                
            # Process and organize results
            for item in all_results:
                season_num, episode_num = self._detect_episode_info(item['name'])
                
                if season_num is not None and episode_num is not None:
                    if self._is_likely_episode(item['name'], series_name, season_num, episode_num):
                        season_num_str = str(season_num)
                        episode_num_str = str(episode_num)
                        
                        if season_num_str not in series_data['seasons']:
                            series_data['seasons'][season_num_str] = {}
                        
                        if episode_num_str not in series_data['seasons'][season_num_str]:
                            series_data['seasons'][season_num_str][episode_num_str] = {
                                'episodes': []
                            }
                        
                        series_data['seasons'][season_num_str][episode_num_str]['episodes'].append({
                            'name': item['name'],
                            'ident': item['ident'],
                            'size': item.get('size', '0')
                        })
            
            # Sort episodes by quality preference and size
            for season in series_data['seasons'].values():
                for episode_data in season.values():
                    episode_data['episodes'] = self._sort_streams(episode_data['episodes'], series_name)
            
            # Save the series data
            self._save_series_data(series_name, series_data)
            # Ulož i do cache
            self.save_series_cache(series_name, series_data)
            return series_data
        except Exception as e:
            xbmc.log(f'Error in search_series: {str(e)}', level=xbmc.LOGERROR)
            return None
    
    # Helper: normalize filename to a comparable key (for dedup)
    def _normalize_key(self, name):
        try:
            n = unidecode.unidecode(name or '').lower()
            # remove common quality / lang tokens
            n = re.sub(r'\b(uhd|4k|2160p|1080p|720p|480p|hdr|x265|h265|x264|h264|hevc|dvdrip|brrip|webrip|web-dl|bluray|remux)\b', ' ', n)
            n = re.sub(r'\b(cz|czech|czdab|dabing|sk|slovak|tit|sub|subs|czsub|cz-tit)\b', ' ', n)
            # remove dots/underscores/dashes and years
            n = re.sub(r'\b(19|20)\d{2}\b', ' ', n)
            n = re.sub(r'[^a-z0-9]+', '', n)
            return n.strip()
        except Exception:
            return (name or '').strip().lower()

    # Helper: pick better result (by size desc)
    def _prefer_better(self, current, candidate):
        def _sz(it):
            try:
                return int(it.get('size') or '0')
            except Exception:
                return 0
        return candidate if _sz(candidate) > _sz(current) else current

    # Formát velikosti v MB/GB
    def _format_size(self, size_value):
        try:
            size = int(size_value or 0)
        except Exception:
            return ''
        if size <= 0:
            return ''
        gb = size / float(1024 ** 3)
        if gb >= 1:
            return f'{gb:.2f} GB'
        mb = size / float(1024 ** 2)
        return f'{mb:.0f} MB'

    # Vyčistí text na slovní název epizody z názvu souboru
    def _clean_title(self, raw_name, series_name):
        try:
            name = str(raw_name or '')
            # odstranění přípon a tagů v závorkách
            name = re.sub(r'\.[a-z0-9]{2,4}$', '', name, flags=re.I)
            name = re.sub(r'[\[\(\{].*?[\]\)\}]', ' ', name)
            # odstranit epizodní patterny
            patts = [
                r'[Ss]\d{1,2}[Ee]\d{1,2}',
                r'\b\d{1,2}x\d{1,2}\b',
                r'\b[Ee][Pp]?\s?\d{1,2}\b',
                r'\b\d{1,2}\s*d[íi]l\b',
                r'\b\d{1,2}\.\s*d[íi]l\b',
                r'\b\d{1,2}\.\s*cast\b',
                r'\bcast\s*\d{1,2}\b',
                r'\bseason\s*\d{1,2}\b',
                r'\bepisode\s*\d{1,2}\b',
            ]
            for p in patts:
                name = re.sub(p, ' ', name, flags=re.I)
            # odstranit kvalitu/jazyk/codec tagy
            name = re.sub(
                r'\b(uhd|4k|2160p|1080p|720p|480p|hdr|x265|h265|x264|h264|hevc|dvdrip|brrip|webrip|web[-_. ]?dl|bluray|remux|aac|mp3|dts|atmos|10bit|10b|cz|czech|czdab|dabing|sk|slovak|tit|sub|subs|czsub|cz[-_. ]?tit|c4u)\b',
                ' ',
                name,
                flags=re.I
            )
            # odstranit klíčová slova názvu seriálu
            for kw in self._series_keywords(series_name):
                name = re.sub(rf'\b{re.escape(kw)}\b', ' ', name, flags=re.I)
            # sjednotit oddělovače
            name = re.sub(r'[._\-]+', ' ', name)
            name = re.sub(r'\s+', ' ', name).strip(' -–—\u2022').strip()
            # fallback pokud nic nezůstalo
            return name or str(raw_name or '').strip()
        except Exception:
            return str(raw_name or '').strip()

    # Sestaví jednotný název: "Díl X — <slovní název> • <velikost>"
    def _build_episode_label(self, series_name, raw_stream_name, size_value, season=None, episode=None):
        title = self._clean_title(raw_stream_name, series_name)
        # prefix "Díl X —" pokud známe číslo epizody
        prefix = ''
        try:
            if episode is not None:
                prefix = f'Díl {int(str(episode))} — '
        except Exception:
            prefix = ''
        size_str = self._format_size(size_value)
        base = (prefix + title).strip() if title else (prefix[:-3] if prefix.endswith(' — ') else (raw_stream_name or ''))
        return base + (f' • {size_str}' if size_str else '')

    def _perform_search(self, search_query, api_function, token, max_retries=2):
        """Perform the actual search using the provided API function with pagination and retry logic + in-memory cache"""
        # Serve from cache if available
        if search_query in getattr(self, '_query_cache', {}):
            return list(self._query_cache[search_query])

        all_results = []
        limit = 75
        offset = 0
        max_pages = 4
        current_page = 0

        while current_page < max_pages:
            retry_count = 0
            while retry_count < max_retries:
                try:
                    response = api_function('search', {
                        'what': search_query,
                        'category': 'video',
                        'sort': 'recent',
                        'limit': limit,
                        'offset': offset,
                        'wst': token,
                        'maybe_removed': 'true'
                    })
                    if not response or not response.content:
                        retry_count += 1
                        xbmc.sleep(300)
                        continue
                    try:
                        xml = ET.fromstring(response.content)
                        status = xml.find('status')
                        if status is None or status.text != 'OK':
                            break
                        results_in_page = 0
                        for file in xml.iter('file'):
                            item = {}
                            for elem in file:
                                item[elem.tag] = elem.text
                            if item:
                                all_results.append(item)
                                results_in_page += 1
                        if results_in_page < limit:
                            # Cache before returning
                            self._query_cache[search_query] = list(all_results)
                            return all_results
                        break
                    except ET.ParseError:
                        if retry_count == max_retries - 1:
                            self._query_cache[search_query] = list(all_results)
                            return all_results
                        retry_count += 1
                        xbmc.sleep(300)
                except Exception:
                    if retry_count == max_retries - 1:
                        self._query_cache[search_query] = list(all_results)
                        return all_results
                    retry_count += 1
                    xbmc.sleep(300)
            offset += limit
            current_page += 1

        # Cache full result
        self._query_cache[search_query] = list(all_results)
        return all_results

    def _perform_multi_search(self, series_name, api_function, token):
        """Optimized multi-query search with CZ priority, episode patterns and early stopping."""
        search_queries = []

        # Base normalized names
        base = unidecode.unidecode(series_name or '').lower()
        base = re.sub(r'[^a-z0-9& ]', '', base).strip()
        base_dot = base.replace(' ', '.')
        base_dash = base.replace(' ', '-')
        base_us  = base.replace(' ', '_')

        # 1) CZ-first queries
        search_queries.extend([
            f'{base} cz',
            f'{base_dot} cz',
            f'{base} czech',
            f'{base} cesky'
        ])

        # 2) Solid general fallbacks
        search_queries.extend([
            base,
            base_dot,
            base_dash,
            base_us,
        ])

        # 3) Episode-patterns for S01 and S02 (first 12 eps each) – most effective formats first
        for season in (1, 2):
            for ep in range(1, 13):
                search_queries.append(f'{base} s{season:02d}e{ep:02d}')
                search_queries.append(f'{base} {season}x{ep:02d}')
                if season == 1:
                    search_queries.append(f'{base} cz s{season:02d}e{ep:02d}')

        # 4) Czech "díl" patterns (first 12 parts)
        for part in range(1, 13):
            search_queries.append(f'{base} {part:02d}.dil')
            search_queries.append(f'{base} {part}.dil')
            search_queries.append(f'{base} {part:02d}.cast')

        # Compact the plan
        # Limit to 45 queries (balanced)
        search_queries = [q for q in search_queries if q.strip()][:45]

        all_results = []
        seen_idents = set()

        # Dedup by normalized key -> keep best by size
        grouped = {}

        # Track coverage to stop early when we have enough good episodes
        from collections import defaultdict
        season_coverage = defaultdict(set)

        def register_item(item):
            name = item.get('name') or ''
            key = self._normalize_key(name)
            if not key:
                return False
            if key in grouped:
                best = self._prefer_better(grouped[key], item)
                if best is not grouped[key]:
                    grouped[key] = best
                    return True
                return False
            grouped[key] = item
            return True

        def update_coverage(item):
            try:
                fn = item.get('name') or ''
                s, e = self._detect_episode_info(fn)
                if s is not None and e is not None:
                    season_coverage[str(s)].add(int(e))
            except Exception:
                pass

        def should_stop():
            total_eps = sum(len(v) for v in season_coverage.values())
            # Stop if we already have solid coverage for first 2 seasons or overall >= 24 eps
            if total_eps >= 24:
                return True
            s1 = len(season_coverage.get('1', set()))
            s2 = len(season_coverage.get('2', set()))
            # Good baseline: at least 10 eps S1 and 6 eps S2
            if s1 >= 10 and s2 >= 6:
                return True
            # Or enough unique groups overall
            if len(grouped) >= 80:
                return True
            return False

        for query in search_queries:
            results = self._perform_search(query, api_function, token)
            for item in results:
                ident = item.get('ident')
                if not ident or ident in seen_idents:
                    continue
                # Add or improve grouped entry
                added_or_improved = register_item(item)
                if added_or_improved:
                    seen_idents.add(ident)
                    update_coverage(item)
            # Early stop check after each query
            if should_stop():
                break

        # Flatten grouped to all_results preserving best candidates only
        all_results = list(grouped.values())
        return all_results

    # Uvolněné limity pro detekci S/E (méně false-negative)
    def _detect_episode_info(self, filename):
        """Try to detect season and episode numbers from filename using only patterns"""
        cleaned = unidecode.unidecode(filename).lower()
        
        for pattern in EPISODE_PATTERNS:
            match = re.search(pattern, cleaned)
            if match:
                groups = match.groups()
                if len(groups) == 2:
                    season, episode = int(groups[0]), int(groups[1])
                    if 1 <= season <= 25 and 1 <= episode <= 60:
                        return season, episode
                elif len(groups) == 1:
                    episode = int(groups[0])
                    if 1 <= episode <= 60:
                        return 1, episode
        
        return None, None

    # Klíčová slova ze jména seriálu (bez diakritiky, min. délka 3, bez obecných slov)
    def _series_keywords(self, series_name):
        s = unidecode.unidecode(series_name or '').lower()
        s = re.sub(r'[^a-z0-9 ]+', ' ', s)
        words = [w for w in s.split() if len(w) >= 3]
        stop = {
            'tshare','the','and','und','der','die','das',
            'cz','czech','cesky','sk','slovak',
            'episode','ep','dil','cast','serie','serial','season','sezona','rada'
        }
        return [w for w in words if w not in stop]

    # Přísná verze: musí sedět klíčová slova názvu seriálu a jasný epizodní pattern
    def _is_likely_episode(self, filename, series_name, season_num, episode_num):
        """Přísná verze: musí sedět klíčová slova názvu seriálu a jasný epizodní pattern."""
        normalized_filename = unidecode.unidecode(filename or '').lower()
        def normalize(s):
            return re.sub(r'[^a-z0-9 ]', ' ', s).replace('  ', ' ').strip()
        norm_fn = normalize(normalized_filename)

        # 1) Kontrola klíčových slov názvu seriálu
        keywords = self._series_keywords(series_name)
        fn_tokens = set(norm_fn.split())
        if not keywords:
            return False

        if len(keywords) <= 2:
            # U krátkých názvů (2 slova) trvej na všech
            if not all(k in fn_tokens for k in keywords):
                return False
        else:
            # U delších názvů vyžaduj aspoň 70 % klíčových slov (min. 3)
            required = max(3, int(round(0.7 * len(keywords))))
            hits = sum(1 for k in keywords if k in fn_tokens)
            if hits < required:
                return False

        # 2) Musí být jasný pattern epizody (SxxExx / xXxx / Ep)
        s_e_pattern = f"s{season_num:02d}e{episode_num:02d}"
        x_x_pattern = f"{season_num}x{episode_num:02d}"
        ep_pattern1 = f"ep{episode_num:02d}"
        ep_pattern2 = f"e{episode_num:02d}"
        dot_pattern = f"{season_num}.{episode_num:02d}"
        if any(p in norm_fn for p in [s_e_pattern, x_x_pattern, ep_pattern1, ep_pattern2, dot_pattern]):
            return True

        # 3) Slabší slovní varianta jen pro S1 a bez zmínek o jiné sezóně
        if season_num == 1 and (f"episode {episode_num}" in norm_fn or f"epizoda {episode_num}" in norm_fn):
            if not re.search(r's[2-9]|season [2-9]', norm_fn):
                return True

        return False

    # Zjistí, zda má seriál/řada chybějící díly (mezery v intervalu 1..max)
    def has_missing(self, series_name, season=None):
        try:
            data = self.load_series_data(series_name) or {}
            seasons = data.get('seasons') or {}

            def season_has_gap(eps_dict):
                nums = sorted(int(n) for n in eps_dict.keys() if str(n).isdigit())
                if not nums:
                    return False
                mx = max(nums)
                # chybí-li cokoliv mezi 1..max, je mezera
                return any(str(i) not in eps_dict for i in range(1, mx + 1))

            if season is None:
                for _, eps in seasons.items():
                    if season_has_gap(eps):
                        return True
                return False
            else:
                return season_has_gap(seasons.get(str(season)) or {})
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: has_missing error: {e}', level=xbmc.LOGERROR)
            return False

# Pomocná funkce pro tvorbu plugin URL (bez závislosti na Tshare.get_url)
def _plugin_url(**kwargs):
    try:
        import sys
        base = sys.argv[0]
    except Exception:
        base = ''
    try:
        return f'{base}?{urlencode(kwargs, doseq=True)}'
    except TypeError:
        # Fallback bez doseq pro starší Python/Kodi
        return f'{base}?{urlencode(kwargs)}'

# --- UI funkce volané z Tshare.py ---

def create_series_menu(sm, handle):
    """
    Hlavní menu seriálů:
    - Vyhledávání seriálu
    - Seznam uložených seriálů (z DB)
    """
    try:
        # 1) Vyhledávání
        li = xbmcgui.ListItem(label='Vyhledat seriál')
        li.setArt({'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'})
        xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_search'), li, True)

        # 2) Seznam seriálů z DB
        if not os.path.exists(sm.series_db_path):
            xbmcplugin.endOfDirectory(handle)
            return

        for fname in sorted(os.listdir(sm.series_db_path)):
            if not fname.endswith('.json'):
                continue
            try:
                fpath = os.path.join(sm.series_db_path, fname)
                with io.open(fpath, 'r', encoding='utf8') as f:
                    data = json.load(f)
                series_name = data.get('name') or os.path.splitext(fname)[0]
                label = series_name

                li = xbmcgui.ListItem(label=label)
                li.setArt({'icon': 'DefaultTVShows.png', 'thumb': 'DefaultTVShows.png'})

                # Připrav přímý URL na další díl (pokud existuje)
                ns, ne, best = sm.get_next_episode(series_name)
                if best:
                    play_url = _plugin_url(
                        action='play',
                        ident=best.get('ident'),
                        name=best.get('name'),
                        series_name=series_name,
                        season=str(ns) if ns is not None else '',
                        episode=str(ne) if ne is not None else '',
                        episode_title=best.get('name')
                    )
                    play_next_cm = ('Přehrát další díl', f'RunPlugin({play_url})')
                else:
                    play_next_cm = ('Přehrát další díl', f'Container.Update({_plugin_url(action="series_detail", series_name=series_name)})')

                # Kontextové menu včetně chybějících (vždy k dispozici na úrovni seriálu)
                cm = [
                    play_next_cm,
                    ('Aktualizovat seriál', f'Container.Update({_plugin_url(action="series_refresh", series_name=series_name)})'),
                ]
                if sm.has_missing(series_name):
                    cm.append(('Hledat chybějící díly', f'Container.Update({_plugin_url(action="search_missing_episodes", series_name=series_name)})'))
                cm.append(('Smazat seriál', f'RunPlugin({_plugin_url(action="delete_series", series_name=series_name)})'))
                li.addContextMenuItems(cm)

                xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_detail', series_name=series_name), li, True)
            except Exception as e:
                xbmc.log(f'SeriesManager menu: skip file {fname}: {e}', level=xbmc.LOGWARNING)

        # 3) Historie
        li = xbmcgui.ListItem(label='Historie seriálů')
        li.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_history'), li, True)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_series_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_seasons_menu_from_data(sm, handle, series_name, series_data):
    """Výpis řad ze zadaných dat (cache)."""
    try:
        seasons = (series_data or {}).get('seasons') or {}
        if not seasons:
            xbmcgui.Dialog().notification('Tshare', 'Pro tento seriál nejsou k dispozici žádné řady', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        # Přehrát další díl (přímo přes action=play)
        ns, ne, best = sm.get_next_episode(series_name)
        if best:
            play_next = xbmcgui.ListItem(label='Přehrát další díl')
            play_next.setProperty('IsPlayable', 'true')
            # Přelož special:// cestu a najdi ikonu
            addon_path = translatePath(sm.addon.getAddonInfo('path'))
            play_icon = os.path.join(addon_path, 'resources', 'media', 'play.png')
            if not os.path.exists(play_icon):
                play_icon = 'DefaultVideo.png'
            play_next.setArt({'icon': play_icon, 'thumb': play_icon, 'poster': play_icon})
            try:
                play_next.setIconImage(play_icon)  # kompatibilita se staršími skiny
            except Exception:
                pass
            # ZMĚNA: vlastní ikona přehrávání
            # play_icon = os.path.join(sm.addon.getAddonInfo('path'), 'resource', 'media', 'play.png')
            # if os.path.exists(play_icon):
            #     play_next.setArt({'icon': play_icon, 'thumb': play_icon})
            play_url = _plugin_url(
                action='play',
                ident=best.get('ident'),
                name=best.get('name'),
                series_name=series_name,
                season=str(ns) if ns is not None else '',
                episode=str(ne) if ne is not None else '',
                episode_title=best.get('name')
            )
            label_norm = sm._build_episode_label(series_name, best.get('name'), best.get('size'), season=ns, episode=ne)
            # Dříve: play_next.setLabel(f'> Přehrát další díl — {label_norm}')
            play_next.setLabel(f'• [B][COLOR cyan]Přehrát další díl[/COLOR][/B] — {label_norm}')
            xbmcplugin.addDirectoryItem(handle, play_url, play_next, False)

        for season in sorted(seasons.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
            ep_count = len(seasons[season])
            li = xbmcgui.ListItem(label=f'Řada {season} ({ep_count} dílů)')
            # Prefer addon icon, fallback to built-in default
            addon_path = translatePath(sm.addon.getAddonInfo('path'))
            season_icon = os.path.join(addon_path, 'resources', 'media', 'season.png')
            if not os.path.exists(season_icon):
                season_icon = 'DefaultTVShows.png'
            li.setArt({'icon': season_icon, 'thumb': season_icon, 'poster': season_icon})
            try:
                li.setIconImage(season_icon)  # compatibility with older skins
            except Exception:
                pass
            cm = [
                (f'Aktualizovat řadu {season}', f'Container.Update({_plugin_url(action="series_refresh", series_name=series_name, season=season)})'),
            ]
            if sm.has_missing(series_name, season=season):
                cm.insert(0, (f'Hledat chybějící díly v řadě {season}', f'Container.Update({_plugin_url(action="search_missing_episodes", series_name=series_name, season=season)})'))
            # nově: obnovit chytré řazení pro tuto řadu
            cm.append((f'Obnovit chytré řazení streamů (řada {season})', f'RunPlugin({_plugin_url(action="restore_smart_ordering", series_name=series_name, season=season)})'))
            li.addContextMenuItems(cm)

            xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_season', series_name=series_name, season=season), li, True)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_seasons_menu_from_data error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_seasons_menu(sm, handle, series_name):
    """Výpis řad načtením z DB."""
    try:
        data = sm.load_series_data(series_name)
        if not data:
            xbmcgui.Dialog().notification('Tshare', 'Data seriálu nenalezena', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        create_seasons_menu_from_data(sm, handle, series_name, data)
    except Exception as e:
        xbmc.log(f'create_seasons_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_episodes_menu(sm, handle, series_name, season):
    """Výpis epizod v dané řadě, položky jsou přehrávatelné (preferovaný/první stream)."""
    try:
        data = sm.load_series_data(series_name) or {}
        seasons = data.get('seasons') or {}
        eps = (seasons.get(str(season)) or {})
        if not eps:
            xbmcgui.Dialog().notification('Tshare', f'Řada {season} nemá žádné epizody', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        # Akce pro řadu – nahoře, “Hledat chybějící” jen pokud je co dohledat
        li_update = xbmcgui.ListItem(label='Aktualizovat řadu')
        li_update.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        li_update.addContextMenuItems([
            ('Obnovit chytré řazení (tato řada)', f'RunPlugin({_plugin_url(action="restore_smart_ordering", series_name=series_name, season=str(season))})')
        ])
        xbmcplugin.addDirectoryItem(handle, _plugin_url(action='series_refresh', series_name=series_name, season=str(season)), li_update, True)

        if sm.has_missing(series_name, season=season):
            li_missing = xbmcgui.ListItem(label='Hledat chybějící díly v řadě')
            li_missing.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(handle, _plugin_url(action='search_missing_episodes', series_name=series_name, season=str(season)), li_missing, True)

        # Prepare addon path for per-item icons (fallback to DefaultVideo.png)
        addon_path = translatePath(sm.addon.getAddonInfo('path'))
        episode_icon_path = os.path.join(addon_path, 'resources', 'media', 'episode.png')
        if not os.path.exists(episode_icon_path):
            episode_icon_path = 'DefaultVideo.png'

        # Přehrát další díl v řadě – přímo přes action=play
        ns, ne, nbest = sm.get_next_episode_in_season(series_name, season)
        if nbest:
            label_norm = sm._build_episode_label(series_name, nbest.get('name'), nbest.get('size'), season=ns, episode=ne)
            play_next_s = xbmcgui.ListItem(label=f'• [B][COLOR cyan]Přehrát další díl v této řadě[/COLOR][/B] — {label_norm}')
            play_next_s.setProperty('IsPlayable', 'true')
            # Přelož special:// cestu a najdi ikonu
            addon_path = translatePath(sm.addon.getAddonInfo('path'))
            play_icon = os.path.join(addon_path, 'resources', 'media', 'play.png')
            if not os.path.exists(play_icon):
                play_icon = os.path.join(addon_path, 'resource', 'media', 'play.png')
            if os.path.exists(play_icon):
                play_next_s.setArt({'icon': play_icon, 'thumb': play_icon, 'poster': play_icon})
                try:
                    play_next_s.setIconImage(play_icon)  # kompatibilita se staršími skiny
                except Exception:
                    pass
            play_next_s_url = _plugin_url(
                action='play',
                ident=nbest.get('ident'),
                name=nbest.get('name'),
                series_name=series_name,
                season=str(ns) if ns is not None else '',
                episode=str(ne) if ne is not None else '',
                episode_title=nbest.get('name')
            )
            xbmcplugin.addDirectoryItem(handle, play_next_s_url, play_next_s, False)

        # Získat poslední shlédnutou epizodu kvůli označení
        last_s, last_e = sm.get_last_watched_episode(series_name)
        try:
            last_s = str(last_s) if last_s is not None else None
            last_e = str(last_e) if last_e is not None else None
        except Exception:
            last_s = last_s
            last_e = last_e

        for ep_num in sorted(eps.keys(), key=lambda x: int(x) if str(x).isdigit() else x):
            ep_data = eps[ep_num] or {}
            streams = list(ep_data.get('episodes') or [])
            if not streams:
                continue
            streams = sm._sort_streams(streams, series_name, str(season), str(ep_num))
            best = streams[0]
            is_last_watched = (str(season) == str(last_s) and str(ep_num) == str(last_e))
            base_label = sm._build_episode_label(series_name, best.get('name'), best.get('size'), season=season, episode=ep_num)
            label = f'[COLOR yellow]★shlédnuto[/COLOR] | {base_label}' if is_last_watched else base_label

            li = xbmcgui.ListItem(label=label)
            # Set a valid icon for the episode item
            li.setArt({'icon': episode_icon_path, 'thumb': episode_icon_path, 'poster': episode_icon_path})
            try:
                li.setIconImage(episode_icon_path)  # compatibility with older skins
            except Exception:
                pass
            li.setProperty('IsPlayable', 'true')
            try:
                li.setInfo('video', {
                    'title': base_label,
                    'tvshowtitle': series_name,
                    'season': int(season) if str(season).isdigit() else season,
                    'episode': int(ep_num) if str(ep_num).isdigit() else ep_num,
                    'playcount': 1 if is_last_watched else 0,
                    'overlay': 7 if is_last_watched else 0
                })
            except Exception:
                pass

            # rozšířený kontext pro epizodu
            li.addContextMenuItems([
                ('Vybrat jiný stream…', f'RunPlugin({_plugin_url(action="select_stream", series_name=series_name, season=str(season), episode=str(ep_num))})'),
                ('Obnovit chytré řazení streamů (tato řada)', f'RunPlugin({_plugin_url(action="restore_smart_ordering", series_name=series_name, season=str(season))})')
            ])

            url = _plugin_url(
                action='play',
                ident=best.get('ident'),
                name=best.get('name'),
                series_name=series_name,
                season=str(season),
                episode=str(ep_num),
                episode_title=best.get('name')
            )
            xbmcplugin.addDirectoryItem(handle, url, li, False)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_episodes_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def create_series_history_menu(sm, handle):
    """Zobrazení historie přehrávání seriálů."""
    try:
        history = sm.get_series_history()
        if not history:
            xbmcgui.Dialog().notification('Tshare', 'Historie seriálů je prázdná', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        for i, entry in enumerate(history):
            series_name = entry.get('series_name', 'Seriál')
            season = entry.get('season', '?')
            episode = entry.get('episode', '?')
            title = entry.get('episode_title') or f'S{season}E{episode}'

            label = f'{series_name} — S{season}E{episode} — {title}'
            li = xbmcgui.ListItem(label=label)
            li.setProperty('IsPlayable', 'true')

            # Kontext: odstranit z historie (Tshare.delete_series_history očekává history_index)
            li.addContextMenuItems([
                ('Odstranit z historie', f'RunPlugin({_plugin_url(action="delete_series_history", history_index=i, series_label=label)})')
            ])

            # Pokud máme uložený stream_url, přehrát přímo; jinak přehrát přes ident/heuristiku v Tshare
            params = {
                'action': 'play_series_history',
                'series_name': series_name,
                'season': season,
                'episode': episode
            }
            if entry.get('stream_url'):
                params['stream_url'] = entry['stream_url']

            xbmcplugin.addDirectoryItem(handle, _plugin_url(**params), li, False)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'create_series_history_menu error: {e}', level=xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)