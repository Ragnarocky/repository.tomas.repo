# -*- coding: utf-8 -*-
# Module: series_manager
# Author: Tomas for friends
# Created on: 2.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import os
import io
import re
import json
import logging
import xbmc
import xbmcaddon
import xbmcgui
import xml.etree.ElementTree as ET
import unidecode
import traceback

try:
    from urllib import urlencode
    from urlparse import parse_qsl
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

# Regular expressions for detecting episode patterns
EPISODE_PATTERNS = [
    r'[Ss](\d+)[Ee](\d+)',      # S01E01 format
    r'(\d+)x(\d+)',             # 1x01 format
    r'(\d+)\.\s*d[íi]l',        # 01.díl, 02.díl format (český)
    r'-\s*(\d+)\.\s*d[íi]l',    # - 01.díl format
    r'(\d+)\s+d[íi]l',          # 01 díl format (bez tečky)
    r'(\d+)\.\s*cast',          # 01.cast, 02.cast format
    r'[Ee]pisode\s*(\d+)',      # Episode 1 format
    r'[Ee]p\s*(\d+)',           # Ep 1 format
    r'[Ee](\d+)\b',             # E1 format (s word boundary)
    r'(\d+)\.\s*(\d+)'          # 1.01 format
]

class SeriesManager:
    def cleanup_series_cache(self, max_files=10):
        """Ponechá pouze max_files nejnovějších cache souborů v series_cache."""
        cache_dir = self.get_cache_dir()
        files = [os.path.join(cache_dir, f) for f in os.listdir(cache_dir) if f.endswith('.json')]
        files = sorted(files, key=lambda f: os.path.getmtime(f), reverse=True)
        for f in files[max_files:]:
            try:
                os.remove(f)
            except Exception:
                pass
    def get_cache_dir(self):
        cache_dir = os.path.join(self.profile, 'series_cache')
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        return cache_dir

    def get_series_cache_path(self, series_name):
        safe_name = self._safe_filename(series_name)
        return os.path.join(self.get_cache_dir(), f"{safe_name}.json")

    def load_series_cache(self, series_name, max_age_days=7):
        """Načte cache seriálu, pokud existuje a není starší než max_age_days."""
        import time
        path = self.get_series_cache_path(series_name)
        if not os.path.exists(path):
            return None
        
        try:
            mtime = os.path.getmtime(path)
            age_days = (time.time() - mtime) / 86400
            if age_days > max_age_days:
                # Smaž starý cache soubor
                try:
                    os.remove(path)
                except Exception:
                    pass
                return None
                
            with io.open(path, 'r', encoding='utf8') as file:
                return json.load(file)
        except (IOError, ValueError, json.JSONDecodeError) as e:
            xbmc.log(f'Series cache error for {series_name}: {str(e)}', level=xbmc.LOGWARNING)
            # Smaž poškozený cache soubor
            try:
                os.remove(path)
            except Exception:
                pass
            return None

    def save_series_cache(self, series_name, series_data):
        """Uloží výsledky hledání seriálu do cache a udržuje max. 10 souborů."""
        path = self.get_series_cache_path(series_name)
        try:
            with io.open(path, 'w', encoding='utf8') as file:
                json.dump(series_data, file, indent=2)
            self.cleanup_series_cache(max_files=10)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error saving series cache: {str(e)}', level=xbmc.LOGERROR)
    def __init__(self, addon, profile):
        self.addon = addon
        self.profile = profile
        self.profile_path = profile  # Přidat pro kompatibilitu
        self.series_db_path = os.path.join(profile, 'series_db')
        self.preferences_path = os.path.join(profile, 'series_preferences.json')
        self.load_preferences()
    
    def ensure_db_exists(self):
        """Ensure that the series database directory exists"""
        try:
            if not os.path.exists(self.profile):
                os.makedirs(self.profile)
            if not os.path.exists(self.series_db_path):
                os.makedirs(self.series_db_path)
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error creating directories: {str(e)}', level=xbmc.LOGERROR)
    
    def load_preferences(self):
        """Načte preference ze souboru"""
        self.preferences = {}
        if os.path.exists(self.preferences_path):
            try:
                with io.open(self.preferences_path, 'r', encoding='utf8') as file:
                    self.preferences = json.load(file)
            except Exception as e:
                xbmc.log(f'Error loading preferences: {str(e)}', level=xbmc.LOGERROR)

    def save_preferences(self):
        """Uloží preference do souboru"""
        try:
            with io.open(self.preferences_path, 'w', encoding='utf8') as file:
                json.dump(self.preferences, file, indent=2)
        except Exception as e:
            xbmc.log(f'Error saving preferences: {str(e)}', level=xbmc.LOGERROR)

    def set_preferred_pattern(self, series_name, pattern, api_function=None, token=None):
        """Nastaví preferovaný vzor pro celý seriál a ihned přeřadí všechny epizody"""
        if api_function and token:
            self.search_series(series_name, api_function, token)
        if series_name not in self.preferences:
            self.preferences[series_name] = {}
        self.preferences[series_name]['preferred_pattern'] = pattern
        self.preferences[series_name]['force_pattern'] = True
        # Smaž všechny per-episode preference pro tento seriál
        if 'episode_patterns' in self.preferences[series_name]:
            self.preferences[series_name]['episode_patterns'] = {}
        self.save_preferences()
        self.load_preferences()  # Důležité! Načti nové preference, aby byly použity při přeřazení
        # Načti a přeřaď všechny epizody podle nového vzoru (s ohledem na per-episode preference)
        series_data = self.load_series_data(series_name)
        if not series_data or 'seasons' not in series_data:
            return
        changed = False
        for season_num, season in series_data['seasons'].items():
            for episode_num, episode_data in season.items():
                # Vždy volat _sort_streams s konkrétní sezónou a epizodou (per-episode preference už jsou smazané)
                sorted_streams = self._sort_streams(
                    episode_data['episodes'],
                    series_name,
                    season=str(season_num),
                    episode=str(episode_num)
                )
                xbmc.log(f'Tshare SeriesManager: Resorting S{season_num}E{episode_num} for {series_name} (streams: {len(sorted_streams)})', level=xbmc.LOGDEBUG)
                if episode_data['episodes'] != sorted_streams:
                    episode_data['episodes'] = sorted_streams
                    changed = True
        if changed:
            self._save_series_data(series_name, series_data)

    def set_episode_stream(self, series_name, season, episode, pattern):
        """Nastaví preferovaný stream pro konkrétní epizodu a ihned přeřadí danou epizodu"""
        if series_name not in self.preferences:
            self.preferences[series_name] = {}
        if 'episode_patterns' not in self.preferences[series_name]:
            self.preferences[series_name]['episode_patterns'] = {}
        episode_key = f"S{season}E{episode}"
        self.preferences[series_name]['episode_patterns'][episode_key] = pattern
        self.save_preferences()
        # Ihned přeřaď danou epizodu
        series_data = self.load_series_data(series_name)
        if not series_data or 'seasons' not in series_data:
            return
        season_str = str(season)
        episode_str = str(episode)
        if season_str in series_data['seasons'] and episode_str in series_data['seasons'][season_str]:
            episode_data = series_data['seasons'][season_str][episode_str]
            sorted_streams = self._sort_streams(episode_data['episodes'], series_name, season_str, episode_str)
            if episode_data['episodes'] != sorted_streams:
                episode_data['episodes'] = sorted_streams
                self._save_series_data(series_name, series_data)

    def get_preferred_pattern(self, series_name, season=None, episode=None):
        """Získá preferovaný vzor pro seriál nebo konkrétní epizodu"""
        if series_name not in self.preferences:
            return ''
            
        # Nejprve zkontroluj specifické nastavení epizody
        if season is not None and episode is not None:
            episode_key = f"S{season}E{episode}"
            episode_patterns = self.preferences[series_name].get('episode_patterns', {})
            if episode_key in episode_patterns:
                return episode_patterns[episode_key]
        
        # Pokud není specifické nastavení, vrať obecný vzor
        return self.preferences[series_name].get('preferred_pattern', '')

    def _sort_streams(self, episodes, series_name, season=None, episode=None):
        """Seřadí streamy s prioritou: per-episode pattern > global pattern > velikost"""
        episodes = list(episodes)
        pattern = None
        # 1. Per-episode pattern
        if season is not None and episode is not None and series_name in self.preferences:
            episode_key = f"S{season}E{episode}"
            episode_patterns = self.preferences[series_name].get('episode_patterns', {})
            if episode_key in episode_patterns:
                pattern = episode_patterns[episode_key]
        # 2. Global pattern (if force_pattern is set and no per-episode pattern)
        if not pattern and series_name in self.preferences and self.preferences[series_name].get('force_pattern', False):
            pattern = self.preferences[series_name].get('preferred_pattern', '')
        # 3. If pattern found, move matching stream to front
        if pattern:
            for i, ep in enumerate(episodes):
                if pattern.lower() in ep['name'].lower():
                    if i > 0:
                        episodes.insert(0, episodes.pop(i))
                    break
            return episodes
        # 4. Default: sort by size descending
        return sorted(episodes, key=lambda e: (-int(e.get('size', '0'))))
    
    def search_series(self, series_name, api_function, token):
        """Search for episodes of a series with improved error handling"""
        try:
            series_data = {
                'name': series_name,
                'last_updated': xbmc.getInfoLabel('System.Date'),
                'seasons': {}
            }
            
            all_results = self._perform_multi_search(series_name, api_function, token)
            if not all_results:
                return None
                
            # Process and organize results
            for item in all_results:
                season_num, episode_num = self._detect_episode_info(item['name'])
                
                if season_num is not None and episode_num is not None:
                    if self._is_likely_episode(item['name'], series_name, season_num, episode_num):
                        season_num_str = str(season_num)
                        episode_num_str = str(episode_num)
                        
                        if season_num_str not in series_data['seasons']:
                            series_data['seasons'][season_num_str] = {}
                        
                        if episode_num_str not in series_data['seasons'][season_num_str]:
                            series_data['seasons'][season_num_str][episode_num_str] = {
                                'episodes': []
                            }
                        
                        series_data['seasons'][season_num_str][episode_num_str]['episodes'].append({
                            'name': item['name'],
                            'ident': item['ident'],
                            'size': item.get('size', '0')
                        })
            
            # Sort episodes by quality preference and size
            for season in series_data['seasons'].values():
                for episode_data in season.values():
                    episode_data['episodes'] = self._sort_streams(episode_data['episodes'], series_name)
            
            # Save the series data
            self._save_series_data(series_name, series_data)
            # Ulož i do cache
            self.save_series_cache(series_name, series_data)
            return series_data
        except Exception as e:
            xbmc.log(f'Error in search_series: {str(e)}', level=xbmc.LOGERROR)
            return None
    
    def _is_likely_episode(self, filename, series_name, season_num, episode_num):
        """Check if a filename is likely to be an episode of the series based on patterns and name (vylepšeno)"""
        normalized_filename = unidecode.unidecode(filename).lower()
        normalized_series_name = unidecode.unidecode(series_name).lower().replace(':', '').replace('-', ' ')
        def normalize(s):
            return re.sub(r'[^a-z0-9 ]', '', s).replace('  ', ' ').strip()
        norm_fn = normalize(normalized_filename)
        norm_sn = normalize(normalized_series_name)
        # Hlavní název musí být v názvu souboru (tolerantně)
        if not any(part in norm_fn for part in [norm_sn, norm_sn.replace(' ', ''), norm_sn.replace(' ', '.')]):
            # Fuzzy matching (pokud je k dispozici)
            try:
                from fuzzywuzzy import fuzz
                if fuzz.partial_ratio(norm_sn, norm_fn) < 70:  # Sníženo z 80 na 70
                    return False
            except ImportError:
                # Fallback bez fuzzywuzzy - jednodušší matching
                words = norm_sn.split()
                if len(words) > 1:
                    # Pokud má název více slov, stačí najít alespoň polovinu
                    found_words = sum(1 for word in words if word in norm_fn)
                    if found_words < len(words) / 2:
                        return False
                else:
                    # Jednoduché slovo - musí být obsaženo
                    if norm_sn not in norm_fn:
                        return False
        # Detekce SxxExx, xXxx, epX, Exx, 1.01 atd.
        s_e_pattern = f"s{season_num:02d}e{episode_num:02d}"
        x_x_pattern = f"{season_num}x{episode_num}"
        ep_pattern = f"ep{episode_num}"
        e_pattern = f"e{episode_num:02d}"
        dot_pattern = f"{season_num}.{episode_num:02d}"
        if any(p in norm_fn for p in [s_e_pattern, x_x_pattern, ep_pattern, e_pattern, dot_pattern]):
            return True
        # Pokud je v názvu pouze číslo epizody a sezóna je 1, povol i "episode X"
        if season_num == 1 and (f"episode {episode_num}" in norm_fn or f"epizoda {episode_num}" in norm_fn):
            return True
        return False

    def filter_streams_by_language(self, streams, prefer_czsk=True, prefer_subs=False):
        """Vrátí pouze streamy s preferovaným jazykem (CZ/SK dabing nebo titulky)"""
        cz_patterns = ['czdab', 'cz dab', 'czdabing', 'cz dabing', 'cz audio', 'cz', 'czech', 'cesky']
        sk_patterns = ['sk', 'slovak', 'slovensky']
        subs_patterns = ['cz titulky', 'czsub', 'cz sub', 's titulkami', 'sub', 'titulky']
        filtered = []
        for s in streams:
            name = s.get('name', '').lower()
            if prefer_czsk and any(p in name for p in cz_patterns + sk_patterns):
                filtered.append(s)
            elif prefer_subs and any(p in name for p in subs_patterns):
                filtered.append(s)
        if filtered:
            return filtered
        return streams  # fallback: vše

    def get_unwatched_episodes(self, series_name):
        """Vrátí seznam nezhlédnutých epizod podle historie"""
        series_data = self.load_series_data(series_name)
        if not series_data:
            return []
        history = self.get_series_history()
        watched = set((h['season'], h['episode']) for h in history if h['series_name'] == series_name)
        unwatched = []
        for season_num, season in series_data['seasons'].items():
            for episode_num, episode_data in season.items():
                if (season_num, episode_num) not in watched:
                    unwatched.append((season_num, episode_num, episode_data))
        return unwatched

    def get_last_watched_episode(self, series_name):
        """Vrátí poslední zhlédnutou epizodu jako (season, episode) nebo (None, None)"""
        try:
            history = self.get_series_history()
            series_episodes = [h for h in history if h['series_name'] == series_name]
            if series_episodes:
                # Seřaď podle času a vrať nejnovější
                latest = max(series_episodes, key=lambda x: x.get('timestamp', 0))
                return (latest.get('season'), latest.get('episode'))
            return (None, None)
        except Exception as e:
            xbmc.log(f'Error getting last watched episode: {str(e)}', level=xbmc.LOGERROR)
            return (None, None)

    def _perform_search(self, search_query, api_function, token, max_retries=2):
        """Perform the actual search using the provided API function with pagination and retry logic"""
        all_results = []
        limit = 75  # Kompromis mezi 50 a 100
        offset = 0
        max_pages = 4  # Zvýšeno ze 3 na 4 stránky = max 300 výsledků
        current_page = 0
        
        while current_page < max_pages:
            retry_count = 0
            while retry_count < max_retries:
                try:
                    response = api_function('search', {
                        'what': search_query, 
                        'category': 'video', 
                        'sort': 'recent',
                        'limit': limit,
                        'offset': offset,
                        'wst': token,
                        'maybe_removed': 'true'
                    })
                    
                    if not response or not response.content:
                        retry_count += 1
                        xbmc.sleep(300)  # Ještě rychlejší - 300ms
                        continue
                        
                    try:
                        xml = ET.fromstring(response.content)
                        
                        status = xml.find('status')
                        if status is None or status.text != 'OK':
                            break
                        
                        results_in_page = 0
                        for file in xml.iter('file'):
                            item = {}
                            for elem in file:
                                item[elem.tag] = elem.text
                            if item:  # Only add if we got valid data
                                all_results.append(item)
                                results_in_page += 1
                        
                        # Pokud je méně výsledků než limit, konec
                        if results_in_page < limit:
                            return all_results
                        
                        break  # Success, exit retry loop
                        
                    except ET.ParseError as e:
                        xbmc.log(f'XML parsing error in search (attempt {retry_count + 1}): {str(e)}', level=xbmc.LOGERROR)
                        if retry_count == max_retries - 1:  # Last attempt
                            return all_results
                        retry_count += 1
                        xbmc.sleep(300)
                        
                except Exception as e:
                    xbmc.log(f'Error in search (attempt {retry_count + 1}): {str(e)}', level=xbmc.LOGERROR)
                    if retry_count == max_retries - 1:  # Last attempt
                        return all_results
                    retry_count += 1
                    xbmc.sleep(300)
            
            offset += limit
            current_page += 1
            
        return all_results

    def _perform_multi_search(self, series_name, api_function, token):
        """Perform search with multiple queries to increase chances of finding correct results."""
        search_queries = []
        
        # Cleaned name without special characters and diacritics
        normalized_name = unidecode.unidecode(series_name).lower()
        normalized_name = re.sub(r'[^a-z0-9& ]', '', normalized_name).strip()
        
        # BALANCOVANÉ: Základní dotazy + rozšířené epizody
        # Prioritized "cz" queries
        search_queries.append(f'{normalized_name} cz')
        search_queries.append(f'{normalized_name.replace(" ", ".")} cz')
        search_queries.append(f'{normalized_name} czech')
        search_queries.append(f'{normalized_name} cesky')
        
        # General queries for fallback
        search_queries.append(normalized_name)
        search_queries.append(normalized_name.replace(' ', '.'))
        search_queries.append(normalized_name.replace(' ', '-'))
        search_queries.append(normalized_name.replace(' ', '_'))

        # ROZŠÍŘENÉ: První 2 sezóny a více epizod
        clean_name_for_episodes = unidecode.unidecode(series_name).lower()
        clean_name_for_episodes = re.sub(r'[^a-z0-9& ]', '', clean_name_for_episodes).strip()
        
        # Zkus první 2 sezóny a prvních 15 epizod
        for season in range(1, 3):  # Sezóny 1-2
            for episode in range(1, 16):  # Epizody 1-15
                # Pouze nejefektivnější formáty
                search_queries.append(f'{clean_name_for_episodes} s{season:02d}e{episode:02d}')
                search_queries.append(f'{clean_name_for_episodes} {season}x{episode:02d}')
                # CZ varianty pro první sezónu
                if season == 1:
                    search_queries.append(f'{clean_name_for_episodes} cz s{season:02d}e{episode:02d}')

        # České formáty - rozšířeno na 15 dílů
        for part in range(1, 16):
            search_queries.append(f'{clean_name_for_episodes} {part:02d}.dil')
            search_queries.append(f'{clean_name_for_episodes} {part}.dil')
            search_queries.append(f'{clean_name_for_episodes} {part:02d}.cast')

        all_results = []
        seen_idents = set()

        # KOMPROMIS: Limit počtu dotazů na 60 (více než 25, méně než 250)
        search_queries = search_queries[:60]

        for query in search_queries:
            if not query.strip():
                continue
            
            results = self._perform_search(query, api_function, token)
            for item in results:
                if item['ident'] not in seen_idents:
                    all_results.append(item)
                    seen_idents.add(item['ident'])
        
        return all_results
    
    def _detect_episode_info(self, filename):
        """Try to detect season and episode numbers from filename using only patterns"""
        cleaned = unidecode.unidecode(filename).lower()
        
        for pattern in EPISODE_PATTERNS:
            match = re.search(pattern, cleaned)
            if match:
                groups = match.groups()
                if len(groups) == 2:
                    return int(groups[0]), int(groups[1])
                elif len(groups) == 1:
                    return 1, int(groups[0])
        
        return None, None
    
    def _save_series_data(self, series_name, series_data):
        """Save series data to the database"""
        self.ensure_db_exists()  # zajistí existenci adresáře před zápisem
        safe_name = self._safe_filename(series_name)
        file_path = os.path.join(self.series_db_path, f"{safe_name}.json")
        try:
            with io.open(file_path, 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(series_data, indent=2).decode('utf8')
                except AttributeError:
                    data = json.dumps(series_data, indent=2)
                file.write(data)
                file.close()
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error saving series data: {str(e)}', level=xbmc.LOGERROR)
    
    def load_series_data(self, series_name):
        """Load series data from the database"""
        safe_name = self._safe_filename(series_name)
        file_path = os.path.join(self.series_db_path, f"{safe_name}.json")
        
        if not os.path.exists(file_path):
            return None
        
        try:
            with io.open(file_path, 'r', encoding='utf8') as file:
                data = file.read()
                file.close()
                try:
                    series_data = json.loads(data, "utf-8")
                except TypeError:
                    series_data = json.loads(data)
                return series_data
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error loading series data: {str(e)}', level=xbmc.LOGERROR)
            return None
    
    def get_all_series(self):
        """Get a list of all saved series"""
        series_list = []
        
        try:
            for filename in os.listdir(self.series_db_path):
                if filename.endswith('.json'):
                    series_name = os.path.splitext(filename)[0]
                    proper_name = series_name.replace('_', ' ')
                    series_list.append({
                        'name': proper_name,
                        'filename': filename,
                        'safe_name': series_name
                    })
        except Exception as e:
            xbmc.log(f'Tshare Series Manager: Error listing series: {str(e)}', level=xbmc.LOGERROR)
        
        return series_list
    
    def _safe_filename(self, name):
        """Convert a series name to a safe filename"""
        safe = re.sub(r'[^\w\-_.\s]', '', name)
        return safe.strip().lower().replace(' ', '_')

    def get_streams_for_episode(self, series_name, season, episode):
        """Získá všechny streamy pro danou epizodu"""
        series_data = self.load_series_data(series_name)
        if not series_data:
            return []
            
        season = str(season)
        episode = str(episode)
        
        if season not in series_data['seasons']:
            return []
            
        if episode not in series_data['seasons'][season]:
            return []
            
        episode_data = series_data['seasons'][season][episode]
        # Vrať kopii seznamu streamů, aby se nemodifikoval originál
        return list(self._sort_streams(episode_data['episodes'], series_name))

    def disable_force_pattern(self, series_name):
        """Vypne vynucení vzoru a obnoví chytré řazení"""
        if series_name in self.preferences:
            self.preferences[series_name]['force_pattern'] = False
            self.save_preferences()
            # Přeřaď streamy podle chytrého řazení
            series_data = self.load_series_data(series_name)
            if series_data and 'seasons' in series_data:
                for season in series_data['seasons'].values():
                    for episode_data in season.values():
                        episode_data['episodes'] = sorted(episode_data['episodes'], 
                            key=lambda e: (-int(e.get('size', '0'))))
                self._save_series_data(series_name, series_data)

    def get_history_path(self):
        return os.path.join(self.profile, 'series_history.json')

    def load_history(self):
        path = self.get_history_path()
        if os.path.exists(path):
            try:
                with io.open(path, 'r', encoding='utf8') as file:
                    return json.load(file)
            except Exception:
                return []
        return []

    def save_history(self, history):
        path = self.get_history_path()
        try:
            with io.open(path, 'w', encoding='utf8') as file:
                json.dump(history, file, indent=2)
        except Exception:
            pass

    def add_to_history(self, series_name, season, episode, episode_title, year=None, plot=None, poster=None, tmdb_id=None, stream_url=None):
        import time
        history = self.load_history()
        entry = {
            'series_name': series_name,
            'season': str(season),
            'episode': str(episode),
            'episode_title': episode_title,
            'year': year,
            'plot': plot,
            'poster': poster,
            'tmdb_id': tmdb_id,
            'timestamp': int(time.time()),
            'stream_url': stream_url
        }
        # Remove duplicates (same series, season, episode)
        history = [h for h in history if not (h['series_name'] == series_name and h['season'] == str(season) and h['episode'] == str(episode))]
        history.insert(0, entry)
        # Limit history size
        history = history[:100]
        self.save_history(history)

    def get_series_history(self):
        """Načte kompletní historii seriálů"""
        try:
            history_file = os.path.join(self.profile, 'series_history.json')
            if os.path.exists(history_file):
                with io.open(history_file, 'r', encoding='utf8') as f:
                    return json.load(f)
            return []
        except Exception as e:
            xbmc.log(f'Error loading series history: {str(e)}', level=xbmc.LOGERROR)
            return []
    
    def find_missing_episodes(self, series_name):
        """Najde chybějící díly v seriálu a vrátí seznam (season, episode) tupletů"""
        series_data = self.load_series_data(series_name)
        if not series_data or 'seasons' not in series_data:
            return []
        
        missing_episodes = []
        
        for season_num, season_data in series_data['seasons'].items():
            season_num = int(season_num)
            available_episodes = set(int(ep) for ep in season_data.keys())
            
            if available_episodes:
                min_ep = min(available_episodes)
                max_ep = max(available_episodes)
                
                # DEBUG: Loguj informace o sezóně
                import xbmc
                xbmc.log(f'DEBUG Season {season_num}: episodes {min_ep}-{max_ep}, available: {sorted(available_episodes)}', level=xbmc.LOGINFO)
                
                # OPRAVENO: Hledej chybějící díly od 1 do max_ep (ne jen díry v sekvenci)
                for ep_num in range(1, max_ep + 1):
                    if ep_num not in available_episodes:
                        missing_episodes.append((season_num, ep_num))
                        xbmc.log(f'DEBUG Missing episode found: S{season_num}E{ep_num}', level=xbmc.LOGINFO)
        
        xbmc.log(f'DEBUG Total missing episodes for {series_name}: {missing_episodes}', level=xbmc.LOGINFO)
        return missing_episodes

    def search_missing_episodes(self, series_name, api_function, token, missing_episodes=None):
        """Cílené vyhledávání konkrétních chybějících dílů"""
        if missing_episodes is None:
            missing_episodes = self.find_missing_episodes(series_name)
        
        if not missing_episodes:
            return None
        
        search_queries = []
        clean_name = unidecode.unidecode(series_name).lower()
        clean_name = re.sub(r'[^a-z0-9& ]', '', clean_name).strip()
        
        # Generuj specifické dotazy pro chybějící díly
        for season, episode in missing_episodes:
            # Různé formáty pro každý chybějící díl
            search_queries.extend([
                f'{clean_name} s{season:02d}e{episode:02d}',
                f'{clean_name}.s{season:02d}e{episode:02d}',
                f'{clean_name} {season}x{episode:02d}',
                f'{clean_name}.{season}x{episode:02d}',
                f'{clean_name} cz s{season:02d}e{episode:02d}',
                f'{clean_name} season {season} episode {episode}',
                f'{clean_name} rada {season} dil {episode}',
                f'{clean_name} {episode:02d}.dil',
                f'{clean_name} {episode}.dil',
                f'{clean_name} {episode:02d}.cast',
                f'{clean_name} episode {episode}',
                f'{clean_name} ep {episode}',
                f'{clean_name} e{episode:02d}',
            ])
        
        # Proveď vyhledávání
        all_results = []
        seen_idents = set()
        
        for query in search_queries:
            if not query.strip():
                continue
            
            results = self._perform_search(query, api_function, token)
            for item in results:
                if item['ident'] not in seen_idents:
                    season_num, episode_num = self._detect_episode_info(item['name'])
                    if season_num is not None and episode_num is not None:
                        if (season_num, episode_num) in missing_episodes:
                            if self._is_likely_episode(item['name'], series_name, season_num, episode_num):
                                all_results.append(item)
                                seen_idents.add(item['ident'])
        
        # Přidej nalezené díly do série
        if all_results:
            series_data = self.load_series_data(series_name)
            if series_data:
                added_count = 0
                for item in all_results:
                    season_num, episode_num = self._detect_episode_info(item['name'])
                    if season_num is not None and episode_num is not None:
                        season_str = str(season_num)
                        episode_str = str(episode_num)
                        
                        if season_str not in series_data['seasons']:
                            series_data['seasons'][season_str] = {}
                        
                        if episode_str not in series_data['seasons'][season_str]:
                            series_data['seasons'][season_str][episode_str] = {'episodes': []}
                            added_count += 1
                        
                        # Přidej stream pouze pokud už není
                        existing_idents = {ep['ident'] for ep in series_data['seasons'][season_str][episode_str]['episodes']}
                        if item['ident'] not in existing_idents:
                            series_data['seasons'][season_str][episode_str]['episodes'].append({
                                'name': item['name'],
                                'ident': item['ident'],
                                'size': item.get('size', '0')
                            })
                
                # Seřaď epizody
                for season in series_data['seasons'].values():
                    for episode_data in season.values():
                        episode_data['episodes'] = self._sort_streams(episode_data['episodes'], series_name)
                
                self._save_series_data(series_name, series_data)
                self.save_series_cache(series_name, series_data)
                
                return added_count
        
    def delete_series(self, series_name):
        """Smaže celý seriál z databáze"""
        try:
            safe_name = self._safe_filename(series_name)
            file_path = os.path.join(self.series_db_path, f"{safe_name}.json")
            
            if os.path.exists(file_path):
                os.remove(file_path)
                
            # Smaž i cache
            cache_path = self.get_series_cache_path(series_name)
            if os.path.exists(cache_path):
                os.remove(cache_path)
                
            # Smaž preference
            if series_name in self.preferences:
                del self.preferences[series_name]
                self.save_preferences()
                
            return True
        except Exception as e:
            xbmc.log(f'Error deleting series {series_name}: {str(e)}', level=xbmc.LOGERROR)
            return False

    def delete_season(self, series_name, season_num):
        """Smaže celou sezónu ze seriálu"""
        try:
            series_data = self.load_series_data(series_name)
            if not series_data or 'seasons' not in series_data:
                return False
                
            season_str = str(season_num)
            if season_str in series_data['seasons']:
                del series_data['seasons'][season_str]
                
                # Pokud nezbyla žádná sezóna, smaž celý seriál
                if not series_data['seasons']:
                    return self.delete_series(series_name)
                else:
                    self._save_series_data(series_name, series_data)
                    return True
            return False
        except Exception as e:
            xbmc.log(f'Error deleting season {season_num} from {series_name}: {str(e)}', level=xbmc.LOGERROR)
            return False

    def delete_episode(self, series_name, season_num, episode_num):
        """Smaže konkrétní epizodu"""
        try:
            series_data = self.load_series_data(series_name)
            if not series_data or 'seasons' not in series_data:
                return False
                
            season_str = str(season_num)
            episode_str = str(episode_num)
            
            if season_str in series_data['seasons'] and episode_str in series_data['seasons'][season_str]:
                del series_data['seasons'][season_str][episode_str]
                
                # Pokud nezbyla žádná epizoda v sezóně, smaž sezónu
                if not series_data['seasons'][season_str]:
                    del series_data['seasons'][season_str]
                    
                    # Pokud nezbyla žádná sezóna, smaž celý seriál
                    if not series_data['seasons']:
                        return self.delete_series(series_name)
                
                self._save_series_data(series_name, series_data)
                return True
            return False
        except Exception as e:
            xbmc.log(f'Error deleting episode S{season_num}E{episode_num} from {series_name}: {str(e)}', level=xbmc.LOGERROR)
            return False
def get_url(**kwargs):
    """Create a URL for calling the plugin recursively"""
    from Tshare import _url
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def create_series_menu(series_manager, handle):
    """Create the series selection menu"""
    import xbmcplugin
    
    listitem = xbmcgui.ListItem(label="Hledat novy serial")
    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})  # Sjednoceno s hlavním menu
    xbmcplugin.addDirectoryItem(handle, get_url(action='series_search'), listitem, True)
    
    series_list = series_manager.get_all_series()
    
    for series in series_list:
        listitem = xbmcgui.ListItem(label=series['name'])
        listitem.setArt({'icon': 'DefaultAlbumCover.png'})  # 4. ikona - Album obal pro seriály
        
        # Context menu pouze pro odstranění seriálu
        context_menu = [
            ('Odstranit seriál', f'RunPlugin({get_url(action="delete_series", series_name=series["name"])})')
        ]
        listitem.addContextMenuItems(context_menu)
        
        xbmcplugin.addDirectoryItem(handle, get_url(action='series_detail', series_name=series['name']), listitem, True)
    
    xbmcplugin.endOfDirectory(handle)

def create_seasons_menu(series_manager, handle, series_name):
    import xbmcplugin
    from Tshare import get_url
    
    series_data = series_manager.load_series_data(series_name)
    if not series_data:
        xbmcgui.Dialog().notification('Tshare', 'Data serialu nenalezena', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    
    # Pokračovat tam, kde jsem skončil
    last_watched = series_manager.get_last_watched_episode(series_name)
    if last_watched != (None, None):
        season, episode = last_watched
        # Najdi další epizodu (nebo tu poslední, pokud další není)
        next_season = str(season)
        next_episode = str(int(episode) + 1)
        if next_season in series_data['seasons'] and next_episode in series_data['seasons'][next_season]:
            play_season, play_episode = next_season, next_episode
        else:
            play_season, play_episode = str(season), str(episode)
        
        # Získej ident první epizody z dostupných streamů
        if play_season in series_data['seasons'] and play_episode in series_data['seasons'][play_season]:
            episode_data = series_data['seasons'][play_season][play_episode]
            if episode_data['episodes']:
                first_stream = episode_data['episodes'][0]
                label = f">> Pokracovat: S{play_season}E{play_episode}"  # Změněno na ASCII
                listitem = xbmcgui.ListItem(label=label)
                listitem.setArt({'icon': 'DefaultMovies.png'})
                listitem.setProperty('IsPlayable', 'true')
                url = get_url(action='play', ident=first_stream['ident'], name=first_stream['name'],
                             series_name=series_name, season=play_season, episode=play_episode,
                             episode_title=first_stream['name'])
                xbmcplugin.addDirectoryItem(handle, url, listitem, False)
    
    listitem = xbmcgui.ListItem(label="Aktualizovat serial")
    listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})  # Změněno na Updates
    xbmcplugin.addDirectoryItem(handle, get_url(action='series_refresh', series_name=series_name), listitem, True)
    
    for season_num in sorted(series_data['seasons'].keys(), key=int):
        season_name = f"Rada {season_num}"
        listitem = xbmcgui.ListItem(label=season_name)
        listitem.setArt({'icon': 'DefaultFolder.png'})  # Zůstává Folder pro sezóny
        xbmcplugin.addDirectoryItem(handle, get_url(action='series_season', series_name=series_name, season=season_num), listitem, True)
    
    xbmcplugin.endOfDirectory(handle)

def create_seasons_menu_from_data(series_manager, handle, series_name, series_data):
    """Vytvoří menu sezón pro seriál z předaných dat (např. z cache)."""
    import xbmcplugin
    import xbmcgui
    from Tshare import get_url
    if not series_data:
        xbmcgui.Dialog().notification('Tshare', 'Data serialu nenalezena', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    
    # Pokračovat tam, kde jsem skončil
    last_watched = series_manager.get_last_watched_episode(series_name)
    if last_watched != (None, None):
        season, episode = last_watched
        # Najdi další epizodu (nebo tu poslední, pokud další není)
        next_season = str(season)
        next_episode = str(int(episode) + 1)
        if next_season in series_data['seasons'] and next_episode in series_data['seasons'][next_season]:
            play_season, play_episode = next_season, next_episode
        else:
            play_season, play_episode = str(season), str(episode)
        
        # Získej ident první epizody z dostupných streamů
        if play_season in series_data['seasons'] and play_episode in series_data['seasons'][play_season]:
            episode_data = series_data['seasons'][play_season][play_episode]
            if episode_data['episodes']:
                first_stream = episode_data['episodes'][0]
                label = f">> Pokracovat: S{play_season}E{play_episode}"  # Změněno na ASCII
                listitem = xbmcgui.ListItem(label=label)
                listitem.setArt({'icon': 'DefaultMovies.png'})
                listitem.setProperty('IsPlayable', 'true')
                url = get_url(action='play', ident=first_stream['ident'], name=first_stream['name'],
                             series_name=series_name, season=play_season, episode=play_episode,
                             episode_title=first_stream['name'])
                xbmcplugin.addDirectoryItem(handle, url, listitem, False)
    
    listitem = xbmcgui.ListItem(label="Aktualizovat serial")
    listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})  # Změněno na Updates pro konzistenci
    xbmcplugin.addDirectoryItem(handle, get_url(action='series_refresh', series_name=series_name), listitem, True)
    
    for season_num in sorted(series_data['seasons'].keys(), key=int):
        season_name = f"Rada {season_num}"
        listitem = xbmcgui.ListItem(label=season_name)
        listitem.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle, get_url(action='series_season', series_name=series_name, season=season_num), listitem, True)
    xbmcplugin.endOfDirectory(handle)

def create_episodes_menu(series_manager, handle, series_name, season_num):
    """Vytvoří menu epizod s označením zhlédnutých epizod"""
    import xbmcplugin
    from Tshare import sizelize, get_url
    
    series_data = series_manager.load_series_data(series_name)
    if not series_data or str(season_num) not in series_data['seasons']:
        xbmcgui.Dialog().notification('Tshare', 'Data sezony nenalezena', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    
    listitem = xbmcgui.ListItem(label="Aktualizovat tuto řadu")
    listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})  # Změněno na Updates pro konzistenci
    xbmcplugin.addDirectoryItem(handle, get_url(action='series_refresh_season', series_name=series_name, season=season_num), listitem, True)
    
    # Zkontroluj chybějící díly v této sezóně
    missing_episodes = series_manager.find_missing_episodes(series_name)
    season_missing = [ep for ep in missing_episodes if ep[0] == int(season_num)]
    
    # DEBUG: Loguj informace o chybějících dílech
    import xbmc
    xbmc.log(f'DEBUG missing_episodes total: {len(missing_episodes)}', level=xbmc.LOGINFO)
    xbmc.log(f'DEBUG season_missing for season {season_num}: {len(season_missing)}', level=xbmc.LOGINFO)
    xbmc.log(f'DEBUG season_missing list: {season_missing}', level=xbmc.LOGINFO)
    
    # OPRAVENO: Zobrazuj tlačítko i když jsou chybějící díly v jiných sezónách
    if missing_episodes:  # Jakékoliv chybějící díly v seriálu
        if season_missing:
            missing_count = len(season_missing)
            missing_label = f"Hledat chybejici dily rady {season_num} ({missing_count} chybi)"
        else:
            # V této sezóně nechybí, ale jinde ano
            total_missing = len(missing_episodes)
            missing_label = f"Hledat chybejici dily serialu ({total_missing} celkem chybi)"
        
        listitem = xbmcgui.ListItem(label=missing_label)
        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
        
        # Pokud chybí v této sezóně, hledej jen zde, jinak hledej celý seriál
        if season_missing:
            xbmcplugin.addDirectoryItem(handle, get_url(action='search_missing_episodes', series_name=series_name, season=season_num), listitem, True)
        else:
            xbmcplugin.addDirectoryItem(handle, get_url(action='search_missing_episodes', series_name=series_name), listitem, True)
    
    season_num = str(season_num)
    season = series_data['seasons'][season_num]

    # Získej historii pro označení
    last_watched = series_manager.get_last_watched_episode(series_name)
    watched_set = set((str(h['season']), str(h['episode'])) for h in series_manager.get_series_history() if h['series_name'] == series_name)

    for episode_num in sorted(season.keys(), key=int):
        episode_data = season[episode_num]
        streams = episode_data['episodes']
        if not streams:
            continue
        episode = streams[0]
        size_label = sizelize(episode.get('size')) if episode.get('size') else '?'
        
        # Označení zhlédnutých epizod
        watched = (season_num, str(episode_num)) in watched_set
        label_prefix = '[V] ' if watched else ''
        if last_watched == (season_num, str(episode_num)):
            label_prefix = '★ ' + label_prefix

        # Jednoduchý název: pouze seriál S01E01 (velikost)
        series_name_clean = series_name.replace('_', ' ').strip()
        season_num_int = int(season_num)
        episode_num_int = int(episode_num)
        episode_label = f"{label_prefix}{series_name_clean} S{season_num_int:02d}E{episode_num_int:02d}"
        
        # Zkrácený název epizody - pouze číslo a název bez názvu seriálu
        episode_name = episode['name']
        # Pokus se odstranit název seriálu z názvu epizody
        series_name_lower = series_name.lower()
        episode_name_lower = episode_name.lower()
        
        # Odstraň název seriálu z názvu epizody, pokud tam je
        if series_name_lower in episode_name_lower:
            episode_name = episode_name.replace(series_name, '').strip()
            episode_name = episode_name.replace(series_name.lower(), '').strip()
            episode_name = episode_name.replace(series_name.upper(), '').strip()
        
        # Odstraň různé oddělovače na začátku
        episode_name = re.sub(r'^[\s\-_.:]+', '', episode_name)
        
        # Pokud je název příliš dlouhý, zkrať ho
        if len(episode_name) > 40:
            episode_name = episode_name[:37] + '...'
        
        # Pokud po zkrácení zůstal prázdný název, použij původní
        if not episode_name.strip():
            episode_name = episode['name']
            if len(episode_name) > 50:
                episode_name = episode_name[:47] + '...'
        
        episode_label = f"{label_prefix}E{episode_num} - {episode_name} ({size_label})"
        # Vytvoř listitem s jednoduchým názvem: Seriál S01E01 (velikost)
        series_name_clean = series_name.replace('_', ' ').strip()
        # Použij první stream pro velikost
        first_stream = streams[0] if streams else {}
        size_info = f" ({sizelize(first_stream.get('size'))})" if first_stream.get('size') else ""
        season_num_int = int(season_num)
        episode_num_int = int(episode_num)
        final_label = f"{label_prefix}{series_name_clean} S{season_num_int:02d}E{episode_num_int:02d}{size_info}"
        
        listitem = xbmcgui.ListItem(label=final_label)
        listitem.setArt({'icon': 'DefaultMovies.png'})  
        listitem.setProperty('IsPlayable', 'true')
        
        # Context menu pro více streamů
        context_menu = []
        if len(streams) > 1:
            context_menu.append(
                ('Změnit stream',
                 f'RunPlugin({get_url(action="select_stream", series_name=series_name, season=season_num, episode=episode_num)})')
            )
        
        # Přidej možnost obnovit chytré řazení, pokud je nastavený force pattern
        if series_name in series_manager.preferences and series_manager.preferences[series_name].get('force_pattern', False):
            context_menu.append(
                ('Obnovit chytré řazení',
                 f'RunPlugin({get_url(action="restore_smart_ordering", series_name=series_name)})')
            )
        
        # Vždy přidej debug info o dostupných streamech
        if len(streams) > 0:
            context_menu.append(
                (f'Dostupné streamy: {len(streams)}',
                 f'RunPlugin({get_url(action="select_stream", series_name=series_name, season=season_num, episode=episode_num)})')
            )
        
        listitem.addContextMenuItems(context_menu)
        
        url = get_url(action='play', ident=episode['ident'], name=episode['name'], 
                     series_name=series_name, season=season_num, episode=episode_num, 
                     episode_title=episode['name'])
        xbmcplugin.addDirectoryItem(handle, url, listitem, False)
    
    xbmcplugin.endOfDirectory(handle)

def create_series_history_menu(series_manager, handle):
    import xbmcplugin
    history = series_manager.get_series_history()
    if not history:
        xbmcgui.Dialog().notification('Tshare', 'Historie seriálů je prázdná', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    for i, entry in enumerate(history):
        label = f"{entry['series_name']} S{entry['season']}E{entry['episode']} - {entry['episode_title']}"
        year = entry.get('year')
        plot = entry.get('plot')
        poster = entry.get('poster')
        listitem = xbmcgui.ListItem(label=label)
        info = {'title': label}
        if year:
            info['year'] = year
        if plot:
            info['plot'] = plot
        listitem.setInfo('video', info)
        if poster:
            if poster.startswith('/'):
                poster_url = f'https://image.tmdb.org/t/p/w500{poster}'
            else:
                poster_url = poster
            listitem.setArt({'icon': poster_url, 'poster': poster_url})
        else:
            listitem.setArt({'icon': 'DefaultMovies.png'})  # Změněno na Movies.png pro historii bez posteru
        listitem.setProperty('IsPlayable', 'true')
        
        # Context menu pro odstranění z historie - OPRAVENO: použij index
        context_menu = [
            ('Odstranit z historie', f'RunPlugin({get_url(action="delete_series_history", history_index=i, series_label=label)})')
        ]
        listitem.addContextMenuItems(context_menu)
        
        url_params = {
            'action': 'play_series_history',
            'series_name': entry['series_name'],
            'season': entry['season'],
            'episode': entry['episode']
        }
        if entry.get('stream_url'):
            url_params['stream_url'] = entry.get('stream_url')
        url = get_url(**url_params)
        xbmcplugin.addDirectoryItem(handle, url, listitem, False)
    xbmcplugin.endOfDirectory(handle)