# -*- coding: utf-8 -*-
"""
Inteligentní učící se systém pro detekci epizod
Automaticky se učí vzory na základě úspěšných rozpoznání
"""

import json
import re
import os
import xbmc  # type: ignore
import unidecode  # type: ignore

class PatternLearner:
    def __init__(self, profile_path):
        self.profile_path = profile_path
        self.patterns_file = os.path.join(profile_path, 'learned_patterns.json')
        self.learned_patterns = self._load_patterns()
        
    def _load_patterns(self):
        """Načte naučené vzory ze souboru"""
        try:
            if os.path.exists(self.patterns_file):
                with open(self.patterns_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při načítání vzorů: {e}", xbmc.LOGWARNING)
        
        return {
            'series_patterns': {},      # Vzory pro konkrétní seriály
            'general_patterns': [],     # Obecné vzory
            'success_count': {},        # Počet úspěšných použití
            'last_updated': None
        }
    
    def _save_patterns(self):
        """Uloží naučené vzory do souboru"""
        try:
            import time
            self.learned_patterns['last_updated'] = int(time.time())
            
            with open(self.patterns_file, 'w', encoding='utf-8') as f:
                json.dump(self.learned_patterns, f, indent=2, ensure_ascii=False)
                
            xbmc.log(f"PatternLearner: Vzory uloženy ({len(self.learned_patterns.get('general_patterns', []))} obecných)", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při ukládání vzorů: {e}", xbmc.LOGWARNING)
    
    def learn_pattern(self, filename, season, episode, series_name=None):
        """
        Naučí se vzor z úspěšně rozpoznanego souboru
        
        Args:
            filename: Název souboru
            season: Rozpoznaná sezóna
            episode: Rozpoznaná epizoda  
            series_name: Název seriálu (volitelné)
        """
        try:
            cleaned = unidecode.unidecode(filename).lower()
            
            # Vytvoř vzor z názvu souboru
            pattern_candidates = self._extract_patterns(cleaned, season, episode)
            
            for pattern_info in pattern_candidates:
                pattern = pattern_info['pattern']
                confidence = pattern_info['confidence']
                
                # Přidej do obecných vzorů
                if pattern not in [p['pattern'] for p in self.learned_patterns['general_patterns']]:
                    self.learned_patterns['general_patterns'].append({
                        'pattern': pattern,
                        'confidence': confidence,
                        'learned_from': filename,
                        'season': season,
                        'episode': episode,
                        'series': series_name
                    })
                    
                    xbmc.log(f"PatternLearner: Naučen nový vzor '{pattern}' z '{filename}' → S{season:02d}E{episode:02d}", xbmc.LOGINFO)
                
                # Zvyš počítadlo úspěšnosti
                self.learned_patterns['success_count'][pattern] = self.learned_patterns['success_count'].get(pattern, 0) + 1
            
            # Přidej specifický vzor pro seriál
            if series_name:
                if series_name not in self.learned_patterns['series_patterns']:
                    self.learned_patterns['series_patterns'][series_name] = []
                
                series_pattern = self._create_series_pattern(filename, series_name, season, episode)
                if series_pattern:
                    self.learned_patterns['series_patterns'][series_name].append(series_pattern)
            
            self._save_patterns()
            
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při učení vzoru: {e}", xbmc.LOGERROR)
    
    def _extract_patterns(self, cleaned_filename, season, episode):
        """Extrahuje možné vzory z názvu souboru"""
        patterns = []
        
        # Hledej různé způsoby, jak se season/episode objevují v názvu
        
        # 1. Římské číslice + závorky: velkolepe-stoleti-iii-(43)
        roman_match = re.search(rf'-([ivxlc]+)\(({episode})\)', cleaned_filename)
        if roman_match:
            patterns.append({
                'pattern': r'-([ivxlc]+)\((\d+)\)',
                'confidence': 95
            })
        
        # 2. Římské číslice + pomlčka + závorky: -iii-(43) 
        roman_dash_match = re.search(rf'-([ivxlc]+)-\(({episode})\)', cleaned_filename)
        if roman_dash_match:
            patterns.append({
                'pattern': r'-([ivxlc]+)-\((\d+)\)',
                'confidence': 90
            })
        
        # 3. Podtržítka: _iii_(43) nebo _iii_43
        underscore_match = re.search(rf'_([ivxlc]+)_\(?({episode})\)?', cleaned_filename)
        if underscore_match:
            patterns.append({
                'pattern': r'_([ivxlc]+)_\(?(\d+)\)?',
                'confidence': 85
            })
        
        # 4. Římské číslice + pomlčka + číslo (bez závorek): velkolepe-stoleti-iii-43
        roman_direct_match = re.search(rf'-([ivxlc]+)-({episode})(?:-|$)', cleaned_filename)
        if roman_direct_match:
            patterns.append({
                'pattern': r'-([ivxlc]+)-(\d+)(?:-|$)',
                'confidence': 80
            })
        
        # 5. Klasické formáty
        if re.search(rf's0?{season}e0?{episode}', cleaned_filename):
            patterns.append({
                'pattern': r's(\d+)e(\d+)',
                'confidence': 100
            })
        
        if re.search(rf'{season}x0?{episode}', cleaned_filename):
            patterns.append({
                'pattern': r'(\d+)x(\d+)',
                'confidence': 95
            })
        
        return patterns
    
    def _create_series_pattern(self, filename, series_name, season, episode):
        """Vytvoří specifický vzor pro seriál"""
        try:
            # Normalizuj název seriálu a souboru
            clean_series = unidecode.unidecode(series_name).lower()
            clean_filename = unidecode.unidecode(filename).lower()
            
            # Najdi společné části
            series_words = re.findall(r'\w+', clean_series)
            
            # Vytvoř vzor specifický pro tento seriál
            if len(series_words) >= 2:
                base_pattern = '.*'.join(series_words[:2])  # První dvě slova
                
                return {
                    'base_pattern': base_pattern,
                    'season': season,
                    'episode': episode,
                    'full_filename': filename,
                    'confidence': 80
                }
        except Exception:
            pass
        
        return None
    
    def detect_episode(self, filename):
        """
        Pokusí se rozpoznat epizodu pomocí naučených vzorů
        
        Returns:
            (season, episode) nebo (None, None)
        """
        try:
            cleaned = unidecode.unidecode(filename).lower()
            
            # Zkus naučené vzory (seřazené podle úspěšnosti)
            general_patterns = sorted(
                self.learned_patterns.get('general_patterns', []),
                key=lambda p: self.learned_patterns['success_count'].get(p['pattern'], 0),
                reverse=True
            )
            
            for pattern_info in general_patterns:
                pattern = pattern_info['pattern']
                match = re.search(pattern, cleaned)
                
                if match and len(match.groups()) == 2:
                    try:
                        season_str = match.group(1).lower()
                        episode_str = match.group(2)
                        
                        # Převeď římské číslice
                        if season_str in ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x']:
                            roman_to_arabic = {
                                'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5,
                                'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10
                            }
                            season = roman_to_arabic[season_str]
                        else:
                            season = int(season_str)
                        
                        episode = int(episode_str)
                        
                        if 1 <= season <= 20 and 1 <= episode <= 60:
                            # Zvyš počítadlo úspěšnosti
                            self.learned_patterns['success_count'][pattern] = self.learned_patterns['success_count'].get(pattern, 0) + 1
                            self._save_patterns()
                            
                            xbmc.log(f"PatternLearner: Použit naučený vzor '{pattern}' → S{season:02d}E{episode:02d} pro '{filename}'", xbmc.LOGINFO)
                            return season, episode
                            
                    except (ValueError, KeyError):
                        continue
            
        except Exception as e:
            xbmc.log(f"PatternLearner: Chyba při detekci: {e}", xbmc.LOGWARNING)
        
        return None, None
    
    def get_statistics(self):
        """Vrátí statistiky naučených vzorů"""
        general_count = len(self.learned_patterns.get('general_patterns', []))
        series_count = len(self.learned_patterns.get('series_patterns', {}))
        success_total = sum(self.learned_patterns.get('success_count', {}).values())
        
        return {
            'general_patterns': general_count,
            'series_patterns': series_count,  
            'total_successes': success_total,
            'last_updated': self.learned_patterns.get('last_updated')
        }