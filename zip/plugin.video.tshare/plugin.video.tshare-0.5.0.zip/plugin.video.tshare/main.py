# -*- coding: utf-8 -*-
# Tshare Main Entry Point
# Author: Tomas for friends

import sys
import os
import io
import json
import xbmc
import xbmcvfs
import xbmcgui
import Tshare

def install_tmdb_player_config():
    """Nainstaluje TMDB Helper player konfiguraci"""
    try:
        # JSON konfigurace pro TMDB Helper
        tshare_player_config = {
            "name": "Tshare Player",
            "plugin": "plugin.video.tshare",
            "priority": 100,
            "search_movie": "plugin://plugin.video.tshare/?action=direct_search&what={showname} {year}&tmdb_id={id}&tmdb_type=movie",
            "search_episode": "plugin://plugin.video.tshare/?action=direct_search&what={showname} S{season}E{episode}&tmdb_id={id}&tmdb_type=tv",
            "assert": {
                "search_movie": ["showname", "year", "id"],
                "search_episode": ["showname", "season", "episode", "id"]
            }
        }
        
        # Cesta k TMDB Helper players složce
        tmdb_profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper')
        tmdb_players_path = os.path.join(tmdb_profile, 'players')
        
        # Kontrola, jestli TMDB Helper existuje
        if not xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
            xbmc.log('[Tshare]: TMDB Helper not installed', xbmc.LOGWARNING)
            return False
        
        # Vytvoř složky pokud neexistují
        if not os.path.exists(tmdb_profile):
            os.makedirs(tmdb_profile)
        if not os.path.exists(tmdb_players_path):
            os.makedirs(tmdb_players_path)
        
        # Cesta k Tshare player konfiguraci
        player_config_file = os.path.join(tmdb_players_path, 'tshare_player.json')
        
        # Zapis konfiguraci (vždy přepíše pro aktualizaci)
        with io.open(player_config_file, 'w', encoding='utf-8') as f:
            json.dump(tshare_player_config, f, indent=2, ensure_ascii=False)
        
        xbmc.log('[Tshare]: TMDB Helper player configuration installed successfully', xbmc.LOGINFO)
        return True
        
    except Exception as e:
        xbmc.log(f'[Tshare]: Error installing TMDB player config: {str(e)}', xbmc.LOGERROR)
        return False

def auto_install_tmdb_config():
    """Automaticky nainstaluje TMDB konfiguraci při prvním spuštění"""
    try:
        # Zkontroluj, jestli už byla automatická instalace provedena
        profile_path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.tshare')
        flag_file = os.path.join(profile_path, '.tmdb_auto_installed')
        
        if os.path.exists(flag_file):
            return  # Už bylo nainstalováno
        
        # Pokus o instalaci
        if install_tmdb_player_config():
            # Vytvoř flag soubor
            if not os.path.exists(profile_path):
                os.makedirs(profile_path)
            with open(flag_file, 'w') as f:
                f.write('auto-installed')
            
            # Zobraz notifikaci uživateli
            try:
                xbmcgui.Dialog().notification(
                    'Tshare', 
                    'TMDB Helper player automaticky nainstalovan',
                    xbmcgui.NOTIFICATION_INFO,
                    3000
                )
            except:
                pass
    except Exception as e:
        xbmc.log(f'[Tshare]: Error in auto_install_tmdb_config: {str(e)}', xbmc.LOGERROR)

def main():
    """Hlavní entry point"""
    try:
        # Automaticky zkus nainstalovat TMDB konfiguraci při prvním spuštění
        auto_install_tmdb_config()
        
        # Spusť standardní Tshare router
        Tshare.router(sys.argv[2][1:])
        
    except Exception as e:
        xbmc.log(f'[Tshare]: Critical error in main: {str(e)}', xbmc.LOGERROR)

if __name__ == '__main__':
    main()