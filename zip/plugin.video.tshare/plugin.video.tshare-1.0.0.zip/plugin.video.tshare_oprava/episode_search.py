# -*- coding: utf-8 -*-
"""
Specializované vyhledávání epizod pro Tshare plugin - VYLEPŠENÁ VERZE
"""

import logging
import re
import unidecode
import xbmcplugin  # type: ignore
import xbmcgui  # type: ignore
from xml.etree import ElementTree as ET

def is_matching_episode(filename, series_name, target_season, target_episode):
    """Zkontroluje, zda soubor odpovídá hledané epizodě - ROZŠÍŘENÉ vzory"""
    if not filename or not series_name:
        return False
    
    # ROZŠÍŘENÉ vzory pro detekci epizod
    episode_patterns = [
        # === ZÁKLADNÍ MEZINÁRODNÍ FORMÁTY ===
        r'[Ss](\d{1,2})[Ee](\d{1,2})',         # S01E01, S1E1
        r'(\d{1,2})x(\d{1,2})',                # 1x01, 01x01
        r'(\d{1,2})\.(\d{1,2})',               # 1.01, 01.01
        r'[Ss](\d{1,2})\s*[Ee](\d{1,2})',      # S01 E01, S1 E1
        r'Season\s*(\d{1,2})\s*Episode\s*(\d{1,2})',  # Season 1 Episode 1
        
        # === ČESKÉ FORMÁTY S EXPLICITNÍ SEZÓNOU ===
        r'(\d{1,2})\.\s*série\s*(\d{1,2})\.\s*d[íi]l',  # 1. série 1. díl
        r'(\d{1,2})\.\s*řada\s*(\d{1,2})\.\s*d[íi]l',   # 1. řada 1. díl
        r'(\d{1,2})\.\s*sez[óo]na\s*(\d{1,2})\.\s*d[íi]l', # 1. sezóna 1. díl
        
        # === ČESKÉ FORMÁTY POUZE S EPIZODOU (sezóna = 1) ===
        r'(\d{1,2})\.?\s*d[íi]l',               # 01.díl, 1 díl
        r'(\d{1,2})\.?\s*cast',                 # 01.cast, 1 cast
        r'-\s*(\d{1,2})\.?\s*d[íi]l',           # - 01.díl, - 1 díl
        r'-\s*(\d{1,2})\.?\s*cast',             # - 01.cast, - 1 cast
        
        # === JEDNODUCHÉ FORMÁTY ===
        r'[Ee](\d{1,2})',                       # E01, E1
        r'ep\.?\s*(\d{1,2})',                   # ep.1, ep 1
        r'episode\s*(\d{1,2})',                 # episode 1
    ]
    
    filename_lower = filename.lower()
    series_lower = series_name.lower()
    
    # 1. ZKONTROLUJ NÁZEV SERIÁLU
    series_match = False
    
    # Přímá shoda
    if series_lower in filename_lower:
        series_match = True
    else:
        # Normalizovaná shoda (bez diakritiky)
        normalized_series = unidecode.unidecode(series_lower)
        normalized_filename = unidecode.unidecode(filename_lower)
        if normalized_series in normalized_filename:
            series_match = True
        else:
            # Částečná shoda podle slov
            if len(series_lower) >= 8:
                series_words = series_lower.split()
                if len(series_words) >= 2:
                    matched_words = sum(1 for word in series_words if len(word) >= 3 and word in filename_lower)
                    if matched_words >= len(series_words) * 0.5:
                        series_match = True
    
    if not series_match:
        return False
    
    # 2. NAJDI ČÍSLA SEZÓNY A EPIZODY
    for pattern in episode_patterns:
        match = re.search(pattern, filename_lower)
        if match:
            groups = match.groups()
            
            if len(groups) == 2:  # Vzory se sezónou i epizodou
                try:
                    file_season = int(groups[0])
                    file_episode = int(groups[1])
                    
                    if file_season == target_season and file_episode == target_episode:
                        logging.debug(f'EPISODE MATCH: S{file_season}E{file_episode} == S{target_season}E{target_episode} in "{filename}"')
                        return True
                except (ValueError, IndexError):
                    continue
                    
            elif len(groups) == 1:  # Vzory pouze s epizodou
                try:
                    file_episode = int(groups[0])
                    
                    # Pro vzory pouze s epizodou předpokládej sezónu 1
                    if target_season == 1 and file_episode == target_episode:
                        logging.debug(f'EPISODE MATCH (S1): E{file_episode} == E{target_episode} in "{filename}"')
                        return True
                except (ValueError, IndexError):
                    continue
    
    return False

# VYLEPŠENÉ vzory pro filmy (rozlišení od seriálů)
MOVIE_INDICATORS = [
    r'\b(19|20)\d{2}\b',  # Rok vydání
    r'\b(dvdrip|brrip|webrip|hdtv|bluray|web-dl)\b',  # Formáty typické pro filmy
    r'\b(cam|ts|dvdscr|r5|r6)\b',  # Kvalita typická pro filmy
]

SERIES_EXCLUSION_PATTERNS = [
    r's\d+e\d+',           # S01E01
    r's\d+\s*e\d+',       # S01 E01
    r'\d+x\d+',           # 1x01  
    r'\d+\.\s*d[íi]l',    # 01. díl
    r'-\s*\d+\.\s*d[íi]l', # - 01. díl
    r'[Ee]pisode\s*\d+',   # Episode 1
    r'[Ee]p\s*\d+',       # Ep 1
]

def is_movie_result(filename):
    """Rozhodni, jestli je výsledek film nebo seriál"""
    if not filename:
        return True  # Default k filmu
        
    name_lower = filename.lower()
    
    # Pokud obsahuje vzory seriálů, není to film
    for pattern in SERIES_EXCLUSION_PATTERNS:
        if re.search(pattern, name_lower):
            logging.debug(f'Movie filter: "{filename}" excluded as series (pattern: {pattern})')
            return False
            
    # Pokud obsahuje vzory filmů, je to film
    for pattern in MOVIE_INDICATORS:
        if re.search(pattern, name_lower):
            logging.debug(f'Movie filter: "{filename}" confirmed as movie (pattern: {pattern})')
            return True
            
    # Default: pokud není jasné, považuj za film
    return True

def search_episode(token, series_name, category, sort, limit, offset, season, episode, tmdb_id=None, cz_title=None, original_title=None, year=None):
    """Specializované vyhledávání epizody s DVOUSTUPŇOVÝM vyhledáváním CZ -> originaltitle"""
    logging.info(f'=== EPISODE SEARCH: "{series_name}" S{season}E{episode} ===')
    
    # Import hlavních funkcí
    import Tshare
    
    try:
        # KROK 1: Hledání podle českého názvu (cz_title nebo series_name)
        cz_name = cz_title or series_name
        
        # VYLEPŠENÉ vzory pro hledání epizod podle CZ názvu
        cz_patterns = [
            f"{cz_name} S{season}E{episode.zfill(2)}",
            f"{cz_name} S{season.zfill(2)}E{episode.zfill(2)}",
            f"{cz_name} {season}x{episode.zfill(2)}",
            f"{cz_name} {season}.{episode.zfill(2)}",
            f"{cz_name}",  # Fallback na název seriálu
        ]
        
        cz_episodes = {}
        original_episodes = {}
        
        logging.info(f'Episode search - KROK 1 (CZ): "{cz_name}" S{season}E{episode}')
        
        for search_pattern in cz_patterns:
            logging.info(f'Trying CZ episode pattern: "{search_pattern}"')
            
            # API volání pro CZ název
            Tshare.popinfo(f'Hledám epizodu (CZ): {search_pattern}', icon=xbmcgui.NOTIFICATION_INFO)
            response = Tshare.api('search', {
                'what': search_pattern,
                'category': category,
                'sort': sort,
                'limit': 50,
                'offset': offset,
                'wst': token,
                'maybe_removed': 'true'
            })

            if response is None:
                continue
                
            try:
                xml = ET.fromstring(response.content)
                if Tshare.is_ok(xml):
                    for file in xml.iter('file'):
                        try:
                            item = Tshare.todict(file)
                            if 'ident' in item:
                                filename = item.get('name', '')
                                
                                # Kontrola shody s epizodou
                                if is_matching_episode(filename, cz_name, int(season), int(episode)):
                                    cz_episodes[item['ident']] = item
                                    logging.info(f'CZ EPISODE MATCH: {filename}')
                                    
                        except Exception as e:
                            logging.warning(f'Error processing CZ episode result: {e}')
                            continue
                            
            except ET.ParseError as e:
                logging.error(f'CZ episode search XML parse error: {e}')
                continue
                
            # Pokud jsme našli dostatek epizod podle CZ názvu, přestaň hledat
            if len(cz_episodes) >= 20:
                break
                
        # KROK 2: Pokud málo výsledků a máme original_title, hledej i podle něj
        if len(cz_episodes) < 20 and original_title and original_title != cz_name:
            logging.info(f'Episode search - KROK 2 (Original): "{original_title}" S{season}E{episode} (CZ našlo {len(cz_episodes)} výsledků)')
            
            original_patterns = [
                f"{original_title} S{season}E{episode.zfill(2)}",
                f"{original_title} S{season.zfill(2)}E{episode.zfill(2)}",
                f"{original_title} {season}x{episode.zfill(2)}",
                f"{original_title} {season}.{episode.zfill(2)}",
                f"{original_title}",
            ]
            
            for search_pattern in original_patterns:
                logging.info(f'Trying Original episode pattern: "{search_pattern}"')
                
                # API volání pro originální název
                Tshare.popinfo(f'Hledám epizodu (Original): {search_pattern}', icon=xbmcgui.NOTIFICATION_INFO)
                response = Tshare.api('search', {
                    'what': search_pattern,
                    'category': category,
                    'sort': sort,
                    'limit': 50,
                    'offset': offset,
                    'wst': token,
                    'maybe_removed': 'true'
                })

                if response is None:
                    continue
                    
                try:
                    xml = ET.fromstring(response.content)
                    if Tshare.is_ok(xml):
                        for file in xml.iter('file'):
                            try:
                                item = Tshare.todict(file)
                                if 'ident' in item and item['ident'] not in cz_episodes:  # Nedup
                                    filename = item.get('name', '')
                                    
                                    # Kontrola shody s epizodou (zkusíme oba názvy)
                                    if (is_matching_episode(filename, original_title, int(season), int(episode)) or
                                        is_matching_episode(filename, cz_name, int(season), int(episode))):
                                        original_episodes[item['ident']] = item
                                        logging.info(f'ORIGINAL EPISODE MATCH: {filename}')
                                        
                            except Exception as e:
                                logging.warning(f'Error processing original episode result: {e}')
                                continue
                                
                except ET.ParseError as e:
                    logging.error(f'Original episode search XML parse error: {e}')
                    continue
                    
                # Pokud máme dostatek výsledků, přestaň
                if len(original_episodes) >= 20:
                    break
                    
        # KROK 3: Zobrazení výsledků - NEJDŘÍVE CZ, PAK ORIGINAL
        if cz_episodes:
            sorted_cz = Tshare.intelligent_sort_files(cz_episodes)
            logging.info(f'Zobrazuji {len(sorted_cz)} CZ epizod')
            
            for ident, item in sorted_cz.items():
                try:
                    listitem = Tshare.tolistitem(item, tmdb_id=tmdb_id, media_type='tv')
                    
                    url_params = {
                        'action': 'play',
                        'ident': ident,
                        'name': item.get('name', 'Unknown'),
                        'tmdb_id': tmdb_id,
                        'series_name': series_name,
                        'season': season,
                        'episode': episode
                    }
                    
                    url = Tshare.get_url(**url_params)
                    xbmcplugin.addDirectoryItem(Tshare._handle, url, listitem, False)
                    
                except Exception as e:
                    logging.error(f'Error adding CZ episode item: {e}')
                    continue
                    
        if original_episodes:
            sorted_original = Tshare.intelligent_sort_files(original_episodes)
            logging.info(f'Zobrazuji {len(sorted_original)} originálních epizod')
            
            for ident, item in sorted_original.items():
                try:
                    listitem = Tshare.tolistitem(item, tmdb_id=tmdb_id, media_type='tv')
                    
                    url_params = {
                        'action': 'play',
                        'ident': ident,
                        'name': item.get('name', 'Unknown'),
                        'tmdb_id': tmdb_id,
                        'series_name': series_name,
                        'season': season,
                        'episode': episode
                    }
                    
                    url = Tshare.get_url(**url_params)
                    xbmcplugin.addDirectoryItem(Tshare._handle, url, listitem, False)
                    
                except Exception as e:
                    logging.error(f'Error adding original episode item: {e}')
                    continue
                    
        total_count = len(cz_episodes) + len(original_episodes)
        logging.info(f'Episode search celkem: {total_count} epizod (CZ: {len(cz_episodes)}, Original: {len(original_episodes)})')
        
        if total_count == 0:
            Tshare.popinfo(f'Nenalezena epizoda S{season}E{episode}', icon=xbmcgui.NOTIFICATION_WARNING)

    except Exception as e:
        logging.error(f'Episode search error: {e}')
        Tshare.popinfo(f'Chyba při hledání epizody: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
        
    xbmcplugin.endOfDirectory(Tshare._handle)
