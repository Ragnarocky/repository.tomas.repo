# --- Dočasné uložení kompletních metadat z TMDB Helperu ---
def save_tmp_metadata(meta):
    path = os.path.join(_profile, 'movies_metadata_tmp.json')
    try:
        with io.open(path, 'w', encoding='utf8') as file:
            json.dump(meta, file, indent=2)
    except Exception:
        pass

def load_tmp_metadata():
    path = os.path.join(_profile, 'movies_metadata_tmp.json')
    if os.path.exists(path):
        try:
            with io.open(path, 'r', encoding='utf8') as file:
                return json.load(file)
        except Exception:
            return None
    return None

def clear_tmp_metadata():
    path = os.path.join(_profile, 'movies_metadata_tmp.json')
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass
# --- Dočasná historie filmů ---
def load_tmp_movies_history():
    path = os.path.join(_profile, 'movies_history_tmp.json')
    if os.path.exists(path):
        try:
            with io.open(path, 'r', encoding='utf8') as file:
                return json.load(file)
        except Exception:
            return []
    return []

def save_tmp_movies_history(history):
    path = os.path.join(_profile, 'movies_history_tmp.json')
    try:
        with io.open(path, 'w', encoding='utf8') as file:
            json.dump(history, file, indent=2)
    except Exception:
        pass

def clear_tmp_movies_history():
    path = os.path.join(_profile, 'movies_history_tmp.json')
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass
TMDB_API_KEY = None  # Uživatel si musí zadat vlastní klíč v nastavení

def get_tmdb_details(tmdb_id, media_type='movie', language='cs-CZ'):
    """Získá detaily filmu/seriálu z TMDB podle ID."""
    if not tmdb_id:
        logging.warning('get_tmdb_details: tmdb_id není zadáno')
        return None
    
    # Získej API klíč - pouze z uživatelského nastavení
    user_api_key = _addon.getSetting('tmdb_api_key').strip()
    
    if not user_api_key:
        logging.warning('get_tmdb_details: TMDB API klíč není nastaven')
        return None
    
    # OPRAVA: Správné media_type pro TMDB API
    if media_type == 'video':
        media_type = 'movie'  # Video se mapuje na movie
    elif media_type not in ['movie', 'tv']:
        media_type = 'movie'  # Default na movie
    
    url = f'https://api.themoviedb.org/3/{media_type}/{tmdb_id}'
    params = {
        'api_key': user_api_key,
        'language': language
    }
    
    logging.debug(f'get_tmdb_details: url={url}')
    
    try:
        response = requests.get(url, params=params, timeout=10)
        logging.debug(f'get_tmdb_details: status_code={response.status_code}')
        
        if response.status_code == 200:
            data = response.json()
            logging.debug(f'get_tmdb_details: success for {media_type} {tmdb_id}')
            
            return {
                'cz_title': data.get('title') or data.get('name'),
                'original_title': data.get('original_title') or data.get('original_name'),
                'title': data.get('title'),
                'name': data.get('name'),
                'year': (data.get('release_date') or data.get('first_air_date') or '')[:4],
                'overview': data.get('overview'),
                'poster_path': data.get('poster_path'),
                'imdb_id': data.get('imdb_id'),
                'genres': data.get('genres', []),
                'vote_average': data.get('vote_average'),
                'runtime': data.get('runtime')
            }
        elif response.status_code == 401:
            logging.error('get_tmdb_details: Neplatný TMDB API klíč')
            popinfo('TMDB API klíč je neplatný. Zkontrolujte nastavení.', icon=xbmcgui.NOTIFICATION_ERROR)
            return None
        elif response.status_code == 404:
            logging.warning(f'get_tmdb_details: {media_type} {tmdb_id} nenalezen')
            return None
        else:
            logging.error(f'get_tmdb_details: TMDB API error {response.status_code} - {response.text[:200]}')
            return None
            
    except requests.Timeout:
        logging.error('get_tmdb_details: Timeout při dotazu na TMDB API')
        return None
    except requests.ConnectionError:
        logging.error('get_tmdb_details: Chyba připojení k TMDB API')
        return None
    except Exception as e:
        logging.error(f'get_tmdb_details: Neočekávaná chyba: {str(e)}')
        return None

def test_tmdb_api():
    """Otestuje funkčnost TMDB API klíče"""
    try:
        user_api_key = _addon.getSetting('tmdb_api_key').strip()
        
        if not user_api_key:
            popinfo('TMDB API klíč není nastaven.\nZadejte vlastní klíč v nastavení pro lepší vyhledávání.', icon=xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Test s známým filmem (The Matrix)
        test_url = 'https://api.themoviedb.org/3/movie/603'
        params = {
            'api_key': user_api_key,
            'language': 'cs-CZ'
        }
        
        logging.debug(f'TMDB API test: testing with user key')
        
        response = requests.get(test_url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            movie_title = data.get('title', 'Unknown')
            logging.info(f'TMDB API test: SUCCESS - získán film "{movie_title}"')
            popinfo(f'TMDB API klíč je funkční!\nTest film: {movie_title}', icon=xbmcgui.NOTIFICATION_INFO)
                
        elif response.status_code == 401:
            logging.error('TMDB API test: Neplatný API klíč')
            popinfo('TMDB API klíč je neplatný!\nZkontrolujte nastavení.', icon=xbmcgui.NOTIFICATION_ERROR)
                
        elif response.status_code == 429:
            logging.error('TMDB API test: Překročen rate limit')
            popinfo('TMDB API rate limit překročen.\nZkuste později.', icon=xbmcgui.NOTIFICATION_WARNING)
            
        else:
            logging.error(f'TMDB API test: HTTP {response.status_code} - {response.text[:200]}')
            popinfo(f'TMDB API test selhal\nHTTP {response.status_code}', icon=xbmcgui.NOTIFICATION_ERROR)
            
    except requests.Timeout:
        logging.error('TMDB API test: Timeout')
        popinfo('TMDB API test: Timeout připojení', icon=xbmcgui.NOTIFICATION_ERROR)
    except requests.ConnectionError:
        logging.error('TMDB API test: Connection error')
        popinfo('TMDB API test: Chyba připojení', icon=xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        logging.error(f'TMDB API test: Neočekávaná chyba: {str(e)}')
        popinfo(f'TMDB API test: Neočekávaná chyba\n{str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
# -*- coding: utf-8 -*-
# Module: default
# Author: Tomas for friends
# Created on: 2.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import io
import os
import sys
import time
import logging
import xbmc  # type: ignore
import xbmcgui  # type: ignore
import xbmcplugin  # type: ignore
import xbmcaddon  # type: ignore
import xbmcvfs  # type: ignore
import requests  # type: ignore
import requests.cookies  # type: ignore
from xml.etree import ElementTree as ET
import hashlib
from md5crypt import md5crypt
import traceback
import json
import unidecode  # type: ignore
import re
import uuid
import series_manager
import trakt_integration
import movie_search
import episode_search

try:
    from urllib import urlencode  # type: ignore
    from urlparse import parse_qsl, urlparse  # type: ignore
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl, urlparse

try:
    from xbmc import translatePath  # type: ignore
except ImportError:
    from xbmcvfs import translatePath  # type: ignore

BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer':BASE}
REALM = ':Webshare:'
CATEGORIES = ['','video','images','audio','archives','docs','adult']
SORTS = ['','recent','rating','largest','smallest']
SEARCH_HISTORY = 'search_history'
NONE_WHAT = '%#NONE#%'

# Cache settings
CACHE_TIMEOUT = 300  # 5 minut
SEARCH_CACHE_TIMEOUT = 1800  # 30 minut pro vyhledávání
_cache = {}

# Nové konstanty pro chytřejší vyhledávání
QUALITY_PATTERNS = {
    '4K': ['2160p', '4k', 'uhd'],
    '1080p': ['1080p', 'fullhd', 'fhd'],
    '720p': ['720p', 'hd'],
    '480p': ['480p', 'sd']
}

CZECH_PATTERNS = [
    'czdab', 'cz dab', 'czdabing', 'cz dabing', 'cz audio', 
    'cz', 'czech', 'cz jazyk', 'cesky', 'sk', 'slovak', 'slovensky'
]

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)
_session.timeout = (10, 30)  # connection timeout, read timeout
_profile = translatePath( _addon.getAddonInfo('profile'))
try:
    _profile = _profile.decode("utf-8")
except:
    pass

# Setup logging
def setup_logging():
    """Setup logging for debugging purposes"""
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)
        log_path = os.path.join(_profile, 'Tshare.log')
        logging.basicConfig(
            filename=log_path,
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            filemode='a'
        )
        # Also log to Kodi log
        logging.getLogger().addHandler(logging.StreamHandler())
    except Exception as e:
        xbmc.log(f'Tshare: Nelze nastavit logování: {str(e)}', level=xbmc.LOGERROR)

# Initialize logging
setup_logging()

def smart_cache_cleanup():
    """Vyčistí staré položky z cache"""
    global _cache
    current_time = time.time()
    
    # Vyčisti cache - rozliš mezi API a search cache podle timeout
    expired_keys = []
    for k, (cached_time, _) in _cache.items():
        if k.startswith('search_'):
            # Search cache má delší timeout
            if current_time - cached_time > SEARCH_CACHE_TIMEOUT:
                expired_keys.append(k)
        else:
            # API cache má kratší timeout
            if current_time - cached_time > CACHE_TIMEOUT:
                expired_keys.append(k)
    
    for key in expired_keys:
        del _cache[key]
    
    logging.debug(f'Cache cleanup: removed {len(expired_keys)} expired entries')

def get_quality_score(filename):
    """Určí skóre kvality s lepší detekcí"""
    if not filename:
        return 0
    
    filename_lower = filename.lower()
    for quality, patterns in QUALITY_PATTERNS.items():
        for pattern in patterns:
            if pattern in filename_lower:
                if quality == '4K':
                    return 100
                elif quality == '1080p':
                    return 80
                elif quality == '720p':
                    return 60
                elif quality == '480p':
                    return 40
    return 20  # Neznámá kvalita

def get_czech_score(filename):
    """Určí skóre pro české/slovenské obsahy s vylepšenou detekcí dabingu"""
    if not filename:
        return 0
    
    filename_lower = filename.lower()
    score = 0
    
    # Prioritní vzory (vyšší skóre pro dabing)
    high_priority_patterns = ['czdab', 'cz dab', 'czdabing', 'cz dabing', 'cz audio']
    medium_priority_patterns = ['cz', 'czech', 'cz jazyk', 'cesky']
    low_priority_patterns = ['sk', 'slovak', 'slovensky']
    
    # Kontrola vysoké priority (dabing má přednost)
    for pattern in high_priority_patterns:
        if pattern in filename_lower:
            score = max(score, 100)  # Nejvyšší skóre pro dabing
    
    # Kontrola střední priority
    for pattern in medium_priority_patterns:
        if pattern in filename_lower:
            score = max(score, 70)
    
    # Kontrola nízké priority
    for pattern in low_priority_patterns:
        if pattern in filename_lower:
            score = max(score, 50)
    
    return score

def get_file_size_score(size_str):
    """Převede velikost na číselné skóre pro řazení"""
    try:
        if not size_str:
            return 0
        
        # Parsuj velikost
        size_str = str(size_str).upper()
        if 'GB' in size_str:
            return float(size_str.replace('GB', '').strip()) * 1000
        elif 'MB' in size_str:
            return float(size_str.replace('MB', '').strip())
        elif 'KB' in size_str:
            return float(size_str.replace('KB', '').strip()) / 1000
        else:
            # Zkus parsovat jako číslo v bytech
            return float(size_str) / (1024 * 1024)  # Převod na MB
    except:
        return 0

# === Rok: extrakce a řazení podle roku (pro filmy/remaky) ===
def _extract_year(text):
    """Vrátí první rok 1900–2099 z textu, jinak None."""
    try:
        m = re.search(r'(?<!\d)(?:19|20)\d{2}(?!\d)', text or '')
        if m:
            return int(m.group(0))
    except Exception:
        pass
    return None

def _year_score(expected_year, text):
    """Skóre shody roků; vyšší = lepší."""
    if not expected_year:
        return 0
    y = _extract_year(text)
    if y is None:
        return -1
    diff = abs(int(y) - int(expected_year))
    if diff == 0:
        return 4
    if diff == 1:
        return 3
    if diff == 2:
        return 2
    return 0

def sort_results_by_year_preference(files_dict, expected_year):
    """Stabilně seřadí výsledky dle shody roku (aplikuje se vždy, pokud je rok znám)."""
    try:
        if not expected_year or not files_dict:
            return files_dict
        items = list(files_dict.items())
        # Stabilní sort: rok (desc), zachová relativní pořadí při shodě
        items.sort(key=lambda kv: _year_score(expected_year, kv[1].get('name', '')), reverse=True)
        return dict(items)
    except Exception:
        return files_dict

def intelligent_sort_files(files_dict, search_year=None):
    """Inteligentní řazení souborů podle kvality, jazyka, velikosti a roku"""
    if not files_dict:
        return files_dict
    
    files_list = list(files_dict.items())
    
    def sort_key(item):
        ident, file_data = item
        name = file_data.get('name', '')
        size = file_data.get('size', 0)
        
        quality_score = get_quality_score(name)
        czech_score = get_czech_score(name)
        size_score = get_file_size_score(size)
        
        # DYNAMICKÉ: Bonus za správný rok podle vyhledávání
        year_bonus = 0
        if search_year:
            # Najdi rok v názvu souboru (1900–2099)
            year_match = re.search(r'\b(?:19|20)\d{2}\b', name)
            if year_match:
                file_year = int(year_match.group(0))
                search_year_int = int(search_year)
                year_diff = abs(file_year - search_year_int)
                
                if year_diff == 0:
                    year_bonus = 10000  # Nejvyšší bonus pro přesnou shodu
                elif year_diff <= 1:
                    year_bonus = 5000   # Vysoký bonus pro blízký rok
                elif year_diff <= 3:
                    year_bonus = 2000   # Střední bonus
                elif year_diff <= 10:
                    year_bonus = 500    # Malý bonus
                # Jinak žádný bonus
        
        # Kombinované skóre: rok má nejvyšší prioritu, pak jazyk, pak kvalita, pak velikost
        return (year_bonus + czech_score * 10000 + quality_score * 100 + min(size_score, 99))
    
    sorted_files = sorted(files_list, key=sort_key, reverse=True)
    return dict(sorted_files)

def get_cached_search(query, category, sort):
    """Získá cachované výsledky vyhledávání"""
    cache_key = f'search_{hashlib.md5((query + str(category) + str(sort)).encode()).hexdigest()}'
    if cache_key in _cache:
        cached_time, cached_results = _cache[cache_key]
        if time.time() - cached_time < SEARCH_CACHE_TIMEOUT:
            logging.debug(f'Using cached search results for: {query}')
            return cached_results
    return None

def cache_search_results(query, category, sort, results):
    """Cachuje výsledky vyhledávání"""
    cache_key = f'search_{hashlib.md5((query + str(category) + str(sort)).encode()).hexdigest()}'
    _cache[cache_key] = (time.time(), results)
    
    # Omez velikost cache
    if len(_cache) > 100:
        oldest_key = min(_cache.keys(), key=lambda k: _cache[k][0])
        del _cache[oldest_key]

def safe_log(message, level='debug'):
    """Bezpečné logování s handling pro Unicode znaky"""
    try:
        # Normalizuj Unicode znaky pro bezpečné logování
        safe_message = message.encode('ascii', 'replace').decode('ascii')
        if level == 'debug':
            logging.debug(safe_message)
        elif level == 'info':
            logging.info(safe_message)
        elif level == 'warning':
            logging.warning(safe_message)
        elif level == 'error':
            logging.error(safe_message)
    except Exception:
        # Jako poslední záchranu použij pouze ASCII znaky
        try:
            ascii_message = str(message).encode('ascii', 'replace').decode('ascii')
            logging.debug(f'Log message (ASCII): {ascii_message}')
        except:
            logging.debug('Log message with encoding issues')

def is_relevant_result(filename, search_query, search_type):
    """Zkontroluje, zda je výsledek relevantní k hledanému dotazu"""
    if not filename or not search_query:
        return True
    
    filename_lower = filename.lower()
    query_lower = search_query.lower()
    
    # NOVÁ LOGIKA: Pro episode_search použij speciální detekci epizod
    if search_type == 'episode_search':
        # Extrakuj epizodové informace z dotazu a názvu souboru
        query_episode_info = _detect_episode_info(search_query)
        file_episode_info = _detect_episode_info(filename)
        
        if query_episode_info[0] and query_episode_info[1] and file_episode_info[0] and file_episode_info[1]:
            # Máme kompletní info o epizodách v obou
            query_season, query_episode = query_episode_info
            file_season, file_episode = file_episode_info
            
            # Porovnej sezónu a epizodu
            if query_season == file_season and query_episode == file_episode:
                # Stejná epizoda - zkontroluj ještě název seriálu
                query_clean = re.sub(r's\d+e\d+', '', query_lower, flags=re.IGNORECASE).strip()
                query_clean = re.sub(r'\d+x\d+', '', query_clean).strip()
                query_clean = re.sub(r'[Ee]\d+', '', query_clean).strip()
                
                filename_clean = re.sub(r's\d+e\d+', '', filename_lower, flags=re.IGNORECASE).strip()
                filename_clean = re.sub(r'\d+x\d+', '', filename_clean).strip()
                filename_clean = re.sub(r'[Ee]\d+', '', filename_clean).strip()
                
                # Zkontroluj, jestli název seriálu sedí
                if query_clean and len(query_clean) >= 3:
                    # Normalizuj názvy
                    normalized_query = unidecode.unidecode(query_clean).lower()
                    normalized_filename = unidecode.unidecode(filename_clean).lower()
                    
                    if normalized_query in normalized_filename or normalized_filename.startswith(normalized_query):
                        safe_log(f'Episode match: "{filename}" matches "{search_query}" (S{file_season}E{file_episode} == S{query_season}E{query_episode})')
                        return True
                else:
                    # Pokud není název seriálu, považuj za shodu (jen podle epizody)
                    safe_log(f'Episode match by numbers only: "{filename}" matches "{search_query}" (S{file_season}E{file_episode} == S{query_season}E{query_episode})')
                    return True
            else:
                safe_log(f'Episode mismatch: "{filename}" (S{file_season}E{file_episode}) vs "{search_query}" (S{query_season}E{query_episode})')
                return False
        
        # Pokud není detekována epizoda v jednom z nich, použij fallback
        safe_log(f'Episode detection failed for: query="{search_query}" ({query_episode_info}) vs file="{filename}" ({file_episode_info})')
    
    # VYLEPŠENÉ: Vyřaď seriály při hledání filmů - detekce vzorů seriálů
    series_patterns = [
        r's\d+e\d+',           # S01E01
        r's\d+\s*e\d+',       # S01 E01  
        r'season\s*\d+',       # Season 1
        r'serie\s*\d+',       # Serie 1
        r'rada\s*\d+',        # Rada 1
        r'\d+x\d+',           # 1x01
        r'ep\s*\d+',          # Ep 01
        r'episode\s*\d+',     # Episode 01
        r'epizoda\s*\d+',     # Epizoda 01
        r'dil\s*\d+',         # Dil 01
        r'cast\s*\d+',        # Cast 01
        r'\d+\.\s*dil',       # 1. dil
        r'\d+\.\s*cast',      # 1. cast
        r'\d+\.\s*d[íi]l',    # 01.díl, 02.díl (s povinnou tečkou)
        r'\d+\s+d[íi]l',      # 01 díl, 02 díl (bez tečky)
        r'\d+\.?\s*cast',     # 01.cast, 02 cast, 03cast
        r'-\s*\d+\.?\s*d[íi]l', # - 01.díl, - 02 díl
        r'-\s*\d+\.?\s*cast', # - 01.cast, - 02 cast
        r'ii\.\s*-\s*\d+',    # II. - 01, II. - 02 (pokračování)
        r'\b\d{1,3}\.?\s*d[íi]l\b',  # 1díl, 01.díl, 39.díl atd. (word boundary)
        r'\b\d{1,3}\.?\s*cast\b',    # 1cast, 01.cast, 39.cast atd.
        r'\b\d{1,3}\.\s*d[íi]l\b',   # EXPLICITNĚ: 01.díl, 02.díl atd.
        r'\b\d{1,3}\.\s*cast\b',     # EXPLICITNĚ: 01.cast, 02.cast atd.
        r'e\d+\b',            # E01, E02 (samostatné)
        r'\be\d+',            # začíná E číslem
        r'\.e\d+\.',          # .E01.
        r'_e\d+_',            # _E01_
        r'-e\d+-',            # -E01-
        r'\[\d+x\d+\]',       # [1x01]
        r'\(\d+x\d+\)',       # (1x01)
        r'disk\s*\d+',        # Disk 1 (často u seriálů)
        r'disc\s*\d+',        # Disc 1
        r'cd\s*\d+',          # CD 1
        r'dvd\s*\d+',         # DVD 1
    ]
    
    # Pokud filename obsahuje vzory seriálů, vyřaď ho při hledání filmů
    # KLÍČOVÁ OPRAVA: Zkontroluj search_type - pouze u filmového vyhledávání filtruj seriály
    is_movie_search = search_type not in ['series_search', 'explicit_series', 'episode_search'] and 'series' not in str(search_type).lower()
    
    # NOVÁ LOGIKA: Pokud uživatel hledá explicitně seriálový vzor (S01E01), nefiltruj seriály
    user_searches_episode = False
    for pattern in series_patterns[:5]:  # Kontroluj jen hlavní vzory S01E01, 1x01 atd.
        if re.search(pattern, query_lower):
            user_searches_episode = True
            break
    
    # DEBUG: Loguj typ vyhledávání
    safe_log(f'Search type check: search_type="{search_type}", is_movie_search={is_movie_search}, user_searches_episode={user_searches_episode}')
    
    # Filtruj seriály pouze pokud hledáme filmy A uživatel nehledá konkrétní epizodu A není to episode_search
    if is_movie_search and not user_searches_episode and search_type != 'episode_search':
        for pattern in series_patterns:
            if re.search(pattern, filename_lower):
                safe_log(f'Excluding series result: {filename} (matched pattern: {pattern})')
                return False
    
    # Odstraň speciální klíčová slova z dotazu pro porovnání
    query_clean = query_lower
    for keyword in ['cz', 'czdab', 'dabing', 'audio']:
        query_clean = query_clean.replace(keyword, '').strip()
    
    # VYLEPŠENÉ: Extrakce roku z dotazu I souboru
    search_year_match = re.search(r'\b(?:19|20)\d{2}\b', query_clean)
    search_year = search_year_match.group(0) if search_year_match else None
    
    file_year_match = re.search(r'\b(?:19|20)\d{2}\b', filename_lower)
    file_year = file_year_match.group(0) if file_year_match else None
    
    # Odstraň rok z hlavního názvu
    if search_year:
        main_title = query_clean.replace(search_year, '').strip()
    else:
        main_title = query_clean.strip()
    
    # Pokud je název příliš krátký, neprovádej filtrování
    if len(main_title) < 3:
        return True
    
    # NOVÁ LOGIKA: Spoj slova s číslicemi 1-9 do jednoho logického slova
    def create_compound_words(text):
        """Vytvoří seznam kombinovaných slov pro porovnání"""
        words = text.split()
        compound_words = []
        
        i = 0
        while i < len(words):
            word = words[i]
            # Pokud následující slovo je číslice 1-9, spoj je logicky
            if i + 1 < len(words) and words[i + 1].isdigit() and len(words[i + 1]) == 1:
                # Vytvoř kombinované slovo pro porovnání
                compound_word = word + words[i + 1]
                compound_words.append(compound_word)
                i += 2  # Přeskoč obě slova
            else:
                compound_words.append(word)
                i += 1
        
        return compound_words
    
    # Vytvoř kombinovaná slova z hlavního názvu
    title_compound_words = create_compound_words(main_title)
    
    # Počítej shody kombinovaných slov - VYLEPŠENÉ s normalizací diakritiky
    found_words = 0
    for compound_word in title_compound_words:
        # Normalizuj slovo pro lepší porovnání
        normalized_word = unidecode.unidecode(compound_word).lower()
        normalized_filename = unidecode.unidecode(filename_lower)
        
        # Pro kombinované slovo (např. "zlouni2") zkontroluj různé varianty v názvu souboru
        if len(compound_word) >= 3:
            # Zkus najít kombinované slovo (bez mezery) - normalizované
            if normalized_word in normalized_filename.replace(' ', '').replace('.', '').replace('_', '').replace('-', ''):
                found_words += 1
                continue
            # Zkus najít původní slova s mezerou (např. "zlouni 2" nebo "zlouni.2") - normalizované
            elif len(normalized_word) > 1 and normalized_word[-1].isdigit():
                base_word = normalized_word[:-1]
                digit = normalized_word[-1]
                if re.search(rf'\b{re.escape(base_word)}\s*[._-]*\s*{digit}\b', normalized_filename):
                    found_words += 1
                    continue
            # Zkus najít pouze hlavní část slova (pro případ, že číslice chybí) - normalizované
            elif len(normalized_word) > 1 and normalized_word[-1].isdigit():
                base_word = normalized_word[:-1]
                if len(base_word) >= 3 and base_word in normalized_filename:
                    found_words += 1
                    continue
            # Zkus přímé hledání normalizovaného slova
            elif normalized_word in normalized_filename:
                found_words += 1
                continue
        # Pro krátká slova (méně než 3 znaky) použij přesnou shodu - normalizované
        elif normalized_word in normalized_filename:
            found_words += 1
    
    # Kontrola relevantnosti
    total_words = len(title_compound_words)
    
    # UPRAVENÉ: Kontrola roku - mírnější penalizace pro přesné shody
    year_penalty = 0
    if search_year and file_year:
        year_diff = abs(int(search_year) - int(file_year))
        if year_diff == 0:
            # Přesná shoda roku - bonus (žádná penalizace)
            year_penalty = 0
        elif year_diff <= 1:
            # Velmi blízký rok - malá penalizace
            year_penalty = 0.1
        elif year_diff <= 3:
            # Blízký rok - střední penalizace
            year_penalty = 0.3
        elif year_diff <= 10:
            # Vzdálenější rok - vyšší penalizace
            year_penalty = 0.6
        else:
            # Velmi vzdálený rok - vysoká penalizace
            year_penalty = 0.8
    elif search_year and not file_year:
        # Hledáme konkrétní rok, ale soubor rok neobsahuje - malá penalizace
        year_penalty = 0.2
    
    # Aplikuj penalizaci na práh relevance
    if total_words <= 2:
        base_threshold = total_words
    else:
        base_threshold = max(2, int(total_words * 0.7))  # 70% slov
    
    # Pro přesné hledání buď přísnější
    if search_type in ['direct', 'tmdb_czech', 'tmdb_original', 'direct_year', 'tmdb_czech_year', 'tmdb_original_year']:
        if total_words <= 2:
            base_threshold = total_words  # Vždy všechna kombináta slova
        else:
            base_threshold = max(2, int(total_words * 0.8))  # 80% slov
    
    # NOVÉ: Pro přesné TMDB vyhledávání s konkrétním názvem buď ještě přísnější
    if search_type.startswith('tmdb_') and total_words >= 3:
        # Pokud hledáme "Mezi námi děvčaty 2", vyžaduj minimálně 3 ze 4 slov
        base_threshold = max(3, int(total_words * 0.85))  # 85% slov pro TMDB
    
    # Zvýš práh podle penalizace za rok
    adjusted_threshold = base_threshold + year_penalty
    
    is_relevant = found_words >= adjusted_threshold
    
    safe_log(f'Relevance check: "{filename}" vs "{search_query}" -> {is_relevant} (found {found_words}/{total_words} words, year_penalty={year_penalty:.1f}, threshold={adjusted_threshold:.1f})')
    
    return is_relevant

# Regular expressions for detecting episode patterns, shared with series_manager
EPISODE_PATTERNS = [
    r'[Ss](\d{1,2})[Ee](\d{1,2})',  # S01E01, S1E1 format (1-2 digits)
    r'(\d+)x(\d+)',         # 1x01 format
    r'[Ee]pisode\s*(\d+)',  # Episode 1 format
    r'[Ee]p\s*(\d+)',       # Ep 1 format
    r'[Ee](\d+)',           # E1 format
    r'(\d+)\.\s*(\d+)'      # 1.01 format
]

def validate_params(params, required_keys):
    """Validate that required parameters are present"""
    for key in required_keys:
        if key not in params or not params[key]:
            logging.error(f'Missing required parameter: {key}')
            return False, f'Missing required parameter: {key}'
    return True, None

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def api_call_with_cache(fnct, data, cache_key=None, timeout=CACHE_TIMEOUT):
    """Unified cache system for all API calls"""
    try:
        # Check cache first
        if cache_key and cache_key in _cache:
            cached_time, cached_response = _cache[cache_key]
            if time.time() - cached_time < timeout:
                logging.debug(f'Using cached response for {cache_key}')
                return cached_response

        # Make API call
        logging.debug(f'Making API call to {fnct} with data: {data}')
        response = _session.post(API + fnct + "/", data=data)

        # Cache the response if cache_key provided
        if cache_key and response.status_code == 200:
            _cache[cache_key] = (time.time(), response)
            logging.debug(f'Cached response for {cache_key}')

        return response

    except requests.Timeout:
        logging.error(f'Timeout při API volání {fnct}')
        popinfo('Vypršel časový limit spojení', icon=xbmcgui.NOTIFICATION_ERROR)
        return None
    except requests.ConnectionError:
        logging.error(f'Chyba připojení při API volání {fnct}')
        popinfo('Chyba připojení k serveru', icon=xbmcgui.NOTIFICATION_ERROR)
        return None
    except requests.RequestException as e:
        logging.error(f'Síťová chyba při API volání {fnct}: {str(e)}')
        popinfo(f'Síťová chyba: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
        return None

def cached_api_call(fnct, data, cache_key=None):
    """API call with caching for better performance"""
    return api_call_with_cache(fnct, data, cache_key)

def api(fnct, data):
    """Standard API call without caching"""
    return api_call_with_cache(fnct, data)

def is_ok(xml):
    """Check if XML response indicates success"""
    if xml is None:
        return False
    status_elem = xml.find('status')
    if status_elem is None:
        logging.error('XML response missing status element')
        return False
    return status_elem.text == 'OK'

def popinfo(message, heading=_addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False):
    """Show notification with logging"""
    logging.info(f'Notification: {message}')
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def login():
    """Login with improved error handling"""
    try:
        username = _addon.getSetting('wsuser')
        password = _addon.getSetting('wspass')

        if not username or not password:
            logging.warning('Missing login credentials')
            popinfo(_addon.getLocalizedString(30101), sound=True)
            _addon.openSettings()
            return None

        logging.debug(f'Attempting login for user: {username}')
        response = api('salt', {'username_or_email': username})

        if response is None:
            return None

        try:
            xml = ET.fromstring(response.content)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in login: {str(e)}')
            popinfo('Chyba při zpracování odpovědi serveru', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

        if is_ok(xml):
            salt = xml.find('salt').text
            try:
                encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
                pass_digest = hashlib.md5(username.encode('utf-8') + REALM + encrypted_pass.encode('utf-8')).hexdigest()
            except TypeError:
                encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
                pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()

            response = api('login', {'username_or_email': username, 'password': encrypted_pass, 'digest': pass_digest, 'keep_logged_in': 1})
            if response is None:
                return None

            try:
                xml = ET.fromstring(response.content)
            except ET.ParseError as e:
                logging.error(f'XML parsing error in login verification: {str(e)}')
                popinfo('Chyba při zpracování přihlášení', icon=xbmcgui.NOTIFICATION_ERROR)
                return None

            if is_ok(xml):
                token = xml.find('token').text
                _addon.setSetting('token', token)
                logging.info('Login successful')
                return token
            else:
                logging.error('Login failed - invalid credentials')
                popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
                _addon.openSettings()
        else:
            logging.error('Salt request failed')
            popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            _addon.openSettings()

    except Exception as e:
        logging.error(f'Unexpected error in login: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při přihlašování', icon=xbmcgui.NOTIFICATION_ERROR)
        return None

def revalidate():
    """Revalidate token with improved error handling"""
    try:
        token = _addon.getSetting('token')
        if len(token) == 0:
            logging.debug('No token found, attempting login')
            new_token = login()
            if new_token:
                return revalidate()
            return None
        else:
            # Use cache for user_data calls
            cache_key = f'user_data_{token[:10]}'
            response = cached_api_call('user_data', {'wst': token}, cache_key)

            if response is None:
                return None

            try:
                xml = ET.fromstring(response.content)
            except ET.ParseError as e:
                logging.error(f'XML parsing error in revalidate: {str(e)}')
                popinfo('Chyba při ověřování přihlášení', icon=xbmcgui.NOTIFICATION_ERROR)
                return None

            if is_ok(xml):
                vip = xml.find('vip')
                if vip is not None and vip.text != '1':
                    popinfo(_addon.getLocalizedString(30103), icon=xbmcgui.NOTIFICATION_WARNING)
                return token
            else:
                logging.warning('Token validation failed, attempting relogin')
                new_token = login()
                if new_token:
                    return revalidate()
                return None

    except Exception as e:
        logging.error(f'Unexpected error in revalidate: {str(e)}')
        traceback.print_exc()
        return None

def todict(xml, skip=[]):
    """Convert XML to dictionary with error handling"""
    try:
        result = {}
        for e in xml:
            if e.tag not in skip:
                value = e.text if len(list(e)) == 0 else todict(e,skip)
                if e.tag in result:
                    if isinstance(result[e.tag], list):
                        result[e.tag].append(value)
                    else:
                        result[e.tag] = [result[e.tag],value]
                else:
                    result[e.tag] = value
        return result
    except Exception as e:
        logging.error(f'Error converting XML to dict: {str(e)}')
        return {}

def sizelize(txtsize, units=['B','KB','MB','GB']):
    """Convert size to human readable format with error handling"""
    try:
        if txtsize:
            size = float(txtsize)
            if size < 1024:
                size = str(size) + units[0]
            else:
                size = size / 1024
                if size < 1024:
                    size = str(int(round(size))) + units[1]
                else:
                    size = size / 1024
                    if size < 1024:
                        size = str(round(size,2)) + units[2]
                    else:
                        size = size / 1024
                        size = str(round(size,2)) + units[3]
            return size
    except (ValueError, TypeError) as e:
        logging.warning(f'Error formatting size {txtsize}: {str(e)}')
    return str(txtsize) if txtsize else '?'

def labelize(file):
    """Create label for file with error handling"""
    try:
        if 'size' in file:
            size = sizelize(file['size'])
        elif 'sizelized' in file:
            size = file['sizelized']
        else:
            size = '?'
        name = file.get('name', 'Unknown')
        label = name + ' (' + size + ')'
        return label
    except Exception as e:
        logging.error(f'Error creating label: {str(e)}')
        return file.get('name', 'Unknown file')

def tolistitem(file, addcommands=[], tmdb_id=None, media_type='movie'):
    """Create list item with error handling and optional Trakt.tv integration"""
    try:
        label = labelize(file)
        listitem = xbmcgui.ListItem(label=label)

        if 'img' in file and file['img']:
            listitem.setArt({'thumb': file['img']})

        listitem.setInfo('video', {'title': label})
        listitem.setProperty('IsPlayable', 'true')

        commands = []
        if 'ident' in file:
            commands.append(( _addon.getLocalizedString(30211), 'RunPlugin(' + get_url(action='info',ident=file['ident']) + ')'))
            commands.append(( _addon.getLocalizedString(30212), 'RunPlugin(' + get_url(action='download',ident=file['ident']) + ')'))

        # Přidej Trakt.tv kontextové menu pokud je k dispozici TMDB ID
        if tmdb_id and _addon.getSetting('trakt_enabled') == 'true':
            try:
                trakt = trakt_integration.get_trakt_instance(_addon)
                if trakt.is_authenticated():
                    commands.append(('Přidat do Trakt.tv watchlistu', f'RunPlugin({get_url(action="trakt_add_watchlist", tmdb_id=tmdb_id, media_type=media_type)})'))
                    commands.append(('Označit jako zhlédnuto na Trakt.tv', f'RunPlugin({get_url(action="trakt_mark_watched", tmdb_id=tmdb_id, media_type=media_type, ident=file.get("ident"))})'))
                    commands.append(('Zaznamenat pokrok na Trakt.tv', f'RunPlugin({get_url(action="trakt_record_progress", tmdb_id=tmdb_id, media_type=media_type, ident=file.get("ident"))})'))
            except Exception:
                pass  # Ticho ignoruj chyby s Trakt

        if addcommands:
            commands = commands + addcommands
        listitem.addContextMenuItems(commands)
        return listitem
    except Exception as e:
        logging.error(f'Error creating list item: {str(e)}')
        # Return basic listitem as fallback
        fallback_label = file.get('name', 'Error item')
        return xbmcgui.ListItem(label=fallback_label)

def ask(what):
    """Ask user for input with validation"""
    try:
        if what is None:
            what = ''
        kb = xbmc.Keyboard(what, _addon.getLocalizedString(30007))
        kb.doModal()
        if kb.isConfirmed():
            user_input = kb.getText().strip()
            logging.debug(f'User input: {user_input}')
            return user_input
        return None
    except Exception as e:
        logging.error(f'Error in user input dialog: {str(e)}')
        return None

def loadsearch():
    """Load search history with error handling"""
    history = []
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)

        history_file = os.path.join(_profile, SEARCH_HISTORY)
        if os.path.exists(history_file):
            with io.open(history_file, 'r', encoding='utf8') as file:
                fdata = file.read()
                try:
                    history = json.loads(fdata, "utf-8")
                except TypeError:
                    history = json.loads(fdata)

    except (IOError, json.JSONDecodeError) as e:
        logging.error(f'Error loading search history: {str(e)}')
    except Exception as e:
        logging.error(f'Unexpected error loading search history: {str(e)}')

    return history if isinstance(history, list) else []

def storesearch(what):
    """Store search term with error handling"""
    if not what or (isinstance(what, str) and not what.strip()):
        return

    try:
        size = int(_addon.getSetting('shistory'))
        history = loadsearch()

        # Pokud je předán dict (např. s tmdb_id), ukládej jako dict
        if isinstance(what, dict):
            entry = what
        else:
            entry = {'query': what}

        # Odstraň duplicity podle obsahu dictu nebo stringu
        history = [h for h in history if h != entry]
        history = [entry] + history

        if len(history) > size:
            history = history[:size]

        with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
            try:
                data = json.dumps(history).decode('utf8')
            except AttributeError:
                data = json.dumps(history)
            file.write(data)

        logging.debug(f'Stored search term: {entry}')

    except (IOError, ValueError) as e:
        logging.error(f'Error storing search history: {str(e)}')
    except Exception as e:
        logging.error(f'Unexpected error storing search: {str(e)}')

def removesearch(what):
    """Remove search term with error handling"""
    if not what:
        return

    try:
        history = loadsearch()
        if what in history:
            history.remove(what)
            with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(history).decode('utf8')
                except AttributeError:
                    data = json.dumps(history)
                file.write(data)
            logging.debug(f'Removed search term: {what}')

    except (IOError, ValueError) as e:
        logging.error(f'Error removing search history: {str(e)}')
    except Exception as e:
        logging.error(f'Unexpected error removing search: {str(e)}')

def _detect_episode_info(filename):
    """Try to detect season and episode numbers from filename using patterns"""
    try:
        if not filename:
            return None, None

        # Normalize the filename for better matching
        cleaned = unidecode.unidecode(filename).lower()

        # VYLEPŠENÉ VZORY: Pokrývají více formátů - použij vylepšené vzory místo starých
        enhanced_patterns = [
            r'[Ss](\d{1,2})[Ee](\d{1,2})',      # S01E01, S1E1, s01e01
            r'(\d+)x(\d+)',             # 1x01 format
            r'[Ee]pisode\s*(\d+)',      # Episode 1 format
            r'[Ee]p\s*(\d+)',           # Ep 1 format
            r'[Ee](\d+)',               # E1 format
            r'(\d+)\.\s*(\d+)'          # 1.01 format
        ]

        # Try each enhanced pattern
        for pattern in enhanced_patterns:
            match = re.search(pattern, cleaned)
            if match:
                groups = match.groups()
                if len(groups) == 2:  # Patterns like S01E02 or 1x02
                    season = int(groups[0])
                    episode = int(groups[1])
                    logging.debug(f'Episode detected: S{season}E{episode} from "{filename}" using pattern "{pattern}"')
                    return season, episode
                elif len(groups) == 1:  # Patterns like E02 or Episode 2
                    episode = int(groups[0])
                    logging.debug(f'Episode detected: S1E{episode} from "{filename}" using pattern "{pattern}"')
                    return 1, episode

        logging.debug(f'No episode pattern detected in "{filename}"')
        return None, None
    except Exception as e:
        logging.error(f'Error detecting episode info from {filename}: {str(e)}')
        return None, None

def parse_movie_title(title):
    """Zjednodušená verze - pouze základní varianty"""
    if not title:
        return [title]
    
    # Odstraň extra mezery
    title = re.sub(r'\s+', ' ', title.strip())
    variants = [title]  # Vždy začni s původním názvem
    
    # Základní varianty s &
    if '&' in title:
        variants.append(title.replace('&', ' a '))
        variants.append(title.replace('&', ' and '))
        variants.append(title.replace('&', ' '))
    
    # Základní varianty s :
    if ':' in title:
        main_title = title.split(':')[0].strip()
        variants.append(main_title)
    
    # Základní varianty s -
    elif ' - ' in title:
        main_title = title.split(' - ')[0].strip()
        variants.append(main_title)
    
    # Odstraň duplicity a zachovej pořadí
    seen = set()
    unique_variants = []
    for variant in variants:
        if variant and variant.strip() and variant not in seen:
            seen.add(variant)
            unique_variants.append(variant.strip())
    
    safe_log(f'Title variants for "{title}": {unique_variants}')
    return unique_variants

def dosearch(token, what, category, sort, limit, offset, action, explicit_series=False, tmdb_id=None, cz_title=None, original_title=None, year=None, season=None, episode=None, media_type='movie'):
    """Enhanced search function with better error handling and series detection"""
    try:
        if not token:
            logging.error('No valid token for search')
            popinfo('Chyba autentifikace', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)
            return

        # Vyčisti cache před vyhledáváním
        smart_cache_cleanup()

        # OPRAVENO: Pouze při explicitním hledání seriálů použij SeriesManager
        explicit_series_search = explicit_series or (action == 'series_search' or
                                 'series' in str(action).lower() or
                                 category == 'series')
        
        # NOVÁ LOGIKA: Detekuj, jestli uživatel hledá konkrétní epizodu
        user_searches_episode = False
        if what:
            episode_patterns = [
                r's\d+e\d+',           # S01E01
                r's\d+\s*e\d+',       # S01 E01  
                r'\d+x\d+',           # 1x01
                r'[Ee]pisode\s*\d+',   # Episode 1
                r'[Ee]p\s*\d+',       # Ep 1
                r'[Ee]\d+',           # E1
            ]
            what_lower = what.lower()
            for pattern in episode_patterns:
                if re.search(pattern, what_lower):
                    user_searches_episode = True
                    break

        logging.debug(f'Search: what="{what}", action="{action}", explicit_series={explicit_series}, user_searches_episode={user_searches_episode}, tmdb_id="{tmdb_id}", cz_title="{cz_title}", original_title="{original_title}", year="{year}"')

        
        if explicit_series_search or action == 'series_search':
            # POUZE pro explicitní hledání seriálů použij SeriesManager
            logging.debug('Using SeriesManager for series search')
            try:
                sm = series_manager.SeriesManager(_addon, _profile)
                series_data = sm.search_series(what, api, token)

                if series_data and series_data.get('seasons'):
                    progress = xbmcgui.DialogProgress()
                    progress.create('Tshare', f'Nalezen serial {what}...')
                    progress.close()

                    total_episodes = sum(len(season) for season in series_data["seasons"].values())
                    popinfo(f'Nalezeno {total_episodes} epizod v {len(series_data["seasons"])} sezonach')
                    xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=what)})')
                    xbmcplugin.endOfDirectory(_handle)
                    return

                # Pokud nejsou nalezeny žádné seriály
                popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(_handle)
                return

            except Exception as e:
                logging.error(f'Error in SeriesManager search: {str(e)}')
                traceback.print_exc()
                popinfo(f'Chyba při hledání seriálu: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(_handle)
                return

        # NOVÁ LOGIKA: Používej specializované moduly pro TMDB dotazy
        # Rozhodnutí: je to epizoda seriálu?
        is_episode_search = bool(season and episode and media_type == 'tv')
        
        if is_episode_search:
            # Specializované vyhledávání epizod
            logging.info(f'Using episode_search module for S{season}E{episode}')
            episode_search.search_episode(token, what, category, sort, limit, offset, 
                                        season, episode, tmdb_id, cz_title, original_title, year)
            return
        elif tmdb_id and (cz_title or original_title) and media_type == 'movie' and not user_searches_episode:
            # Specializované vyhledávání filmů s TMDB
            logging.info(f'Using movie_search module for "{cz_title or original_title}"')
            movie_search.search_movie(token, what, category, sort, limit, offset,
                                    tmdb_id, cz_title, original_title, year)
            return

        # Pokud není explicitní hledání seriálů, použij vylepšené vyhledávání
        if not explicit_series_search:
            found_files = {}
            search_strategies = []

            # Připrav názvy pro vyhledávání - použij předané TMDB parametry
            if cz_title or original_title:
                showname = cz_title or what
                originaltitle = original_title or what
                # year už máme předané
            else:
                # Parsing pro TMDB formát
                showname = None
                originaltitle = None
                
                tmdb_match = re.search(r'(.+?)\s+(\d{4})\s+cz\s+(.+)', what.strip(), re.IGNORECASE)
                if tmdb_match:
                    showname = tmdb_match.group(1).strip()
                    year = tmdb_match.group(2).strip()
                    originaltitle = tmdb_match.group(3).strip()
                    logging.debug(f'TMDB format - Czech: "{showname}", Year: "{year}", English: "{originaltitle}"')
                else:
                    year_match = re.search(r'(\d{4})', what)
                    if year_match:
                        year = year_match.group(1)
                        showname = what.replace(year, '').strip()
                    else:
                        showname = what.strip()
                    logging.debug(f'Fallback parsing - Name: "{showname}", Year: "{year}"')

            # Očistí názvy
            if showname:
                showname = re.sub(r'\s+', ' ', showname).strip()
            if originaltitle:
                originaltitle = re.sub(r'\s+', ' ', originaltitle).strip()

            # NOVÁ LOGIKA: Pro hledání epizod použij jednoduché vyhledávání
            if user_searches_episode:
                # Pro epizody hledej přímo bez složitých strategií
                search_strategies = [('episode_search', what)]
                logging.info(f'Episode search detected, using simple strategy for: {what}')
            elif tmdb_id and (cz_title or original_title):
                # TMDB strategie - VŽDY prohledej oba názvy
                if cz_title:
                    # České názvy - nejdřív přesné hledání
                    title_variants = parse_movie_title(cz_title)
                    
                    for variant in title_variants:
                        # Nejdřív český název s rokem (nejpřesnější)
                        if year:
                            search_strategies.append(('tmdb_czech_year', f'{variant} {year}'))
                        search_strategies.append(('tmdb_czech', variant))
                
                if original_title and original_title != cz_title:
                    # Anglické názvy - také přesné hledání
                    original_variants = parse_movie_title(original_title)
                    
                    for variant in original_variants:
                        # Anglický název s rokem
                        if year:
                            search_strategies.append(('tmdb_original_year', f'{variant} {year}'))
                        search_strategies.append(('tmdb_original', variant))
                
                # Teprve pak dodatečné české varianty pro oba názvy
                if cz_title:
                    title_variants = parse_movie_title(cz_title)
                    for variant in title_variants:
                        search_strategies.extend([
                            ('tmdb_czech_cz', f'{variant} cz'),
                            ('tmdb_czech_czdab', f'{variant} czdab')
                        ])
                
                if original_title and original_title != cz_title:
                    original_variants = parse_movie_title(original_title)
                    for variant in original_variants:
                        search_strategies.extend([
                            ('tmdb_original_cz', f'{variant} cz'),
                            ('tmdb_original_czdab', f'{variant} czdab')
                        ])
            else:
                # Standardní strategie pro obecné vyhledávání
                clean_what = showname or what.strip()
                what_variants = parse_movie_title(clean_what)
                
                for variant in what_variants:
                    # Nejdřív zkus přesný název s rokem
                    if year:
                        search_strategies.append(('direct_year', f'{variant} {year}'))
                    
                    # Pak základní název
                    search_strategies.append(('direct', variant))
                    
                    # Pak české vzory
                    search_strategies.extend([
                        ('direct_cz', f'{variant} cz'),
                        ('direct_czdab', f'{variant} czdab')
                    ])
            
            # Odfiltruj None strategie
            search_strategies = [(name, query) for name, query in search_strategies if query]

            # Postupné vyhledávání s využitím cache
            for strategy_name, query in search_strategies:
                if len(found_files) >= 25:  # Zvýšeno z 10 na 25 pro více výsledků
                    break
                    
                logging.info(f'Search strategy "{strategy_name}": {query}')
                
                # Zkus cache
                cached_results = get_cached_search(query, category, sort)
                if cached_results:
                    logging.debug(f'Using cached results for: {query}')
                    for ident, file_data in cached_results.items():
                        if ident not in found_files:
                            found_files[ident] = file_data
                    continue
                
                # API volání
                popinfo(f'Hledám: {query}', icon=xbmcgui.NOTIFICATION_INFO)
                cache_key = f'search_{hashlib.md5(query.encode()).hexdigest()}'
                response = cached_api_call('search', {
                    'what': query,
                    'category': category,
                    'sort': sort,
                    'limit': limit,
                    'offset': offset,
                    'wst': token,
                    'maybe_removed': 'true'
                }, cache_key)

                if response is None:
                    continue

                try:
                    xml = ET.fromstring(response.content)
                    if is_ok(xml):
                        new_results = {}
                        for file in xml.iter('file'):
                            try:
                                item = todict(file)
                                if 'ident' in item and item['ident'] not in found_files:
                                    # Zkontroluj relevanci výsledku - předej správný search_type
                                    filename = item.get('name', '')
                                    # OPRAVA: Předej info o hledání epizody
                                    effective_search_type = strategy_name
                                    if user_searches_episode:
                                        effective_search_type = 'episode_search'
                                    
                                    if is_relevant_result(filename, query, effective_search_type):
                                        found_files[item['ident']] = item
                                        new_results[item['ident']] = item
                                    else:
                                        safe_log(f'Skipping irrelevant result: {filename} for query: {query}')
                            except Exception as e:
                                logging.warning(f'Error processing search result: {str(e)}')
                                continue
                        
                        # Cache nové výsledky
                        if new_results:
                            cache_search_results(query, category, sort, new_results)
                            logging.debug(f'Found {len(new_results)} new results with {strategy_name}')
                            
                            # UPRAVENÉ: Poznamenej výsledky, ale neukončuj předčasně
                            if strategy_name.endswith('_year') and len(new_results) >= 1:
                                logging.info(f'Found good result ({len(new_results)}) from year-specific search')
                            
                            # NOVÁ LOGIKA: Ukončuj až po prohledání všech základních strategií
                            # Základní strategie jsou: tmdb_czech_year, tmdb_czech, tmdb_original_year, tmdb_original
                            basic_strategies = ['tmdb_czech_year', 'tmdb_czech', 'tmdb_original_year', 'tmdb_original', 'direct_year', 'direct']
                            current_strategy_index = next((i for i, (name, _) in enumerate(search_strategies) if name == strategy_name), -1)
                            
                            # Zjisti, které základní strategie už byly provedeny
                            completed_basic_strategies = set()
                            for i in range(current_strategy_index + 1):
                                if i < len(search_strategies):
                                    completed_strategy = search_strategies[i][0]
                                    if completed_strategy in basic_strategies:
                                        completed_basic_strategies.add(completed_strategy)
                            
                            # Pokud máme dost výsledků a dokončili jsme všechny hlavní strategie
                            if len(found_files) >= 15:
                                # Pro TMDB vyhledávání: počkej na české i anglické výsledky
                                if tmdb_id and (cz_title or original_title):
                                    has_czech = any(s.startswith('tmdb_czech') for s in completed_basic_strategies)
                                    has_original = any(s.startswith('tmdb_original') for s in completed_basic_strategies)
                                    
                                    # Pokud máme oba typy nebo jen jeden je dostupný
                                    should_stop = False
                                    if cz_title and original_title:
                                        should_stop = has_czech and has_original
                                    elif cz_title:
                                        should_stop = has_czech
                                    elif original_title:
                                        should_stop = has_original
                                    
                                    if should_stop:
                                        logging.info(f'Completed main TMDB strategies (Czech: {has_czech}, Original: {has_original}), stopping with {len(found_files)} results')
                                        break
                                else:
                                    # Pro běžné vyhledávání: pokud jsme dokončili direct strategie
                                    has_direct = any(s.startswith('direct') for s in completed_basic_strategies)
                                    if has_direct:
                                        logging.info(f'Completed main direct strategies, stopping with {len(found_files)} results')
                                        break
                            
                except ET.ParseError as e:
                    logging.error(f'XML parsing error in {strategy_name} search: {str(e)}')
                    continue

            # Inteligentní řazení výsledků (pouze pokud je povoleno)
            if found_files:
                smart_sorting_enabled = _addon.getSetting('smart_sorting') == 'true'
                
                # NOVÉ: vždy preferuj rok (pokud je v dotazu) – i když je chytré řazení vypnuté
                if year and str(year).isdigit():
                    found_files = sort_results_by_year_preference(found_files, int(year))
                    logging.info(f'Aplikováno řazení podle roku (priorita): {year}')
                
                if smart_sorting_enabled:
                    found_files = intelligent_sort_files(found_files, search_year=year)
                    logging.info(f'Applied smart sorting to {len(found_files)} files with year preference: {year}')
                else:
                    logging.info(f'Smart sorting disabled, using server order (po preferenci roku) for {len(found_files)} files')
                
                # Deduplikace pouze při velkém množství výsledků nebo vypnutém chytrém řazení
                files_list = list(found_files.values())
                should_deduplicate = len(files_list) > 15 or not smart_sorting_enabled  # Sníženo z 20 na 15
                
                if should_deduplicate:
                    unique_files_list = deduplicate_results(files_list)
                    # Převeď zpět na dict pro kompatibilitu
                    found_files = {item['ident']: item for item in unique_files_list if 'ident' in item}
                    reason = "many results" if len(files_list) > 15 else "smart sorting disabled"
                    logging.info(f'Applied deduplication ({reason}): {len(files_list)} -> {len(found_files)} files')
                else:
                    logging.info(f'Skipped deduplication for {len(files_list)} files (smart sorting enabled and reasonable count)')
                
                logging.info(f'Total found {len(found_files)} files, displaying results')
                
                # Display results
                clear_tmp_movies_history()
                tmp_history = []
                overview = None
                poster_path = None
                tmdb_data = None
                
                if tmdb_id:
                    tmdb_data = get_tmdb_details(tmdb_id, media_type=category if category else 'movie')
                    if tmdb_data:
                        overview = tmdb_data.get('overview')
                        poster_path = tmdb_data.get('poster_path')
                
                for ident, file_item in found_files.items():
                    try:
                        # Rozliš typ obsahu pro Trakt
                        file_media_type = 'movie'
                        season, episode = _detect_episode_info(file_item.get('name', ''))
                        if season and episode:
                            file_media_type = 'tv'
                            
                        listitem = tolistitem(file_item, tmdb_id=tmdb_id, media_type=file_media_type)
                        
                        # Vylepšené info pro listitem
                        if overview:
                            listitem.setInfo('video', {
                                'title': file_item.get('name', 'Unknown'),
                                'plot': overview,
                                'year': int(year) if year and year.isdigit() else None
                            })
                        
                        if poster_path:
                            poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}"
                            listitem.setArt({'poster': poster_url, 'thumb': poster_url})
                        
                        # Detekce seriálu
                        is_series = False
                        season, episode = _detect_episode_info(file_item.get('name', ''))
                        if season and episode:
                            is_series = True
                        
                        # Připrav metadata pro historii
                        meta_entry = {
                            'ident': ident,
                            'name': file_item.get('name', 'Unknown'),
                            'tmdb_id': tmdb_id,
                            'cz_title': cz_title,
                            'original_title': original_title,
                            'year': year,
                            'overview': overview,
                            'poster_path': poster_path
                        }
                        
                        # URL parametry
                        url_params = {
                            'action': 'play',
                            'ident': ident,
                            'name': file_item.get('name', 'Unknown'),
                            'tmdb_id': tmdb_id,
                            'cz_title': cz_title,
                            'year': year
                        }
                        
                        if is_series:
                            url_params.update({
                                'series_name': cz_title or original_title,
                                'season': season,
                                'episode': episode,
                                'episode_title': url_params['name']
                            })
                            meta_entry.update({
                                'series_name': url_params['series_name'],
                                'season': season,
                                'episode': episode,
                                'episode_title': url_params['episode_title']
                            })
                        
                        tmp_history.append(meta_entry)
                        xbmcplugin.addDirectoryItem(_handle, get_url(**url_params), listitem, False)
                        
                    except Exception as e:
                        logging.warning(f'Error adding item to directory: {str(e)}')
                        continue
                
                save_tmp_movies_history(tmp_history)
            else:
                logging.info(f'No results found for: {what}')
                popinfo('Nenalezeny žádné výsledky', icon=xbmcgui.NOTIFICATION_WARNING)
                
            xbmcplugin.endOfDirectory(_handle)
            return

    except Exception as e:
        logging.error(f'Unexpected error in dosearch: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def direct_search(params):
    """
    Zpracuje požadavek na přímé vyhledávání z externích zdrojů (jako je TMDB Helper).
    Přeskočí uživatelský vstup a menu historie vyhledávání.
    """

    try:
        # 1. Získej vyhledávací dotaz z parametrů URL
        what = params.get('what', None)
        
        # NOVÉ: Pokud what obsahuje číslo na konci (TMDB ID), extrahuj ho
        tmdb_id = params.get('tmdb_id') or params.get('id')
        if what and not tmdb_id:
            # Hledej vzor: "název rok číslo" nebo "název číslo"
            import re
            # Vzor pro "Superman 2025 1061474" nebo "Film název 123456"
            match = re.match(r'^(.+?)\s+(\d{4})?\s*(\d{6,})$', what.strip())
            if match:
                title_part = match.group(1).strip()
                year_part = match.group(2)
                id_part = match.group(3)
                
                logging.info(f'Extracted from what: title="{title_part}", year="{year_part}", id="{id_part}"')
                
                # Použij extrahované hodnoty
                what = title_part
                tmdb_id = id_part
                
                logging.info(f'Updated: what="{what}", tmdb_id="{tmdb_id}"')

        tmdb_type = params.get('tmdb_type', None)
        media_type = tmdb_type or params.get('media_type', 'movie')
        cz_title = None
        original_title = None
        year = None
        tmdb_data = None

        # Pokud je id/tmdb_id, vždy použij název z TMDB
        if tmdb_id:
            tmdb_data = get_tmdb_details(tmdb_id, media_type=media_type)
            if tmdb_data:
                # Ulož kompletní metadata do dočasného souboru
                save_tmp_metadata(tmdb_data)
                cz_title = tmdb_data.get('cz_title')
                original_title = tmdb_data.get('original_title')
                title = tmdb_data.get('title')
                name = tmdb_data.get('name')
                year = tmdb_data.get('year')
                # Preferuj český název, pak originální, pak title, pak name, pak showname z parametru
                what = cz_title or original_title or title or name or params.get('showname') or what
                logging.debug(f'TMDB API použito: cz_title={cz_title}, original_title={original_title}, title={title}, name={name}, year={year}')

        # Pokud není id, použij původní logiku s what
        if not what:
            logging.error("Přímé vyhledávání bylo voláno bez parametru 'what'.")
            popinfo('Chyba: Chybí název k vyhledání', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle)
            return

        # Dotaz na Webshare nikdy nesmí obsahovat id/tmdb_id
        # what = pouze název a rok
        if year and what:
            what = f"{what} {year}"

        # 2. Získej další parametry z nastavení nebo URL
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        # Bezpečné získání kategorie a řazení
        try:
            scategory_setting = _addon.getSetting('scategory')
            if scategory_setting.isdigit():
                category = params.get('category', CATEGORIES[int(scategory_setting)])
            else:
                # Pokud je text, najdi odpovídající index
                category_map = {'Vše': '', 'Video': 'video', 'Obrázky': 'images', 'Audio': 'audio', 'Archivy': 'archives', 'Dokumenty': 'docs', 'Adult': 'adult'}
                category = params.get('category', category_map.get(scategory_setting, 'video'))
        except (ValueError, IndexError):
            category = params.get('category', 'video')
        
        try:
            ssort_setting = _addon.getSetting('ssort')
            if ssort_setting.isdigit():
                sort = params.get('sort', SORTS[int(ssort_setting)])
            else:
                # Pokud je text, najdi odpovídající index
                sort_map = {'Výchozí': '', 'Nejnovější': 'recent', 'Hodnocení': 'rating', 'Největší': 'largest', 'Nejmenší': 'smallest'}
                sort = params.get('sort', sort_map.get(ssort_setting, ''))
        except (ValueError, IndexError):
            sort = params.get('sort', '')
            
        limit = int(params.get('limit', _addon.getSetting('slimit')))
        offset = int(params.get('offset', 0))

        # 3. Přímé volání hlavní logiky vyhledávání (dosearch)
        # Předej získané TMDB údaje, pokud jsou dostupné
        season = params.get('season')
        episode = params.get('episode')
        
        dosearch(token, what, category, sort, limit, offset, 'direct_search', 
                explicit_series=False, tmdb_id=tmdb_id, cz_title=cz_title, 
                original_title=original_title, year=year, season=season, 
                episode=episode, media_type=media_type)

    except Exception as e:
        logging.error(f'Chyba v direct_search: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při přímém vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search(params):
    """Main search function with parameter validation"""
    try:
        show_search_menu = params.get('show_search_menu')
        what = params.get('what', None)

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\ " + 'Vyhledávání')
        token = revalidate()

        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False

        if 'remove' in params:
            removesearch(params['remove'])
            updateListing = True

        if 'toqueue' in params:
            toqueue(params['toqueue'], token)
            updateListing = True

        if 'what' in params:
            what = params['what']

        if 'ask' in params and params['ask'] == '1' and 'query' not in params:
            if what is not None and what == NONE_WHAT:
                history = loadsearch()
                listitem = xbmcgui.ListItem(label='Nové hledání')
                listitem.setArt({'icon': 'DefaultAddSource.png'})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='search',ask=1), listitem, True)

                # Nová položka: Hledat bez filtrů
                listitem = xbmcgui.ListItem(label='Hledat bez filtrů')
                listitem.setArt({'icon': 'DefaultScript.png'})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='search_raw'), listitem, True)

                for search_item in history:
                    try:
                        listitem = xbmcgui.ListItem(label=str(search_item))
                        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
                        commands = []
                        commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search_item) + ')'))
                        listitem.addContextMenuItems(commands)
                        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=search_item), listitem, True)
                    except Exception as e:
                        logging.warning(f'Error adding history item {search_item}: {str(e)}')
                        continue

                xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)
                return

            what = ask(what)
            if what is not None:
                storesearch(what)
            else:
                updateListing = True

        if what is not None:
            if 'offset' not in params:
                _addon.setSetting('slast', what)
            else:
                _addon.setSetting('slast', NONE_WHAT)
                updateListing = True

            try:
                # Bezpečné získání kategorie a řazení
                scategory_setting = _addon.getSetting('scategory')
                if scategory_setting.isdigit():
                    category = params.get('category', CATEGORIES[int(scategory_setting)])
                else:
                    # Pokud je text, najdi odpovídající index
                    category_map = {'Vše': '', 'Video': 'video', 'Obrázky': 'images', 'Audio': 'audio', 'Archivy': 'archives', 'Dokumenty': 'docs', 'Adult': 'adult'}
                    category = params.get('category', category_map.get(scategory_setting, 'video'))
                
                ssort_setting = _addon.getSetting('ssort')
                if ssort_setting.isdigit():
                    sort = params.get('sort', SORTS[int(ssort_setting)])
                else:
                    # Pokud je text, najdi odpovídající index
                    sort_map = {'Výchozí': '', 'Nejnovější': 'recent', 'Hodnocení': 'rating', 'Největší': 'largest', 'Nejmenší': 'smallest'}
                    sort = params.get('sort', sort_map.get(ssort_setting, ''))
                
                limit = int(params.get('limit', _addon.getSetting('slimit')))
                offset = int(params.get('offset', 0))
            except (ValueError, IndexError) as e:
                logging.error(f'Error parsing search parameters: {str(e)}')
                # Use defaults
                category = 'video'
                sort = ''
                limit = 50
                offset = 0

            # Přidání možnosti filtrování
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30216))
            listitem.setArt({'icon': 'DefaultFilter.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search_filter', what=what, category=category, sort=sort, limit=limit, offset=offset), listitem, True)

            dosearch(token, what, category, sort, limit, offset, 'search', 
                    explicit_series=False, tmdb_id=None, cz_title=None, 
                    original_title=None, year=None, season=None, episode=None, media_type='movie')
        else:
            _addon.setSetting('slast', NONE_WHAT)
            history = loadsearch()
            listitem = xbmcgui.ListItem(label='Nové hledání')
            listitem.setArt({'icon': 'DefaultAddSource.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',ask=1), listitem, True)

            # Přidej možnost hledat bez filtrů i v hlavním menu
            listitem = xbmcgui.ListItem(label='Hledat bez filtrů')
            listitem.setArt({'icon': 'DefaultScript.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search_raw'), listitem, True)

            for search_item in history:
                try:
                    # Pokud je search_item dict s tmdb_id, použij název
                    if isinstance(search_item, dict):
                        label = search_item.get('cz_title') or search_item.get('original_title') or search_item.get('query') or str(search_item)
                        url_params = {k: v for k, v in search_item.items() if k in ['tmdb_id', 'cz_title', 'original_title', 'year', 'query']}
                        # query použij jako fallback pro what
                        url_params['what'] = search_item.get('query', label)
                    else:
                        label = str(search_item)
                        url_params = {'what': search_item}
                    listitem = xbmcgui.ListItem(label=label)
                    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
                    commands = []
                    commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search_item) + ')'))
                    listitem.addContextMenuItems(commands)
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='search', **url_params), listitem, True)
                except Exception as e:
                    logging.warning(f'Error adding history item {search_item}: {str(e)}')
                    continue

        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in search: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_raw(params):
    """Čisté vyhledávání bez jakýchkoli filtrů a heuristik."""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return
        # Zeptej se na dotaz
        what = ask('')
        if not what:
            xbmcplugin.endOfDirectory(_handle)
            return
        # Ulož do historie
        storesearch(what)
        # Parametry
        category = ''  # Prázdná kategorie = všechno
        sort = ''      # Prázdné řazení = výchozí
        limit = int(_addon.getSetting('slimit'))
        offset = 0
        # Proveď prosté vyhledávání
        popinfo(f'Hledám: {what}', icon=xbmcgui.NOTIFICATION_INFO)
        cache_key = f'search_{hashlib.md5(what.encode()).hexdigest()}'
        response = cached_api_call('search', {
            'what': what,
            'category': category,
            'sort': sort,
            'limit': limit,
            'offset': offset,
            'wst': token,
            'maybe_removed': 'true'
        }, cache_key)
        if response is None:
            xbmcplugin.endOfDirectory(_handle)
            return
        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                for file in xml.iter('file'):
                    try:
                        item = todict(file)
                        listitem = tolistitem(item)
                        xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item.get('name', 'Unknown')), listitem, False)
                    except Exception as e:
                        logging.warning(f'Error adding item: {str(e)}')
                        continue
            else:
                popinfo('Nenalezeny žádné výsledky', icon=xbmcgui.NOTIFICATION_WARNING)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in search_raw: {str(e)}')
            popinfo('Chyba při zpracování výsledků', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)
    except Exception as e:
        logging.error(f'Chyba v search_raw: {str(e)}')
        popinfo('Neočekávaná chyba při vyhledávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_filter(params):
    """Search filter menu with validation"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ Filtry")

        what = params.get('what', None)
        category = params.get('category', CATEGORIES[0])
        sort = params.get('sort', SORTS[0])
        limit = params.get('limit', _addon.getSetting('slimit'))
        offset = params.get('offset', 0)

        # Menu pro kategorie
        listitem_category = xbmcgui.ListItem(label='Kategorie: ' + (category if category else 'Vše'))
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search_category_menu', what=what, sort=sort, limit=limit, offset=offset), listitem_category, True)

        # Menu pro řazení
        listitem_sort = xbmcgui.ListItem(label='Řazení: ' + (sort if sort else 'Výchozí'))
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search_sort_menu', what=what, category=category, limit=limit, offset=offset), listitem_sort, True)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Error in search_filter: {str(e)}')
        popinfo('Chyba při zobrazení filtrů', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_category_menu(params):
    """Category selection menu with validation"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ Filtry \\\\ Kategorie")

        what = params.get('what', None)
        sort = params.get('sort', SORTS[0])
        limit = params.get('limit', _addon.getSetting('slimit'))
        offset = params.get('offset', 0)

        categories = ['Vše'] + [c.capitalize() for c in CATEGORIES if c]
        for cat in categories:
            category_value = '' if cat == 'Vše' else cat.lower()
            listitem = xbmcgui.ListItem(label=cat)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=what, category=category_value, sort=sort, limit=limit, offset=offset), listitem, True)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Error in search_category_menu: {str(e)}')
        popinfo('Chyba při zobrazení kategorií', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def search_sort_menu(params):
    """Sort selection menu with validation"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\ Filtry \\ Řazení")
        what = params.get('what', None)
        category = params.get('category', CATEGORIES[0])
        limit = params.get('limit', _addon.getSetting('slimit'))
        offset = params.get('offset', 0)

        sorts = ['Výchozí','Nejnovější','Hodnocení','Největší','Nejmenší']
        sort_values = [''] + SORTS[1:]

        for i, sort_label in enumerate(sorts):
            listitem = xbmcgui.ListItem(label=sort_label)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search', what=what, category=category, sort=sort_values[i], limit=limit, offset=offset), listitem, True)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Error in search_sort_menu: {str(e)}')
        popinfo('Chyba při zobrazení řazení', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def queue(params):
    """Queue management with enhanced error handling"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + 'Fronta ke stažení')
        token = revalidate()

        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False

        if 'dequeue' in params:
            response = api('dequeue_file',{'ident':params['dequeue'],'wst':token})
            if response is None:
                xbmcplugin.endOfDirectory(_handle)
                return

            try:
                xml = ET.fromstring(response.content)
                if is_ok(xml):
                    popinfo(_addon.getLocalizedString(30106))
                else:
                    popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                updateListing = True
            except ET.ParseError as e:
                logging.error(f'XML parsing error in dequeue: {str(e)}')
                popinfo('Chyba při odebírání ze fronty', icon=xbmcgui.NOTIFICATION_ERROR)

        response = api('queue',{'wst':token})
        if response is None:
            xbmcplugin.endOfDirectory(_handle)
            return

        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                for file in xml.iter('file'):
                    try:
                        item = todict(file)
                        if 'ident' in item:
                            commands = []
                            commands.append(( _addon.getLocalizedString(30215), 'Container.Update(' + get_url(action='queue',dequeue=item['ident']) + ')'))
                            listitem = tolistitem(item, commands)
                            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item.get('name', 'Unknown')), listitem, False)
                    except Exception as e:
                        logging.warning(f'Error processing queue item: {str(e)}')
                        continue
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in queue: {str(e)}')
            popinfo('Chyba při načítání fronty', icon=xbmcgui.NOTIFICATION_ERROR)

        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in queue: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba ve frontě', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def toqueue(ident, token):
    """Add to queue with error handling"""
    try:
        if not ident or not token:
            logging.error('Missing ident or token for queue operation')
            popinfo('Chyba při přidávání do fronty', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        response = api('queue_file',{'ident':ident,'wst':token})
        if response is None:
            return

        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                popinfo(_addon.getLocalizedString(30105))
                logging.info(f'Successfully queued file: {ident}')
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                logging.warning(f'Failed to queue file: {ident}')
        except ET.ParseError as e:
            logging.error(f'XML parsing error in toqueue: {str(e)}')
            popinfo('Chyba při přidávání do fronty', icon=xbmcgui.NOTIFICATION_ERROR)

    except Exception as e:
        logging.error(f'Unexpected error in toqueue: {str(e)}')
        popinfo('Neočekávaná chyba při přidávání do fronty', icon=xbmcgui.NOTIFICATION_ERROR)

def history(params):
    """History management with enhanced error handling"""
    try:
        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\ " + 'Historie stahování')
        token = revalidate()

        if not token:
            xbmcplugin.endOfDirectory(_handle)
            return

        updateListing = False

        if 'remove' in params:
            remove = params['remove']
            updateListing = True

            response = api('history',{'wst':token})
            if response is None:
                xbmcplugin.endOfDirectory(_handle)
                return

            try:
                xml = ET.fromstring(response.content)
                ids = []
                if is_ok(xml):
                    for file in xml.iter('file'):
                        ident_elem = file.find('ident')
                        download_id_elem = file.find('download_id')
                        if ident_elem is not None and download_id_elem is not None:
                            if remove == ident_elem.text:
                                ids.append(download_id_elem.text)
                else:
                    popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)

                if ids:
                    rr = api('clear_history',{'ids[]':ids,'wst':token})
                    if rr is not None:
                        try:
                            xml = ET.fromstring(rr.content)
                            if is_ok(xml):
                                popinfo(_addon.getLocalizedString(30104))
                            else:
                                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                        except ET.ParseError as e:
                            logging.error(f'XML parsing error in clear_history: {str(e)}')

            except ET.ParseError as e:
                logging.error(f'XML parsing error in history removal: {str(e)}')
                popinfo('Chyba při odebírání z historie', icon=xbmcgui.NOTIFICATION_ERROR)

        if 'toqueue' in params:
            toqueue(params['toqueue'], token)
            updateListing = True

        response = api('history',{'wst':token})
        if response is None:
            xbmcplugin.endOfDirectory(_handle)
            return

        try:
            xml = ET.fromstring(response.content)
            files = []
            if is_ok(xml):
                for file in xml.iter('file'):
                    try:
                        item = todict(file, ['ended_at', 'download_id', 'started_at'])
                        if item and item not in files:
                            files.append(item)
                    except Exception as e:
                        logging.warning(f'Error processing history item: {str(e)}')
                        continue

                for file in files:
                    try:
                        if 'ident' in file:
                            commands = []
                            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='history',remove=file['ident']) + ')'))
                            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='history',toqueue=file['ident']) + ')'))
                            listitem = tolistitem(file, commands)
                            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=file['ident'],name=file.get('name', 'Unknown')), listitem, False)
                    except Exception as e:
                        logging.warning(f'Error adding history item to directory: {str(e)}')
                        continue
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        except ET.ParseError as e:
            logging.error(f'XML parsing error in history: {str(e)}')
            popinfo('Chyba při načítání historie', icon=xbmcgui.NOTIFICATION_ERROR)

        xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

    except Exception as e:
        logging.error(f'Unexpected error in history: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba v historii', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def settings(params):
    """Open settings"""
    try:
        _addon.openSettings()
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
    except Exception as e:
        logging.error(f'Error opening settings: {str(e)}')

def getinfo(ident, wst):
    """Get file info with enhanced error handling"""
    try:
        if not ident or not wst:
            logging.error('Missing ident or token for getinfo')
            return None

        # Try with cache first
        cache_key = f'info_{ident}'
        response = cached_api_call('file_info', {'ident':ident,'wst': wst}, cache_key)

        if response is None:
            return None

        try:
            xml = ET.fromstring(response.content)
            ok = is_ok(xml)

            if not ok:
                # Try with maybe_removed flag
                response = api('file_info',{'ident':ident,'wst': wst, 'maybe_removed':'true'})
                if response is None:
                    return None
                xml = ET.fromstring(response.content)
                ok = is_ok(xml)

            if ok:
                return xml
            else:
                logging.warning(f'File info not found for ident: {ident}')
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                return None

        except ET.ParseError as e:
            logging.error(f'XML parsing error in getinfo: {str(e)}')
            popinfo('Chyba při zpracování informací o souboru', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

    except Exception as e:
        logging.error(f'Unexpected error in getinfo: {str(e)}')
        traceback.print_exc()
        return None

def getlink(ident, wst, dtype='video_stream'):
    """Get download link with enhanced error handling"""
    try:
        if not ident or not wst:
            logging.error('Missing ident or token for getlink')
            return None

        # UUID experiment
        duuid = _addon.getSetting('duuid')
        if not duuid:
            duuid = str(uuid.uuid4())
            _addon.setSetting('duuid', duuid)

        data = {'ident':ident,'wst': wst,'download_type':dtype,'device_uuid':duuid}

        response = api('file_link', data)
        if response is None:
            return None

        try:
            xml = ET.fromstring(response.content)
            if is_ok(xml):
                link_elem = xml.find('link')
                if link_elem is not None:
                    link = link_elem.text
                    logging.debug(f'Successfully got link for ident: {ident}')
                    return link
                else:
                    logging.error('Link element not found in response')
                    return None
            else:
                logging.warning(f'Failed to get link for ident: {ident}')
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
                return None
        except ET.ParseError as e:
            logging.error(f'XML parsing error in getlink: {str(e)}')
            popinfo('Chyba při získávání odkazu', icon=xbmcgui.NOTIFICATION_ERROR)
            return None

    except Exception as e:
        logging.error(f'Unexpected error in getlink: {str(e)}')
        traceback.print_exc()
        return None

def play(params):
    """Play file with robust error handling"""
    try:
        # Validate required parameters
        valid, error_msg = validate_params(params, ['ident', 'name'])
        if not valid:
            logging.error(f'Invalid play parameters: {error_msg}')
            popinfo('Chyba při spouštění - chybí parametry', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return

        token = revalidate()
        if not token:
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return

        link = getlink(params['ident'], token)
        if link is not None:
            # Headers experiment
            headers = _session.headers.copy()
            if headers:
                headers.update({'Cookie':'wst='+token})
                link = link + '|' + urlencode(headers)

            listitem = xbmcgui.ListItem(label=params['name'], path=link)
            listitem.setProperty('mimetype', 'application/octet-stream')
            logging.info(f'Successfully playing: {params["name"]}')
            xbmcplugin.setResolvedUrl(_handle, True, listitem)
            
            # --- TRAKT.TV SCROBBLING ---
            try:
                if _addon.getSetting('trakt_enabled') == 'true':
                    tmdb_id = params.get('tmdb_id') or params.get('id')
                    series_name = params.get('series_name')
                    season = params.get('season')
                    episode = params.get('episode')
                    content_name = params.get('name', 'Neznámý obsah')
                    
                    # Debug info
                    xbmc.log(f'Trakt: Attempting scrobble for "{content_name}", TMDB ID: {tmdb_id}, Series: {series_name}, S{season}E{episode}', xbmc.LOGINFO)
                    
                    if tmdb_id:
                        if series_name and season and episode:
                            # Seriál
                            xbmc.log(f'Trakt: Starting TV scrobble for {series_name} S{season}E{episode}', xbmc.LOGINFO)
                            trakt_scrobble_start(tmdb_id, 'tv', season, episode)
                            xbmc.executebuiltin(f'RunPlugin({get_url(action="trakt_scrobble_stop_delayed", tmdb_id=tmdb_id, media_type="tv", season=season, episode=episode)})')
                        else:
                            # Film
                            xbmc.log(f'Trakt: Starting movie scrobble for {content_name}', xbmc.LOGINFO)
                            trakt_scrobble_start(tmdb_id, 'movie')
                            xbmc.executebuiltin(f'RunPlugin({get_url(action="trakt_scrobble_stop_delayed", tmdb_id=tmdb_id, media_type="movie")})')
                    else:
                        xbmc.log(f'Trakt: No TMDB ID available for "{content_name}" - skipping scrobble', xbmc.LOGWARNING)
                else:
                    xbmc.log('Trakt: Integration disabled', xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f'Trakt scrobbling failed: {str(e)}', xbmc.LOGERROR)
                import traceback
                traceback.print_exc()
            # --- KONEC TRAKT.TV ---

            # --- HISTORIE ---
            try:
                # Převod všech hodnot 'None' (string) na None
                clean_params = {k: (None if v == 'None' else v) for k, v in params.items()}
                # Pokud jsou parametry pro seriál (series_name, season, episode), ulož do historie seriálů
                series_name = clean_params.get('series_name')
                season = clean_params.get('season')
                episode = clean_params.get('episode')
                episode_title = clean_params.get('episode_title') or clean_params.get('name')
                if series_name and season and episode:
                    sm = series_manager.SeriesManager(_addon, _profile)
                    sm.add_to_history(
                        str(series_name), str(season), str(episode), str(episode_title),
                        year=clean_params.get('year'),
                        plot=clean_params.get('plot') or clean_params.get('overview'),
                        poster=clean_params.get('poster') or clean_params.get('poster_path'),
                        tmdb_id=clean_params.get('tmdb_id') or clean_params.get('id'),
                        stream_url=link
                    )
                else:
                    # Najdi odpovídající záznam v dočasné historii podle ident
                    tmp_history = load_tmp_movies_history()
                    found = None
                    for entry in tmp_history:
                        if entry.get('ident') == clean_params.get('ident'):
                            found = entry
                            break
                    if found:
                        # Načti kompletní metadata z movies_metadata_tmp.json
                        meta = load_tmp_metadata() or {}
                        # Doplň ident, název a url vybraného streamu
                        meta = dict(meta)
                        meta['ident'] = clean_params.get('ident')
                        meta['name'] = clean_params.get('name')
                        meta['stream_url'] = link
                        meta['timestamp'] = int(time.time())
                        add_movie_to_history(meta)
                        # Odstraň záznam z tmp historie a ulož zpět
                        tmp_history = [e for e in tmp_history if e.get('ident') != clean_params.get('ident')]
                        save_tmp_movies_history(tmp_history)
                        clear_tmp_metadata()
                    else:
                        # Pokud není v tmp, ulož vše co je v parametrech
                        entry = dict(clean_params)
                        entry['stream_url'] = link
                        entry['timestamp'] = int(time.time())
                        add_movie_to_history(entry)
            except Exception as e:
                logging.warning(f'Nepodařilo se uložit do historie přehrávání: {str(e)}')
            # --- KONEC HISTORIE ---

        else:
            logging.error(f'Failed to get link for: {params["name"]}')
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

    except Exception as e:
        logging.error(f'Unexpected error in play: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při spouštění', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def download(params):
    """Download file with comprehensive error handling"""
    try:
        # Validate parameters
        valid, error_msg = validate_params(params, ['ident'])
        if not valid:
            logging.error(f'Invalid download parameters: {error_msg}')
            popinfo('Chyba při stahování - chybí parametry', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        token = revalidate()
        if not token:
            return

        where = _addon.getSetting('dfolder')
        if not where or not xbmcvfs.exists(where):
            popinfo('Nastavte složku pro stahování!', sound=True)
            _addon.openSettings()
            return

        local = os.path.exists(where)
        normalize = 'true' == _addon.getSetting('dnormalize')
        notify = 'true' == _addon.getSetting('dnotify')

        try:
            every = int(re.sub(r'[^\d]+', '', _addon.getSetting('dnevery')))
        except:
            every = 10

        # Get download link and file info
        link = getlink(params['ident'], token, 'file_download')
        if not link:
            return

        info_xml = getinfo(params['ident'], token)
        if not info_xml:
            return

        name_elem = info_xml.find('name')
        if name_elem is None:
            logging.error('File name not found in info response')
            popinfo('Nepodařilo se získat název souboru', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        name = name_elem.text
        if normalize:
            name = unidecode.unidecode(name)

        # Open file for writing
        try:
            if local:
                bf = io.open(os.path.join(where, name), 'wb')
            else:
                bf = xbmcvfs.File(os.path.join(where, name), 'w')
        except IOError as e:
            logging.error(f'Cannot open file for writing: {str(e)}')
            popinfo(f'Nepodařilo se otevřít soubor pro zápis: {name}', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        try:
            response = _session.get(link, stream=True)
            response.raise_for_status()

            total = response.headers.get('content-length')
            if total is None:
                popinfo(_addon.getLocalizedString(30301) + name, icon=xbmcgui.NOTIFICATION_WARNING, sound=True)
                bf.write(response.content)
            elif not notify:
                popinfo(_addon.getLocalizedString(30302) + name)
                bf.write(response.content)
            else:
                popinfo(_addon.getLocalizedString(30302) + name)
                dl = 0
                total = int(total)
                pct = max(total / 100, 1)  # Avoid division by zero
                lastpop = 0

                for data in response.iter_content(chunk_size=4096):
                    dl += len(data)
                    bf.write(data)
                    done = int(dl / pct)
                    if done % every == 0 and lastpop != done and done <= 100:
                        popinfo(str(done) + '% - ' + name)
                        lastpop = done

            bf.close()
            logging.info(f'Successfully downloaded: {name}')
            popinfo(_addon.getLocalizedString(30303) + name, sound=True)

        except requests.RequestException as e:
            bf.close()
            logging.error(f'Download failed for {name}: {str(e)}')
            popinfo(f'Chyba při stahování: {name}', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            # TODO: Remove unfinished file

    except Exception as e:
        logging.error(f'Unexpected error in download: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při stahování', icon=xbmcgui.NOTIFICATION_ERROR)

def menu():
    """Main menu with error handling"""
    try:
        token = revalidate()
        if not token:
            # Still show menu even if login fails
            pass

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))

        listitem = xbmcgui.ListItem(label='Vyhledávání')
        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search', show_search_menu='true'), listitem, True)

        listitem = xbmcgui.ListItem(label='Historie stahování')
        listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='history'), listitem, True)

        # Add Series Manager menu item
        listitem = xbmcgui.ListItem(label='Seriály')
        listitem.setArt({'icon': 'DefaultTVShows.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='series'), listitem, True)

        # Add Playback History menu item
        listitem = xbmcgui.ListItem(label='Historie přehrávání')
        listitem.setArt({'icon': 'DefaultMovies.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='playback_history'), listitem, True)

        # Add Trakt.tv menu item if enabled
        if _addon.getSetting('trakt_enabled') == 'true':
            try:
                trakt = trakt_integration.get_trakt_instance(_addon)
                if trakt.is_authenticated():
                    listitem = xbmcgui.ListItem(label='Trakt.tv Watchlist')
                    listitem.setArt({'icon': 'DefaultFavourites.png'})
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='trakt_watchlist'), listitem, True)
                    
                    # Sync offline queue if available
                    listitem = xbmcgui.ListItem(label='Trakt.tv Sync')
                    listitem.setArt({'icon': 'DefaultAddonRepository.png'})
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='trakt_sync_offline'), listitem, False)
            except Exception:
                pass  # Ticho ignoruj chyby s Trakt



        listitem = xbmcgui.ListItem(label='Nastavení')
        listitem.setArt({'icon': 'DefaultAddonService.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='settings'), listitem, False)

        xbmcplugin.endOfDirectory(_handle)

    except Exception as e:
        logging.error(f'Unexpected error in menu: {str(e)}')
        traceback.print_exc()
        # Still try to show basic menu
        xbmcplugin.endOfDirectory(_handle)

def series_menu(params):
    """Handle Series functionality with error handling"""
    try:
        sm = series_manager.SeriesManager(_addon, _profile)
        series_manager.create_series_menu(sm, _handle)
    except Exception as e:
        logging.error(f'Error in series_menu: {str(e)}')
        popinfo('Chyba při zobrazení seriálů', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def series_search(params):
    """Search for a TV series with enhanced error handling"""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        series_name_param = params.get('series_name', None)
        originaltitle = params.get('originaltitle')
        year = params.get('year')

        if not series_name_param:
            user_input = ask(None)
            if not user_input:
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return
            series_name_param = user_input

        sm = series_manager.SeriesManager(_addon, _profile)

        progress = xbmcgui.DialogProgress()
        progress.create('Tshare', f'Vyhledavam serial {series_name_param}...')

        try:
            series_data = sm.search_series(series_name_param, api, token, originaltitle=originaltitle)

            if not series_data or not series_data.get('seasons'):
                progress.close()
                popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return

            progress.close()
            total_episodes = sum(len(season) for season in series_data["seasons"].values())
            popinfo(f'Nalezeno {total_episodes} epizod v {len(series_data["seasons"])} sezonach')

            xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name_param)})')

        except Exception as e:
            progress.close()
            logging.error(f'Error in series search: {str(e)}')
            traceback.print_exc()
            popinfo(f'Chyba při hledání seriálu: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)

    except Exception as e:
        logging.error(f'Unexpected error in series_search: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při hledání seriálu', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def series_detail(params):
    """Show seasons for a series with error handling"""
    try:
        series_name = params.get('series_name')
        originaltitle = params.get('originaltitle')  # od TMDB Helper
        year = params.get('year')  # od TMDB Helper
        
        if not series_name:
            logging.error('Missing series_name in series_detail')
            xbmcplugin.endOfDirectory(_handle)
            return

        if _addon.getSetting('debug_enabled') == 'true':
            xbmc.log(f'Series detail: series_name="{series_name}", originaltitle="{originaltitle}", year="{year}"', xbmc.LOGINFO)

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + series_name)

        sm = series_manager.SeriesManager(_addon, _profile)
        # Zkus načíst cache
        cached = sm.load_series_cache(series_name)
        if cached:
            # Zkontroluj kvalitu cache
            seasons_count = len(cached.get('seasons', {}))
            episodes_count = sum(len(season) for season in cached.get('seasons', {}).values())
            
            # OPRAVENO: Používej cache bez zbytečného druhého hledání
            if _addon.getSetting('debug_enabled') == 'true':
                xbmc.log(f'Cache kontrola pro {series_name}: {seasons_count} sezón, {episodes_count} epizod', xbmc.LOGINFO)
                xbmc.log(f'Použita cache pro seriál: {series_name} ({seasons_count} sezón, {episodes_count} epizod)', xbmc.LOGINFO)
            series_manager.create_seasons_menu_from_data(sm, _handle, series_name, cached)
            return
        
        # Pokud není cache nebo potřebujeme refresh, pokračuj s novým vyhledáváním
        series_manager.create_seasons_menu(sm, _handle, series_name, originaltitle=originaltitle)

    except Exception as e:
        logging.error(f'Error in series_detail: {str(e)}')
        popinfo('Chyba při zobrazení seriálu', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def series_season(params):
    """Show episodes for a season with error handling"""
    try:
        valid, error_msg = validate_params(params, ['series_name', 'season'])
        if not valid:
            logging.error(f'Invalid series_season parameters: {error_msg}')
            xbmcplugin.endOfDirectory(_handle)
            return

        series_name = params['series_name']
        season = params['season']

        xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \\\\ " + series_name + " \\\\ " + f"Rada {season}")

        sm = series_manager.SeriesManager(_addon, _profile)
        series_manager.create_episodes_menu(sm, _handle, series_name, season)

    except Exception as e:
        logging.error(f'Error in series_season: {str(e)}')
        popinfo('Chyba při zobrazení sezóny', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def series_refresh(params):
    """Refresh series data with error handling"""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        series_name = params.get('series_name')
        if not series_name:
            logging.error('Missing series_name in series_refresh')
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        sm = series_manager.SeriesManager(_addon, _profile)

        progress = xbmcgui.DialogProgress()
        progress.create('Tshare', f'Aktualizuji data pro serial {series_name}...')

        try:
            series_data = sm.search_series(series_name, api, token)

            if not series_data or not series_data.get('seasons'):
                progress.close()
                popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return

            progress.close()
            total_episodes = sum(len(season) for season in series_data["seasons"].values())
            popinfo(f'Aktualizovano: {total_episodes} epizod v {len(series_data["seasons"])} sezonach')

            xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name)})')

        except Exception as e:
            progress.close()
            logging.error(f'Error refreshing series: {str(e)}')
            traceback.print_exc()
            popinfo(f'Chyba při aktualizaci: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)

    except Exception as e:
        logging.error(f'Unexpected error in series_refresh: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při aktualizaci', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def series_refresh_season(params):
    """Refresh specific season data with error handling"""
    try:
        token = revalidate()
        if not token:
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        series_name = params.get('series_name')
        season = params.get('season')
        if not series_name or not season:
            logging.error('Missing series_name or season in series_refresh_season')
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return

        sm = series_manager.SeriesManager(_addon, _profile)

        progress = xbmcgui.DialogProgress()
        progress.create('Tshare', f'Aktualizuji řadu {season} pro {series_name}...')

        try:
            # Aktualizuj celý seriál (SeriesManager nemá specifickou funkci pro jednu sezónu)
            series_data = sm.search_series(series_name, api, token)

            if not series_data or not series_data.get('seasons'):
                progress.close()
                popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return

            progress.close()
            
            # Spočítej epizody v aktualizované sezóně
            season_episodes = len(series_data['seasons'].get(str(season), {}))
            popinfo(f'Aktualizovano: {season_episodes} epizod v řadě {season}')

            # Přesměruj zpět na sezónu
            xbmc.executebuiltin(f'Container.Update({get_url(action="series_season", series_name=series_name, season=season)})')

        except Exception as e:
            progress.close()
            logging.error(f'Error refreshing season: {str(e)}')
            traceback.print_exc()
            popinfo(f'Chyba při aktualizaci řady: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)

    except Exception as e:
        logging.error(f'Unexpected error in series_refresh_season: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při aktualizaci řady', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def info(params):
    """Show file info with simplified formatting"""
    try:
        valid, error_msg = validate_params(params, ['ident'])
        if not valid:
            logging.error(f'Invalid info parameters: {error_msg}')
            popinfo('Chyba při zobrazení informací', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        token = revalidate()
        if not token:
            return

        ident = params['ident']
        xml = getinfo(ident, token)

        if xml is not None:
            try:
                file = todict(xml)
                dialog = xbmcgui.Dialog()

                # Zjednodušené formátování
                info_parts = []
                if file.get('name'): 
                    info_parts.append(f"Název: {file['name']}")
                if file.get('size'): 
                    info_parts.append(f"Velikost: {sizelize(file['size'])}")
                if file.get('type'): 
                    info_parts.append(f"Typ: {file['type']}")
                if file.get('positive_votes'): 
                    info_parts.append(f"Pozitivní hlasy: {file['positive_votes']}")
                if file.get('negative_votes'): 
                    info_parts.append(f"Negativní hlasy: {file['negative_votes']}")
                if file.get('video_quality'): 
                    info_parts.append(f"Kvalita videa: {file['video_quality']}")
                if file.get('video_format'): 
                    info_parts.append(f"Formát videa: {file['video_format']}")
                if file.get('fps'): 
                    info_parts.append(f"FPS: {file['fps']}")
                if file.get('audio_format'): 
                    info_parts.append(f"Audio formát: {file['audio_format']}")
                if file.get('audio_channels'): 
                    info_parts.append(f"Audio kanály: {file['audio_channels']}")
                if file.get('audio_lang'): 
                    info_parts.append(f"Jazyk: {file['audio_lang']}")
                if file.get('subtitles_lang'): 
                    info_parts.append(f"Titulky: {file['subtitles_lang']}")
                if file.get('duration'): 
                    info_parts.append(f"Délka: {file['duration']} minut")

                dialog.textviewer(labelize(file), '\n'.join(info_parts))

            except Exception as e:
                logging.error(f'Error displaying file info: {str(e)}')
                popinfo('Chyba při zobrazení informací o souboru', icon=xbmcgui.NOTIFICATION_ERROR)

    except Exception as e:
        logging.error(f'Unexpected error in info: {str(e)}')
        traceback.print_exc()
        popinfo('Neočekávaná chyba při zobrazení informací', icon=xbmcgui.NOTIFICATION_ERROR)

def select_stream(params):
    """Dialog pro výběr alternativního streamu"""
    try:
        token = revalidate()
        if not token:
            return
            
        series_name = params['series_name']
        season = params['season']
        episode = params['episode']
        
        sm = series_manager.SeriesManager(_addon, _profile)
        streams = sm.get_streams_for_episode(series_name, season, episode)
        
        if not streams:
            popinfo('Žádné streamy nejsou k dispozici', icon=xbmcgui.NOTIFICATION_WARNING)
            return
            
        # Vytvoř seznam možností pro dialog
        options = []
        for stream in streams:
            size = sizelize(stream.get('size')) if stream.get('size') else '?'
            options.append(f"{stream['name']} ({size})")
            
        # Zobraz dialog pro výběr
        dialog = xbmcgui.Dialog()
        choice = dialog.select('Vyberte stream', options)
        
        if choice >= 0:
            # Uživatel vybral stream
            selected_stream = streams[choice]
            
            # Zeptej se, jestli chce aplikovat na všechny díly
            apply_all = dialog.yesno('Změna streamu', 
                                   'Chcete použít tento typ streamu pro všechny díly seriálu?',
                                   'Pouze tento díl',
                                   'Všechny díly')
            
            progress = xbmcgui.DialogProgress()
            progress.create('Tshare', 'Aktualizuji data seriálu...')
            
            if apply_all:
                # Nastav preferovaný vzor pro celý seriál a aktualizuj data
                sm.set_preferred_pattern(series_name, selected_stream['name'], api, token)
                popinfo('Preferovaný stream byl nastaven pro celý seriál')
            else:
                # Nastav pouze pro konkrétní epizodu
                sm.set_episode_stream(series_name, season, episode, selected_stream['name'])
                popinfo('Preferovaný stream byl nastaven pro tento díl')
            
            progress.close()
            # Obnov zobrazení pouze refresh
            xbmc.executebuiltin('Container.Refresh')
            
    except Exception as e:
        logging.error(f'Error in select_stream: {str(e)}')
        popinfo('Chyba při výběru streamu', icon=xbmcgui.NOTIFICATION_ERROR)

def restore_smart_ordering(params):
    """Obnoví chytré řazení streamů"""
    try:
        series_name = params.get('series_name')
        if not series_name:
            return
            
        sm = series_manager.SeriesManager(_addon, _profile)
        sm.disable_force_pattern(series_name)
        xbmc.executebuiltin('Container.Refresh')
        popinfo('Chytré řazení bylo obnoveno')
        
    except Exception as e:
        logging.error(f'Error restoring smart ordering: {str(e)}')
        popinfo('Chyba při obnovení chytrého řazení', icon=xbmcgui.NOTIFICATION_ERROR)

def search_missing_episodes(params):
    """Vyhledá chybějící díly seriálu"""
    try:
        series_name = params.get('series_name')
        season = params.get('season')  # Nový parametr pro konkrétní sezónu
        if not series_name:
            popinfo('Chybí název seriálu', icon=xbmcgui.NOTIFICATION_ERROR)
            return
            
        token = revalidate()
        if not token:
            return
            
        sm = series_manager.SeriesManager(_addon, _profile)
        
        # Zobraz progress dialog
        if season:
            progress = xbmcgui.DialogProgress()
            progress.create('Tshare', f'Hledám chybějící díly řady {season} pro {series_name}...')
        else:
            progress = xbmcgui.DialogProgress()
            progress.create('Tshare', f'Hledám chybějící díly pro {series_name}...')
        
        try:
            # Najdi chybějící díly
            all_missing = sm.find_missing_episodes(series_name)
            
            # Pokud je zadána konkrétní sezóna, filtruj jen tu
            if season:
                season_int = int(season)
                missing_episodes = [ep for ep in all_missing if ep[0] == season_int]
            else:
                missing_episodes = all_missing
            
            if not missing_episodes:
                progress.close()
                if season:
                    popinfo(f'V řadě {season} nechybí žádné díly', icon=xbmcgui.NOTIFICATION_INFO)
                else:
                    popinfo('Nechybí žádné díly', icon=xbmcgui.NOTIFICATION_INFO)
                return
            
            # Spusť hledání chybějících dílů
            added_count = sm.search_missing_episodes(series_name, api, token, missing_episodes)
            
            progress.close()
            
            if added_count and added_count > 0:
                if season:
                    popinfo(f'Nalezeno a přidáno {added_count} chybějících dílů v řadě {season}!', icon=xbmcgui.NOTIFICATION_INFO)
                    # Přesměruj zpět na sezónu
                    xbmc.executebuiltin(f'Container.Update({get_url(action="series_season", series_name=series_name, season=season)})')
                else:
                    popinfo(f'Nalezeno a přidáno {added_count} chybějících dílů!', icon=xbmcgui.NOTIFICATION_INFO)
                    # Přesměruj zpět na seriál
                    xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name)})')
            else:
                if season:
                    popinfo(f'Žádné chybějící díly v řadě {season} nebyly nalezeny', icon=xbmcgui.NOTIFICATION_WARNING)
                else:
                    popinfo('Žádné chybějící díly nebyly nalezeny', icon=xbmcgui.NOTIFICATION_WARNING)
            
        except Exception as e:
            progress.close()
            logging.error(f'Error searching missing episodes: {str(e)}')
            popinfo(f'Chyba při hledání chybějících dílů: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
            
    except Exception as e:
        logging.error(f'Unexpected error in search_missing_episodes: {str(e)}')
        popinfo('Neočekávaná chyba při hledání chybějících dílů', icon=xbmcgui.NOTIFICATION_ERROR)

def install_tmdb_config():
    """Ručně nainstaluje TMDB Helper player konfiguraci"""
    try:
        from main import install_tmdb_player_config
        success = install_tmdb_player_config()
        
        if success:
            popinfo('TMDB Helper player konfigurace nainstalovana!', icon=xbmcgui.NOTIFICATION_INFO)
        else:
            popinfo('Nepodarilo se nainstalovat player konfiguraci.', icon=xbmcgui.NOTIFICATION_ERROR)
            
    except Exception as e:
        logging.error(f'Error in install_tmdb_config: {str(e)}')
        popinfo(f'Chyba pri instalaci: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)

def delete_series_action(params):
    """Obsluha mazání seriálu s potvrzením"""
    try:
        series_name = params.get('series_name')
        if not series_name:
            popinfo('Chybí název seriálu', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        # Zobraz potvrzovací dialog
        dialog = xbmcgui.Dialog()
        if dialog.yesno('Odstranit seriál', f'Opravdu chcete odstranit seriál "{series_name}"?\n\nTato akce je nevratná!'):
            # Smaž seriál
            sm = series_manager.SeriesManager(_addon, _profile)
            if sm.delete_series(series_name):
                popinfo(f'Seriál "{series_name}" byl odstraněn', icon=xbmcgui.NOTIFICATION_INFO, time=3000)
                # Refresh obsahu
                xbmc.executebuiltin('Container.Refresh')
            else:
                popinfo('Chyba při mazání seriálu', icon=xbmcgui.NOTIFICATION_ERROR, time=3000)

    except Exception as e:
        logging.error(f'Error in delete_series_action: {str(e)}')
        popinfo('Chyba při mazání seriálu', icon=xbmcgui.NOTIFICATION_ERROR, time=3000)

def delete_movie_history_action(params):
    """Obsluha mazání filmu z historie přehrávání"""
    try:
        movie_id = params.get('movie_id')
        movie_title = params.get('movie_title', 'film')
        
        # OPRAVA: movie_id může být string "None" z URL
        if movie_id == 'None' or not movie_id:
            movie_id = None
        
        # Zobraz potvrzovací dialog
        dialog = xbmcgui.Dialog()
        if dialog.yesno('Odstranit z historie', f'Odstranit "{movie_title}" z historie přehrávání?'):
            # Načti historii
            history = load_movies_history()
            original_count = len(history)
            
            # LADĚNÍ: Loguj co máme v historii
            logging.info(f'Movie history has {original_count} entries')
            for i, entry in enumerate(history):
                logging.info(f'Entry {i}: tmdb_id={entry.get("tmdb_id")}, cz_title={entry.get("cz_title")}, title={entry.get("title")}')
            
            # OPRAVENÁ LOGIKA: Mazání podle indexu z parametru nebo kompletní shody
            history_index = params.get('history_index')
            if history_index is not None:
                # Maž podle indexu (nejspolehlivější)
                try:
                    index = int(history_index)
                    if 0 <= index < len(history):
                        removed_entry = history.pop(index)
                        logging.info(f'Removed entry by index {index}: {removed_entry}')
                    else:
                        popinfo('Neplatný index v historii', icon=xbmcgui.NOTIFICATION_WARNING)
                        return
                except (ValueError, TypeError):
                    popinfo('Chybný index', icon=xbmcgui.NOTIFICATION_ERROR)
                    return
            else:
                # Maž podle údajů (méně spolehlivé)
                new_history = []
                removed = False
                
                for entry in history:
                    should_remove = False
                    
                    # Zkus různé kombinace pro odstranění
                    if movie_id and entry.get('tmdb_id') == movie_id:
                        should_remove = True
                        logging.info(f'Removing by tmdb_id: {movie_id}')
                    elif movie_title and movie_title != 'Neznámý film':
                        # Porovnej s různými názvy
                        entry_titles = [
                            entry.get('cz_title', ''),
                            entry.get('title', ''),
                            entry.get('name', ''),
                            entry.get('original_title', '')
                        ]
                        for title in entry_titles:
                            if title and title.strip():
                                # Vytvoř label stejně jako v zobrazení
                                entry_label = title
                                if entry.get('year'):
                                    entry_label = f"{title} ({entry['year']})"
                                
                                if entry_label == movie_title or title == movie_title:
                                    should_remove = True
                                    logging.info(f'Removing by title match: "{title}" == "{movie_title}"')
                                    break
                    
                    if should_remove and not removed:
                        removed = True  # Odstraň pouze první shodu
                        logging.info(f'Removed entry: {entry}')
                    else:
                        new_history.append(entry)
            
            if len(history) < original_count:
                save_movies_history(history)
                popinfo(f'"{movie_title}" byl odstraněn z historie', icon=xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin('Container.Refresh')
                logging.info(f'Movie history updated: {original_count} -> {len(history)} entries')
            else:
                logging.warning(f'No matching entry found for removal: movie_id={movie_id}, movie_title={movie_title}')
                popinfo('Film nebyl v historii nalezen', icon=xbmcgui.NOTIFICATION_WARNING)

    except Exception as e:
        logging.error(f'Error in delete_movie_history_action: {str(e)}')
        import traceback
        traceback.print_exc()
        popinfo('Chyba při mazání z historie', icon=xbmcgui.NOTIFICATION_ERROR)

def delete_series_history_action(params):
    """Obsluha mazání seriálu z historie přehrávání"""
    try:
        history_index = params.get('history_index')
        series_label = params.get('series_label', 'epizodu')
        
        # Zobraz potvrzovací dialog
        dialog = xbmcgui.Dialog()
        if dialog.yesno('Odstranit z historie', f'Odstranit "{series_label}" z historie přehrávání?'):
            # Použij SeriesManager pro mazání z historie
            sm = series_manager.SeriesManager(_addon, _profile)
            history = sm.get_series_history()
            original_count = len(history)
            
            # OPRAVENO: Maž podle indexu
            if history_index is not None:
                try:
                    index = int(history_index)
                    if 0 <= index < len(history):
                        removed_entry = history.pop(index)
                        sm.save_history(history)
                        popinfo(f'"{series_label}" byl odstraněn z historie', icon=xbmcgui.NOTIFICATION_INFO, time=3000)
                        xbmc.executebuiltin('Container.Refresh')
                        logging.info(f'Removed series history entry by index {index}: {removed_entry}')
                    else:
                        popinfo('Neplatný index v historii', icon=xbmcgui.NOTIFICATION_WARNING)
                except (ValueError, TypeError):
                    popinfo('Chybný index', icon=xbmcgui.NOTIFICATION_ERROR)
            else:
                # Fallback - původní logika (pokud by někde chyběl index)
                series_name = params.get('series_name')
                season = params.get('season')
                episode = params.get('episode')
                
                if series_name and season and episode:
                    history = [entry for entry in history if not (
                        entry.get('series_name') == series_name and 
                        entry.get('season') == str(season) and 
                        entry.get('episode') == str(episode)
                    )]
                    
                    if len(history) < original_count:
                        sm.save_history(history)
                        popinfo(f'"{series_label}" byl odstraněn z historie', icon=xbmcgui.NOTIFICATION_INFO, time=3000)
                        xbmc.executebuiltin('Container.Refresh')
                    else:
                        popinfo('Epizoda nebyla v historii nalezena', icon=xbmcgui.NOTIFICATION_WARNING)
                else:
                    popinfo('Chybí parametry pro mazání z historie', icon=xbmcgui.NOTIFICATION_ERROR)

    except Exception as e:
        logging.error(f'Error in delete_series_history_action: {str(e)}')
        import traceback
        traceback.print_exc()
        popinfo('Chyba při mazání z historie', icon=xbmcgui.NOTIFICATION_ERROR)

# Main router with comprehensive error handling

def router(paramstring):
    """Main router with comprehensive error handling"""

    try:
        # Debug info pouze pokud je povoleno
        if _addon.getSetting('debug_enabled') == 'true':
            xbmc.log('Tshare ROUTER START', xbmc.LOGINFO)
            xbmc.log(f'Raw paramstring: {paramstring}', xbmc.LOGINFO)
        
        # OPRAVA: Speciální handling pro parametr 'what' s ampersandem
        params = {}
        if 'what=' in paramstring:
            # Najdi pozici what parametru
            what_pos = paramstring.find('what=')
            what_start = what_pos + 5
            
            # Hledej další platný parametr (& následovaný známým parametrem)
            valid_params = ['action', 'tmdb_id', 'id', 'tmdb_type', 'media_type', 'category', 'sort', 'limit', 'offset']
            what_end = len(paramstring)  # Default na konec
            
            # Hledej nejbližší platný parametr za what=
            for param in valid_params:
                param_pos = paramstring.find(f'&{param}=', what_start)
                if param_pos != -1 and param_pos < what_end:
                    what_end = param_pos
            
            what_value = paramstring[what_start:what_end]
            # URL decode what hodnotu
            try:
                from urllib.parse import unquote
            except ImportError:
                from urllib import unquote
            what_value = unquote(what_value)
            params['what'] = what_value
            
            # Vytvoř nový paramstring bez what parametru
            before_what = paramstring[:what_pos]
            after_what = paramstring[what_end:]
            
            # Odstraň what= část a spoj zbytek
            if before_what and not before_what.endswith('&'):
                before_what += '&'
            remaining = before_what + after_what.lstrip('&')
            remaining = remaining.strip('&')  # Odstraň & na začátku a konci
            
            if remaining:
                params.update(dict(parse_qsl(remaining, keep_blank_values=True)))
        else:
            # Normální parsing pokud není what
            params = dict(parse_qsl(paramstring, keep_blank_values=True))
        
        if _addon.getSetting('debug_enabled') == 'true':
            xbmc.log(f'Tshare ROUTER PARAMS: {params}', xbmc.LOGINFO)
            xbmc.log(f'Router called with params: {params}', xbmc.LOGINFO)

        if params:
            action = params.get('action', None)

            # OPRAVENO: Pokud action chybí ale máme 'what', předpokládej search
            if not action and 'what' in params:
                action = 'search'
                params['action'] = 'search'
                logging.info(f'Missing action parameter, defaulting to search with what="{params["what"]}"')

            # Log the action being performed  
            if _addon.getSetting('debug_enabled') == 'true':
                xbmc.log(f'Performing action: {action}', xbmc.LOGINFO)

            # Route to appropriate function
            if action == 'series_detail' and 'series_name' not in params:
                xbmc.log('series_detail called without series_name', xbmc.LOGWARNING)
                xbmcplugin.endOfDirectory(_handle)
                return
            # OPRAVA: POUŽÍVAT direct_search
            elif action == 'direct_search':
                direct_search(params)
            elif action == 'search_raw':
                search_raw(params)
            elif action == 'search':
                search(params)
            elif action == 'search_filter':
                search_filter(params)
            elif action == 'search_category_menu':
                search_category_menu(params)
            elif action == 'search_sort_menu':
                search_sort_menu(params)
            elif action == 'queue':
                queue(params)
            elif action == 'history':
                history(params)
            elif action == 'settings':
                settings(params)
            elif action == 'info':
                info(params)
            elif action == 'play':
                play(params)
            elif action == 'download':
                download(params)
            # Series Manager actions
            elif action == 'series':
                series_menu(params)
            elif action == 'series_search':
                series_search(params)
            elif action == 'series_detail':
                series_detail(params)
            elif action == 'series_season':
                series_season(params)
            elif action == 'series_refresh':
                series_refresh(params)
            elif action == 'series_refresh_season':
                series_refresh_season(params)
            elif action == 'select_stream':
                select_stream(params)
            elif action == 'restore_smart_ordering':
                restore_smart_ordering(params)
            elif action == 'search_missing_episodes':
                search_missing_episodes(params)
            elif action == 'playback_history':
                show_playback_history()
            elif action == 'series_history':
                sm = series_manager.SeriesManager(_addon, _profile)
                series_manager.create_series_history_menu(sm, _handle)
            elif action == 'play_series_history':
                play_series_history(params)
            elif action == 'movies_history':
                show_movies_history()
            elif action == 'play_movie_history':
                play_movie_history(params)
            elif action == 'test_tmdb_api':
                test_tmdb_api()
            elif action == 'install_tmdb_config':
                install_tmdb_config()
            elif action == 'delete_series':
                delete_series_action(params)
            elif action == 'delete_movie_history':
                delete_movie_history_action(params)
            elif action == 'delete_series_history':
                delete_series_history_action(params)
            # Trakt.tv actions
            elif action == 'trakt_login':
                trakt_login()
            elif action == 'trakt_logout':
                trakt_logout()
            elif action == 'trakt_add_watchlist':
                trakt_add_watchlist(params)
            elif action == 'trakt_remove_watchlist':
                trakt_remove_watchlist(params)
            elif action == 'trakt_watchlist':
                trakt_show_watchlist(params)
            elif action == 'trakt_sync_offline':
                trakt_sync_offline()
            elif action == 'trakt_test_connection':
                trakt_test_connection()
            elif action == 'trakt_scrobble_stop_delayed':
                trakt_scrobble_stop_delayed(params)
            elif action == 'trakt_mark_watched':
                trakt_mark_watched(params)
            elif action == 'trakt_record_progress':
                trakt_record_progress(params)
            elif action is None:
                logging.debug('No action specified, showing main menu')
                menu()
            else:
                logging.warning(f'Unknown action: {action}')
                menu()
        else:
            logging.debug('No parameters, showing main menu')
            menu()

    except Exception as e:
        logging.error(f'Critical error in router: {str(e)}')
        traceback.print_exc()
        popinfo('Kritická chyba aplikace', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        # Try to show main menu as fallback
        try:
            menu()
        except:
            xbmcplugin.endOfDirectory(_handle)

# ===== TRAKT.TV FUNCTIONS =====

def trakt_login():
    """Přihlášení k Trakt.tv"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        
        # Klíče jsou již nastavené, pokračujeme s přihlášením
        
        if trakt.authenticate():
            xbmcgui.Dialog().notification('Trakt.tv', 'Úspěšně přihlášen!', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('Trakt.tv', 'Přihlášení se nezdařilo', xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        xbmc.log(f'Trakt login error: {str(e)}', xbmc.LOGERROR)
        
        # Pokud chyba obsahuje 403, nabídni pomoc
        if '403' in str(e):
            dialog = xbmcgui.Dialog()
            if dialog.yesno('Trakt.tv Chyba 403', 
                           'Chyba 403 znamená neplatné API klíče.\n\n'
                           'Chcete zobrazit instrukce pro nastavení vlastních klíčů?'):
                instructions = (
                    'Chyba 403 - Řešení:\n\n'
                    '1. Demo klíče nefungují pro skutečné připojení\n'
                    '2. Potřebujete si zaregistrovat vlastní aplikaci\n'
                    '3. Jděte na: https://trakt.tv/oauth/applications\n'
                    '4. Vytvořte aplikaci s názvem "Tshare Kodi Addon"\n'
                    '5. Redirect URI: urn:ietf:wg:oauth:2.0:oob\n'
                    '6. Zkopírujte Client ID a Secret do nastavení addonu\n'
                    '7. Zkuste přihlášení znovu\n\n'
                    'Je to jednorázová akce, trvá 2-3 minuty.'
                )
                dialog.textviewer('Trakt.tv - Řešení chyby 403', instructions)
        else:
            xbmcgui.Dialog().notification('Trakt.tv', f'Chyba: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

def trakt_logout():
    """Odhlášení z Trakt.tv"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        trakt.logout()
    except Exception as e:
        xbmc.log(f'Trakt logout error: {str(e)}', xbmc.LOGERROR)

def trakt_add_watchlist(params):
    """Přidá položku do Trakt.tv watchlistu"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if not trakt.is_enabled() or not trakt.is_authenticated():
            xbmcgui.Dialog().notification('Trakt.tv', 'Není přihlášen', xbmcgui.NOTIFICATION_WARNING)
            return
            
        tmdb_id = params.get('tmdb_id')
        media_type = params.get('media_type', 'movie')
        
        if tmdb_id:
            if trakt.add_to_watchlist(tmdb_id, media_type):
                xbmcgui.Dialog().notification('Trakt.tv', 'Přidáno do watchlistu', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('Trakt.tv', 'Chyba při přidávání', xbmcgui.NOTIFICATION_ERROR)
        else:
            xbmcgui.Dialog().notification('Trakt.tv', 'Chybí TMDB ID', xbmcgui.NOTIFICATION_WARNING)
            
    except Exception as e:
        xbmc.log(f'Trakt add watchlist error: {str(e)}', xbmc.LOGERROR)

def trakt_remove_watchlist(params):
    """Odebere položku z Trakt.tv watchlistu"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if not trakt.is_enabled() or not trakt.is_authenticated():
            return
            
        tmdb_id = params.get('tmdb_id')
        media_type = params.get('media_type', 'movie')
        
        if tmdb_id:
            if trakt.remove_from_watchlist(tmdb_id, media_type):
                xbmcgui.Dialog().notification('Trakt.tv', 'Odebráno z watchlistu', xbmcgui.NOTIFICATION_INFO)
                
    except Exception as e:
        xbmc.log(f'Trakt remove watchlist error: {str(e)}', xbmc.LOGERROR)

def trakt_show_watchlist(params):
    """Zobrazí Trakt.tv watchlist"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if not trakt.is_enabled() or not trakt.is_authenticated():
            xbmcgui.Dialog().notification('Trakt.tv', 'Není přihlášen', xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(_handle)
            return
            
        media_type = params.get('type', 'all')  # all, movies, shows
        watchlist = trakt.get_watchlist(media_type)
        
        if not watchlist:
            xbmcgui.Dialog().notification('Trakt.tv', 'Prázdný watchlist', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(_handle)
            return
            
        for item in watchlist:
            try:
                if 'movie' in item:
                    movie = item['movie']
                    title = movie.get('title', 'Unknown')
                    year = movie.get('year', '')
                    tmdb_id = movie['ids'].get('tmdb')
                    
                    listitem = xbmcgui.ListItem(f"{title} ({year})")
                    listitem.setInfo('video', {
                        'title': title,
                        'year': year,
                        'mediatype': 'movie'
                    })
                    
                    # URL pro vyhledání filmu
                    url = get_url(action='direct_search', what=f"{title} {year}", tmdb_id=tmdb_id, tmdb_type='movie')
                    
                elif 'show' in item:
                    show = item['show']
                    title = show.get('title', 'Unknown')
                    year = show.get('year', '')
                    tmdb_id = show['ids'].get('tmdb')
                    
                    listitem = xbmcgui.ListItem(f"{title} ({year})")
                    listitem.setInfo('video', {
                        'title': title,
                        'year': year,
                        'mediatype': 'tvshow'
                    })
                    
                    # URL pro vyhledání seriálu
                    url = get_url(action='series_search', series_name=title, tmdb_id=tmdb_id)
                
                else:
                    continue
                    
                # Kontextové menu pro odebrání
                context_menu = [
                    ('Odebrat z watchlistu', f'RunPlugin({get_url(action="trakt_remove_watchlist", tmdb_id=tmdb_id, media_type="movie" if "movie" in item else "tv")})')
                ]
                listitem.addContextMenuItems(context_menu)
                
                xbmcplugin.addDirectoryItem(_handle, url, listitem, True)
                
            except Exception as e:
                xbmc.log(f'Error processing watchlist item: {str(e)}', xbmc.LOGWARNING)
                continue
                
        xbmcplugin.endOfDirectory(_handle)
        
    except Exception as e:
        xbmc.log(f'Trakt show watchlist error: {str(e)}', xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(_handle)

def trakt_sync_offline():
    """Synchronizuje offline frontu s Trakt.tv"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if trakt.is_enabled() and trakt.is_authenticated():
            trakt.process_sync_queue()
            xbmcgui.Dialog().notification('Trakt.tv', 'Offline sync dokončen', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('Trakt.tv', 'Není dostupné', xbmcgui.NOTIFICATION_WARNING)
    except Exception as e:
        xbmc.log(f'Trakt sync offline error: {str(e)}', xbmc.LOGERROR)

def trakt_test_connection():
    """Testuje připojení k Trakt.tv API"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        
        # Test základního API připojení bez autentifikace
        import requests  # type: ignore
        
        dialog = xbmcgui.DialogProgress()
        dialog.create('Trakt.tv Test', 'Testuji připojení k API...')
        
        # Test 1: Základní API dostupnost
        try:
            response = requests.get('https://api.trakt.tv', timeout=10)
            if response.status_code == 200:
                dialog.update(25, 'API dostupné ✓')
            else:
                dialog.update(25, f'API nedostupné: HTTP {response.status_code}')
        except Exception as e:
            dialog.update(25, f'API nedostupné: {str(e)}')
        
        xbmc.sleep(1000)
        
        # Test 2: Client ID validace
        dialog.update(50, 'Testuji Client ID...')
        
        device_url = 'https://api.trakt.tv/oauth/device/code'
        device_data = {'client_id': trakt.CLIENT_ID}
        
        try:
            response = requests.post(device_url, json=device_data, timeout=10)
            if response.status_code == 200:
                dialog.update(75, 'Client ID platné ✓')
                result_msg = 'Trakt.tv API test ÚSPĚŠNÝ!\n\nMůžete se pokusit o přihlášení.'
                result_type = xbmcgui.NOTIFICATION_INFO
            elif response.status_code == 403:
                dialog.update(75, 'Client ID neplatné ✗')
                result_msg = 'Chyba 403: Neplatné Client ID/Secret\n\nZkontrolujte nastavení v kategorii Trakt.tv'
                result_type = xbmcgui.NOTIFICATION_ERROR
            else:
                dialog.update(75, f'Chyba HTTP {response.status_code}')
                result_msg = f'HTTP chyba {response.status_code}\n\n{response.text[:100]}'
                result_type = xbmcgui.NOTIFICATION_WARNING
        except Exception as e:
            dialog.update(75, f'Chyba sítě: {str(e)}')
            result_msg = f'Síťová chyba: {str(e)}'
            result_type = xbmcgui.NOTIFICATION_ERROR
        
        xbmc.sleep(1000)
        dialog.update(100, 'Test dokončen')
        xbmc.sleep(1000)
        dialog.close()
        
        # Zobraz výsledek
        xbmcgui.Dialog().notification('Trakt.tv Test', result_msg, result_type, 5000)
        
        # Podrobné info v dialogu
        xbmcgui.Dialog().textviewer('Trakt.tv Test Výsledek', 
            f'Client ID: {trakt.CLIENT_ID[:20]}...\n'
            f'API Base: {trakt.API_BASE}\n'
            f'Enabled: {trakt.is_enabled()}\n'
            f'Authenticated: {trakt.is_authenticated()}\n\n'
            f'{result_msg}')
        
    except Exception as e:
        xbmc.log(f'Trakt test connection error: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Trakt.tv Test', f'Test error: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

def trakt_scrobble_start(tmdb_id, media_type, season=None, episode=None):
    """Začne Trakt scrobbling pro přehrávání"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if trakt.is_enabled() and trakt.is_authenticated() and _addon.getSetting('trakt_scrobble') == 'true':
            trakt.scrobble_start(tmdb_id, media_type, 0.0, season, episode)
    except Exception as e:
        xbmc.log(f'Trakt scrobble start error: {str(e)}', xbmc.LOGWARNING)

def trakt_scrobble_stop(tmdb_id, media_type, progress=100.0, season=None, episode=None):
    """Ukončí Trakt scrobbling"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if trakt.is_enabled() and trakt.is_authenticated() and _addon.getSetting('trakt_scrobble') == 'true':
            trakt.scrobble_stop(tmdb_id, media_type, progress, season, episode)
    except Exception as e:
        xbmc.log(f'Trakt scrobble stop error: {str(e)}', xbmc.LOGWARNING)

def trakt_scrobble_stop_delayed(params):
    """Ukončí scrobbling po delay - zaznamenává realistický pokrok"""
    try:
        import threading
        
        def delayed_stop():
            # Nejdřív počkej 10 sekund - pokud uživatel hned vypne, zaznamená se malý pokrok
            time.sleep(10)
            
            tmdb_id = params.get('tmdb_id')
            media_type = params.get('media_type', 'movie')
            season = params.get('season')
            episode = params.get('episode')
            
            if tmdb_id:
                # Zaznamenaej malý pokrok (10%) - tím se zobrazí v "Continue Watching"
                trakt_scrobble_stop(tmdb_id, media_type, 10.0, season, episode)
                xbmc.log(f'Trakt: Recorded 10% progress for initial viewing', xbmc.LOGINFO)
                
                # Pak čekej dalších 20 sekund a pokud stále běží, předpokládej delší sledování
                time.sleep(20)
                
                # Zkontroluj jestli Kodi stále přehrává
                player = xbmc.Player()
                if player.isPlaying():
                    # Stále přehrává po 30 sekundách - zaznamená 50%
                    trakt_scrobble_stop(tmdb_id, media_type, 50.0, season, episode)
                    xbmc.log(f'Trakt: Recorded 50% progress for continued viewing', xbmc.LOGINFO)
                    
                    # Počkej dalších 30 sekund pro úplné dokončení
                    time.sleep(30)
                    if player.isPlaying():
                        # Přehrává více než minutu - považuj za zhlédnuto
                        trakt_scrobble_stop(tmdb_id, media_type, 85.0, season, episode)
                        xbmc.log(f'Trakt: Marked as watched (85%) for extended viewing', xbmc.LOGINFO)
        
        # Spusť v separátním vlákně
        thread = threading.Thread(target=delayed_stop)
        thread.daemon = True
        thread.start()
        
    except Exception as e:
        xbmc.log(f'Trakt delayed scrobble stop error: {str(e)}', xbmc.LOGWARNING)

def trakt_mark_watched(params):
    """Manuálně označí obsah jako zhlédnutý na Trakt.tv"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if not trakt.is_enabled() or not trakt.is_authenticated():
            xbmcgui.Dialog().notification('Trakt.tv', 'Není přihlášen', xbmcgui.NOTIFICATION_WARNING)
            return
            
        tmdb_id = params.get('tmdb_id')
        media_type = params.get('media_type', 'movie')
        
        if not tmdb_id:
            xbmcgui.Dialog().notification('Trakt.tv', 'Chybí TMDB ID', xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Označí jako 100% zhlédnuto
        if trakt.scrobble_stop(tmdb_id, media_type, 100.0, 
                              params.get('season'), params.get('episode')):
            xbmcgui.Dialog().notification('Trakt.tv', 'Označeno jako zhlédnuto ✓', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('Trakt.tv', 'Chyba při označování', xbmcgui.NOTIFICATION_ERROR)
            
    except Exception as e:
        xbmc.log(f'Trakt mark watched error: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Trakt.tv', f'Chyba: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

def trakt_record_progress(params):
    """Zaznamenává pokrok ve sledování na Trakt.tv"""
    try:
        trakt = trakt_integration.get_trakt_instance(_addon)
        if not trakt.is_enabled() or not trakt.is_authenticated():
            xbmcgui.Dialog().notification('Trakt.tv', 'Není přihlášen', xbmcgui.NOTIFICATION_WARNING)
            return
            
        tmdb_id = params.get('tmdb_id')
        media_type = params.get('media_type', 'movie')
        
        if not tmdb_id:
            xbmcgui.Dialog().notification('Trakt.tv', 'Chybí TMDB ID', xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Nabídni uživateli možnost vybrat pokrok
        dialog = xbmcgui.Dialog()
        progress_options = [
            '10% - Jen jsem začal(a)',
            '25% - Čtvrtina',
            '50% - Polovina', 
            '75% - Skoro dokončeno',
            '90% - Téměř u konce'
        ]
        
        choice = dialog.select('Vyberte pokrok sledování:', progress_options)
        if choice == -1:  # Zrušeno
            return
            
        progress_values = [10.0, 25.0, 50.0, 75.0, 90.0]
        progress = progress_values[choice]
        
        # Zaznamenej pokrok
        if trakt.scrobble_stop(tmdb_id, media_type, progress,
                              params.get('season'), params.get('episode')):
            xbmcgui.Dialog().notification('Trakt.tv', f'Pokrok {int(progress)}% zaznamenán ✓', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('Trakt.tv', 'Chyba při zaznamenávání', xbmcgui.NOTIFICATION_ERROR)
            
    except Exception as e:
        xbmc.log(f'Trakt record progress error: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Trakt.tv', f'Chyba: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

# Main entry point
if __name__ == '__main__':
    try:
        logging.info('Tshare plugin started')
        router(sys.argv[2][1:])
        logging.info('Tshare plugin finished')
    except Exception as e:
        logging.error(f'Fatal error in main: {str(e)}')
        traceback.print_exc()
        popinfo('Fatální chyba při spouštění', icon=xbmcgui.NOTIFICATION_ERROR, sound=True)

def play_series_history(params):
    """Přehraje epizodu ze seriálové historie"""
    try:
        stream_url = params.get('stream_url')
        if stream_url:
            listitem = xbmcgui.ListItem(label=params.get('series_name') or 'Přehrát', path=stream_url)
            listitem.setProperty('mimetype', 'application/octet-stream')
            xbmcplugin.setResolvedUrl(_handle, True, listitem)
            return
        series_name = params.get('series_name')
        season = params.get('season')
        episode = params.get('episode')
        if not (series_name and season and episode):
            popinfo('Chybí parametry pro přehrání ze historie', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        sm = series_manager.SeriesManager(_addon, _profile)
        streams = sm.get_streams_for_episode(series_name, season, episode)
        if not streams:
            popinfo('Stream pro tuto epizodu nebyl nalezen', icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        # Přehrát první (preferovaný) stream
        params_play = {'ident': streams[0]['ident'], 'name': streams[0]['name']}
        play(params_play)
    except Exception as e:
        logging.error(f'Error in play_series_history: {str(e)}')
        popinfo('Chyba při přehrávání ze seriálové historie', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def show_movies_history():
    try:
        history = load_movies_history()
        if not history:
            xbmcgui.Dialog().notification('Tshare', 'Historie filmů je prázdná', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return
        for i, entry in enumerate(history):
            # Zobraz název a rok
            label = entry.get('cz_title') or entry.get('title') or 'Neznámý film'
            if entry.get('year'):
                label = f"{label} ({entry['year']})"
            listitem = xbmcgui.ListItem(label=label)
            # Popis
            if entry.get('plot'):
                listitem.setInfo('video', {'plot': entry['plot']})
            # Plakát
            if entry.get('poster'):
                poster_url = entry['poster']
                if poster_url and not poster_url.startswith('http'):
                    poster_url = f"https://image.tmdb.org/t/p/w500{poster_url}"
                listitem.setArt({'poster': poster_url, 'icon': poster_url})
            else:
                listitem.setArt({'icon': 'DefaultMovies.png'})
            listitem.setProperty('IsPlayable', 'true')
            
            # Context menu pro odstranění z historie - OPRAVENO: použij index pro spolehlivé mazání
            context_menu = [
                ('Odstranit z historie', f'RunPlugin({get_url(action="delete_movie_history", history_index=i, movie_title=label)})')
            ]
            listitem.addContextMenuItems(context_menu)
            
            # Předat tmdb_id i název pro případné fallbacky
            url_params = {
                'action': 'play_movie_history',
                'tmdb_id': entry.get('tmdb_id'),
                'cz_title': entry.get('cz_title'),
                'title': entry.get('title'),
                'year': entry.get('year')
            }
            if entry.get('stream_url'):
                url_params['stream_url'] = entry.get('stream_url')
            url = get_url(**url_params)
            xbmcplugin.addDirectoryItem(_handle, url, listitem, False)
        xbmcplugin.endOfDirectory(_handle)
    except Exception as e:
        logging.error(f'Error in show_movies_history: {str(e)}')
        popinfo('Chyba při zobrazení historie filmů', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def play_movie_history(params):
    try:
        stream_url = params.get('stream_url')
        if stream_url:
            listitem = xbmcgui.ListItem(label=params.get('title') or params.get('cz_title') or 'Přehrát', path=stream_url)
            listitem.setProperty('mimetype', 'application/octet-stream')
            xbmcplugin.setResolvedUrl(_handle, True, listitem)
            return
        tmdb_id = params.get('tmdb_id')
        cz_title = params.get('cz_title')
        title = params.get('title')
        year = params.get('year')
        # Pokud máme tmdb_id, použij přesné info z TMDB
        movie_title = cz_title or title
        if tmdb_id:
            tmdb_data = get_tmdb_details(tmdb_id, media_type='movie')
            if tmdb_data:
                movie_title = tmdb_data.get('cz_title') or tmdb_data.get('title')
                year = tmdb_data.get('year') or year
        if not movie_title:
            popinfo('Chybí název filmu', icon=xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        # Znovu použij vyhledávání podle názvu filmu a přehraj první výsledek
        token = revalidate()
        if not token:
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
        # Najdi film přes dosearch
        query = movie_title
        if year:
            query = f"{movie_title} {year}"
        dosearch(token, query, 'video', SORTS[0], 1, 0, 'movie_history_play')
    except Exception as e:
        logging.error(f'Error in play_movie_history: {str(e)}')
        popinfo('Chyba při přehrávání filmu z historie', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def load_movies_history():
    path = os.path.join(_profile, 'movies_history.json')
    if os.path.exists(path):
        try:
            with io.open(path, 'r', encoding='utf8') as file:
                return json.load(file)
        except Exception:
            return []
    return []

def save_movies_history(history):
    path = os.path.join(_profile, 'movies_history.json')
    try:
        with io.open(path, 'w', encoding='utf8') as file:
            json.dump(history, file, indent=2)
    except Exception:
        pass

def add_movie_to_history(movie_title):
    import time
    history = load_movies_history()
    # Pokud je movie_title dict, uložíme vše potřebné
    import logging
    logging.warning(f'add_movie_to_history: vstup={movie_title}')
    if isinstance(movie_title, dict):
        # Ulož cokoliv, co přijde, bez podmínek
        entry = dict(movie_title)
        if 'timestamp' not in entry:
            entry['timestamp'] = int(time.time())
       
        history.insert(0, entry)
        logging.warning(f'add_movie_to_history: UKLÁDÁM entry={entry}')
    else:
        logging.warning('add_movie_to_history: NEUKLÁDÁM, není dict')
        return
    history = history[:100]
    save_movies_history(history)

# --- NOVÁ FUNKCE: show_playback_history ---
def show_playback_history():
    try:
        logging.warning('Zobrazuji hlavní menu historie přehrávání')
        listitem_movies = xbmcgui.ListItem(label='Historie filmů')
        listitem_movies.setArt({'icon': 'DefaultMovies.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='movies_history'), listitem_movies, True)

        listitem_series = xbmcgui.ListItem(label='Historie seriálů')
        listitem_series.setArt({'icon': 'DefaultTVShows.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='series_history'), listitem_series, True)

        xbmcplugin.endOfDirectory(_handle)
    except Exception as e:
        logging.error(f'Error in show_playback_history: {str(e)}')
        popinfo('Chyba při zobrazení historie přehrávání', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle)

def deduplicate_results(results):
    """Odstraní duplicitní výsledky na základě názvu souboru, ale zachová nejlepší verzi podle chytrého řazení"""
    if not results:
        return results
    
    seen_files = {}
    unique_results = []
    
    for result in results:
        # Získej identifikátor souboru (pouze název, bez velikosti pro flexibilnější detekci)
        file_name = result.get('name', '').strip().lower()
        
        if not file_name:
            unique_results.append(result)
            continue
        
        # Normalizuj název pro porovnání (odstraň speciální znaky, mezery)
        normalized_name = re.sub(r'[^\w\d]+', '', file_name)
        
        if normalized_name in seen_files:
            # Už máme podobný soubor - porovnej kvality
            existing_result = seen_files[normalized_name]
            existing_quality = get_quality_score(existing_result.get('name', ''))
            existing_czech = get_czech_score(existing_result.get('name', ''))
            existing_size = get_file_size_score(existing_result.get('size', 0))
            
            current_quality = get_quality_score(result.get('name', ''))
            current_czech = get_czech_score(result.get('name', ''))
            current_size = get_file_size_score(result.get('size', 0))
            
            # Použij stejnou logiku jako chytré řazení pro rozhodnutí
            existing_score = existing_czech * 10000 + existing_quality * 100 + min(existing_size, 99)
            current_score = current_czech * 10000 + current_quality * 100 + min(current_size, 99)
            
            if current_score > existing_score:
                # Současný soubor je lepší - nahraď ho v seznamu
                for i, item in enumerate(unique_results):
                    if item == existing_result:
                        unique_results[i] = result
                        break
                seen_files[normalized_name] = result
                logging.debug(f"Replaced duplicate: '{existing_result.get('name')}' -> '{result.get('name')}' (better score)")
            else:
                logging.debug(f"Skipped duplicate: '{result.get('name')}' (worse than '{existing_result.get('name')}')")
        else:
            # Nový soubor
            seen_files[normalized_name] = result
            unique_results.append(result)
    
    logging.info(f"Smart deduplication: {len(results)} -> {len(unique_results)} unique files")
    return unique_results

