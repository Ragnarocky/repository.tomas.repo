# -*- coding: utf-8 -*-
# Module: adaptive_search
# Author: Tomas for friends
# Created on: 17.9.2025
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import re
import threading
import xbmc  # type: ignore
import unidecode  # type: ignore
from collections import defaultdict

class AdaptiveSeriesSearch:
    """
    Inteligentní adaptivní vyhledávač seriálů.
    
    Místo fixního počtu dotazů používá adaptivní strategii:
    - Najde základní pokrytí pomocí obecných dotazů
    - Systematicky hledá specifické epizody dokud něco nachází
    - Automaticky končí když několik dotazů po sobě nevrátí nic nového
    """
    
    def __init__(self, series_manager):
        self.sm = series_manager  # reference na SeriesManager pro využití jeho metod
        
        # Mapování římských číslic
        self.roman_numerals = {
            'i': '1', 'ii': '2', 'iii': '3', 'iv': '4', 'v': '5',
            'vi': '6', 'vii': '7', 'viii': '8', 'ix': '9', 'x': '10'
        }
        
        # Běžné pattern pro pokračování seriálů
        self.continuation_patterns = [
            'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x',
            '2', '3', '4', '5', '6', '7', '8', '9', '10',
            'nova serie', 'nova seria', 'new series', 'pokracovani', 'fortsetzung'
        ]
    
    def search(self, series_name, api_function, token):
        """Hlavní metoda pro adaptivní vyhledávání série"""
        try:
            # Uložení series_name (jednoduchá verze)
            self.current_series_name = series_name
            
            # Příprava základních názvů
            base = unidecode.unidecode(series_name or '').lower()
            base = re.sub(r'[^a-z0-9& ]', '', base).strip()
            base_dot = base.replace(' ', '.')
            base_dash = base.replace(' ', '-')
            base_us = base.replace(' ', '_')
            
            # Nové: Generuj varianty s římskými číslicemi a pokračováními
            base_variants = self._generate_series_variants(base)

            # Tracking výsledků
            all_results = []
            seen_idents = set()
            grouped = {}
            season_coverage = defaultdict(set)
            
            xbmc.log(f'Adaptive Search: Starting search for "{series_name}"', level=xbmc.LOGINFO)
            
            # Fáze 1: Základní průzkum
            self._phase1_basic_discovery(base, base_dot, api_function, token, seen_idents, grouped, season_coverage)
            
            # Fáze 2: Systematické hledání S01
            self._phase2_systematic_s01(base, api_function, token, seen_idents, grouped, season_coverage)
            
            # Fáze 3: Systematické hledání S02
            self._phase3_systematic_s02(base, api_function, token, seen_idents, grouped, season_coverage)
            
            # 🧠 PATTERN LEARNING RECOVERY: Když Phase 2&3 našly málo, hledej v objevených sezónách
            current_episodes = sum(len(v) for v in season_coverage.values())
            discovered_seasons = sorted([int(s) for s in season_coverage.keys() if s.isdigit()])
            
            if current_episodes < 15 and len(discovered_seasons) > 2:  # Málo epizod, ale Phase 1 něco našla
                xbmc.log(f'Adaptive Search: Pattern Learning Recovery triggered - {current_episodes} episodes from Phase 2&3, but {len(discovered_seasons)} seasons discovered', xbmc.LOGINFO)
                self._pattern_learning_recovery(base, discovered_seasons, api_function, token, seen_idents, grouped, season_coverage)
                current_episodes = sum(len(v) for v in season_coverage.values())  # Aktualizuj počet
            
            # 🚀 INTELIGENTNÍ ROZHODOVÁNÍ: Spusť pokročilé fáze jen když má smysl
            
            should_run = self._should_run_advanced_phases(current_episodes, series_name)
            xbmc.log(f'Adaptive Search: Should run advanced phases for "{series_name}"? {should_run} (current episodes: {current_episodes})', xbmc.LOGINFO)
            
            if should_run:
                # FÁZE 4: Hledání variant s pokračováním
                xbmc.log(f'Adaptive Search: Starting Phase 4 for "{series_name}"', xbmc.LOGINFO)
                self._phase4_series_variants(base_variants, api_function, token, seen_idents, grouped, season_coverage)
                
                # FÁZE 5: Číslované pokračování (velkolepe-stoleti-iii-XX)
                xbmc.log(f'Adaptive Search: Starting Phase 5 for "{series_name}"', xbmc.LOGINFO)
                self._phase5_numbered_continuations(base, series_name, api_function, token, seen_idents, grouped, season_coverage)
            else:
                xbmc.log(f'Adaptive Search: Skipping advanced phases for "{series_name}" - not beneficial (found {current_episodes} episodes)', xbmc.LOGINFO)
            
            # Výsledky s chytrým řazením
            all_results = list(grouped.values())
            
            # 🇨🇿 PREFERUJ ČESKÉ NÁZVY + VĚTŠÍ SOUBORY
            all_results = self._sort_results_intelligently(all_results)
            
            self._log_final_stats(series_name, all_results, season_coverage)
            
            return all_results
            
        except Exception as e:
            xbmc.log(f'Adaptive Search: Error searching "{series_name}": {e}', level=xbmc.LOGERROR)
            return []
    
    def _phase1_basic_discovery(self, base, base_dot, api_function, token, seen_idents, grouped, season_coverage):
        """Fáze 1: Základní dotazy pro získání přehledu o dostupných epizodách - OPTIMALIZOVANÉ"""
        basic_queries = [
            f'{base} cz', f'{base} czech', 
            base, base_dot, 
            base.replace(' ', '-'), base.replace(' ', '_'),
            # Přidej specifické dotazy pro starší sezóny aby se dostal přes limit 300 nejnovějších
            f'{base} s01', f'{base} s02', f'{base} s03', f'{base} s04', f'{base} s05',
            f'{base} s10', f'{base} s15', f'{base} s20', f'{base} s25', f'{base} s30',
            f's01 {base}', f's02 {base}', f's03 {base}', f's10 {base}', f's20 {base}'
        ]
        
        # Speciální alternativy pro známé série
        if 'simpson' in base:
            alt_base = 'the simpsons'
            basic_queries.extend([
                f'{alt_base} cz', alt_base, alt_base.replace(' ', '.'),
                # Přidáme jen nejúčinnější varianty
                'simpson cz', 'simpson', 'simpsons cz', 'simpsons'
            ])
        
        xbmc.log(f'Adaptive Search: Phase 1 - Basic discovery with {len(basic_queries)} queries: {basic_queries}', level=xbmc.LOGINFO)
        
        for i, query in enumerate(basic_queries):
            xbmc.log(f'Adaptive Search: Phase 1 - Query {i+1}/{len(basic_queries)}: "{query}"', level=xbmc.LOGINFO)
            results = self.sm._perform_search(query, api_function, token)
            new_items = self._process_results(results, seen_idents, grouped, season_coverage)
            
            total_eps = sum(len(v) for v in season_coverage.values())
            seasons_found = sorted([int(s) for s in season_coverage.keys() if s.isdigit()])
            xbmc.log(f'Adaptive Search: Query "{query}" → {len(results)} files, +{new_items} new episodes, total: {total_eps} in seasons {seasons_found}', level=xbmc.LOGINFO)
    
    def _phase2_systematic_s01(self, base, api_function, token, seen_idents, grouped, season_coverage):
        """Fáze 2: Systematické hledání všech epizod první série - DŮKLADNÉ"""
        max_consecutive_empty = 2  # EMERGENCY: Sníženo na minimum
        consecutive_empty = 0
        s1_episodes = season_coverage.get('1', set())
        
        xbmc.log(f'Adaptive Search: Phase 2 - Systematic S01 search (currently have {len(s1_episodes)} episodes)', level=xbmc.LOGDEBUG)
        
        for ep in range(1, 31):  # Hledáme až do epizody 30
            if consecutive_empty >= max_consecutive_empty:
                xbmc.log(f'Adaptive Search: S01 search ended at E{ep:02d} - {consecutive_empty} consecutive empty queries', level=xbmc.LOGINFO)
                break
            
            xbmc.log(f'Adaptive Search: Phase 2 - Searching S01E{ep:02d}', level=xbmc.LOGDEBUG)
            
            # VŽDY hledej každou epizodu, i když už nějakou S01 máme
            # (Phase 1 může najít S01E20, ale ne S01E05)
            found_new = self._search_specific_episode(base, 1, ep, api_function, token, seen_idents, grouped, season_coverage)
            
            if found_new:
                consecutive_empty = 0
                s1_episodes = season_coverage.get('1', set())  # Aktualizace
            else:
                consecutive_empty += 1
    
    def _phase3_systematic_s02(self, base, api_function, token, seen_idents, grouped, season_coverage):
        """Fáze 3: Systematické hledání druhé série - DŮKLADNÉ"""
        max_consecutive_empty = 2  # EMERGENCY: Sníženo na minimum
        consecutive_empty = 0
        s2_episodes = season_coverage.get('2', set())
        
        xbmc.log(f'Adaptive Search: Phase 3 - Systematic S02 search (currently have {len(s2_episodes)} episodes)', level=xbmc.LOGDEBUG)
        
        for ep in range(1, 26):  # Hledáme až do epizody 25 pro S02
            if consecutive_empty >= max_consecutive_empty:
                xbmc.log(f'Adaptive Search: S02 search ended at E{ep:02d} - {consecutive_empty} consecutive empty queries', level=xbmc.LOGINFO)
                break
            
            xbmc.log(f'Adaptive Search: Phase 3 - Searching S02E{ep:02d}', level=xbmc.LOGDEBUG)
            
            # VŽDY hledej každou epizodu, i když už nějakou S02 máme
            found_new = self._search_specific_episode_s02(base, ep, api_function, token, seen_idents, grouped, season_coverage)
            
            if found_new:
                consecutive_empty = 0
                s2_episodes = season_coverage.get('2', set())
            else:
                consecutive_empty += 1
    
    def _search_specific_episode(self, base, season, episode, api_function, token, seen_idents, grouped, season_coverage):
        """Hledá konkrétní epizodu pomocí optimalizovaných vzorů"""
        # Pouze nejefektivnější dotazy pro rychlost
        ep_queries = [
            f'{base} s{season:02d}e{episode:02d}',  # Hlavní vzor: simpsonovi s02e03
            f's{season:02d}e{episode:02d} {base}',  # Obrácený vzor: s02e03 simpsonovi
            f'{base} {season}x{episode:02d}',       # Alternativní vzor
            f'{season}x{episode:02d} {base}',       # Obrácený alternativní vzor
        ]
        
        for query in ep_queries:
            results = self.sm._perform_search(query, api_function, token)
            for item in results:
                ident = item.get('ident')
                if not ident or ident in seen_idents:
                    continue
                
                if self._register_item(item, grouped):
                    seen_idents.add(ident)
                    s, e = self._update_coverage(item, season_coverage)
                    if s == season and e == episode:  # Našli jsme přesně tu epizodu, kterou hledáme
                        return True
        
        return False
    
    def _search_specific_episode_s02(self, base, episode, api_function, token, seen_idents, grouped, season_coverage):
        """Hledá konkrétní epizodu S02 (zjednodušená verze)"""
        ep_queries = [
            f'{base} s02e{episode:02d}',
            f's02e{episode:02d} {base}',  # Obrácený vzor
            f'{base} 2x{episode:02d}',
            f'2x{episode:02d} {base}'     # Obrácený vzor
        ]
        
        for query in ep_queries:
            results = self.sm._perform_search(query, api_function, token)
            for item in results:
                ident = item.get('ident')
                if not ident or ident in seen_idents:
                    continue
                
                if self._register_item(item, grouped):
                    seen_idents.add(ident)
                    s, e = self._update_coverage(item, season_coverage)
                    if s == 2 and e == episode:
                        return True
        
        return False
    
    def _process_results(self, results, seen_idents, grouped, season_coverage):
        """Zpracuje výsledky vyhledávání a vrátí počet nových epizod"""
        new_items = 0
        for item in results:
            ident = item.get('ident')
            if not ident or ident in seen_idents:
                continue
            
            if self._register_item(item, grouped):
                seen_idents.add(ident)
                s, e = self._update_coverage(item, season_coverage)
                if s and e:
                    new_items += 1
        
        return new_items
    
    def _register_item(self, item, grouped):
        """Registruje item do grouped dict, preference podle velikosti"""
        name = item.get('name') or ''
        key = self.sm._normalize_key(name)
        if not key:
            return False
        
        if key in grouped:
            best = self.sm._prefer_better(grouped[key], item)
            if best is not grouped[key]:
                grouped[key] = best
                return True
            return False
        
        grouped[key] = item
        return True
    
    def _update_coverage(self, item, season_coverage):
        """Aktualizuje sledování pokrytí epizod"""
        try:
            fn = item.get('name') or ''
            # Získání series_name
            series_name = getattr(self, 'current_series_name', None)
            s, e = self.sm._detect_episode_info(fn, series_name)
            if s is not None and e is not None:
                season_coverage[str(s)].add(int(e))
                return s, e
        except Exception:
            pass
        return None, None
    
    def _log_final_stats(self, series_name, all_results, season_coverage):
        """Zaloguje finální statistiky"""
        final_total = sum(len(v) for v in season_coverage.values())
        seasons_found = sorted([int(s) for s in season_coverage.keys() if s.isdigit()])
        
        xbmc.log(
            f'Adaptive Search: Completed "{series_name}": '
            f'{len(all_results)} files found, {final_total} episodes total, seasons: {seasons_found}', 
            level=xbmc.LOGINFO
        )
    
    def _generate_series_variants(self, base_name):
        """Generuje varianty názvu série pro lepší pokrytí"""
        variants = [base_name]
        
        try:
            # Definice stop slov (nezajímavá slova pro varianty)
            stop_words = {
                # Anglická
                'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
                # Česká
                'a', 'v', 've', 'na', 'za', 'do', 'od', 'po', 'při', 'bez', 'pro', 'před', 'mezi',
                'nad', 'pod', 'podle', 'během', 'kolem', 'že', 'aby', 'když', 'pokud', 'protože',
                'ale', 'nebo', 'ani', 'tak', 'také', 'již', 'už', 'jen', 'pouze', 'každý', 'všechen'
            }
            
            # Tokenizace a filtrování významných slov
            tokens = re.findall(r'\b\w+\b', base_name.lower())
            meaningful_tokens = [token for token in tokens if len(token) > 2 and token not in stop_words]
            
            # 1. Varianty s římskými číslicemi - celý název
            for roman, arabic in self.roman_numerals.items():
                # Normalizovaný název s pomlčkami (jako ve vzoru)
                dash_name = base_name.replace(' ', '-').replace('_', '-')
                
                # Přidej římské číslice k celému názvu - různé formáty
                variants.extend([
                    f'{base_name}_{roman}',
                    f'{base_name} {roman}', 
                    f'{base_name}.{roman}',
                    f'{base_name}-{roman}',
                    f'{dash_name}-{roman}',       # Velkolepé-století-III
                    f'{dash_name}-{roman.upper()}' # Velkolepé-století-III (velká písmena)
                ])
                
                # Přidej arabské číslice k celému názvu
                variants.extend([
                    f'{base_name}_{arabic}',
                    f'{base_name} {arabic}',
                    f'{base_name}.{arabic}',
                    f'{base_name}-{arabic}',
                    f'{dash_name}-{arabic}'
                ])
                
                # Přidej římské číslice k významným slovům jednotlivě
                if meaningful_tokens:
                    for token in meaningful_tokens[:3]:  # Max 3 slova
                        variants.extend([
                            f'{token}_{roman}',
                            f'{token} {roman}',
                            f'{token}{roman}',
                            f'{token}-{roman}',
                            f'{token}-{roman.upper()}'
                        ])
            
            # 2. Obecné pokračovací pattern
            for pattern in self.continuation_patterns[:8]:  # Omezeně pro výkon
                variants.extend([
                    f'{base_name}_{pattern}',
                    f'{base_name} {pattern}',
                    f'{base_name}.{pattern}'
                ])
            
            # 3. Zkrácené verze (pro dlouhé názvy)
            if len(base_name.split()) > 2:
                words = base_name.split()
                short_name = ' '.join(words[:2])  # První dvě slova
                variants.extend([
                    short_name,
                    short_name.replace(' ', '_'),
                    short_name.replace(' ', '.')
                ])
            
            # 4. Bez diakritiky a speciální znaky
            clean_name = re.sub(r'[^a-z0-9 ]', '', base_name)
            if clean_name != base_name:
                variants.append(clean_name)
                variants.append(clean_name.replace(' ', '_'))
                variants.append(clean_name.replace(' ', '-'))  # Přidej pomlčkovou verzi
            
            # 5. Speciální varianty pro konkrétní případy
            if 'velkolep' in base_name.lower() or 'stoleti' in base_name.lower():
                # Přidej specifické varianty pro Velkolepé století
                special_variants = [
                    'velkolep stoleti', 'velikolep stoleti', 'velkolepe stoleti',
                    'velkolep-stoleti', 'velikolep-stoleti', 'velkolepe-stoleti'
                ]
                for variant in special_variants:
                    variants.append(variant)
                    for roman, arabic in self.roman_numerals.items():
                        if arabic <= 6:  # I-VI pro Velkolepé století
                            variants.extend([
                                f'{variant}-{roman}',
                                f'{variant}-{roman.upper()}',
                                f'{variant} {roman}',
                                f'{variant}_{roman}',
                                # 🎯 KLÍČOVÉ: Přesný vzor z Webshare
                                f'{variant.replace(" ", "-")}-{roman}',  # velkolepe-stoleti-iii
                            ])
            
            xbmc.log(f'Generated {len(variants)} search variants for "{base_name}"', xbmc.LOGDEBUG)
            return list(set(variants))  # Odstraň duplicity
            
        except Exception as e:
            xbmc.log(f'Error generating variants: {str(e)}', xbmc.LOGWARNING)
            return [base_name]
    
    def _phase4_series_variants(self, variants, api_function, token, seen_idents, grouped, season_coverage):
        """Fáze 4: Hledání variant seriálu (římské číslice, pokračování)"""
        try:
            xbmc.log('Phase 4: Searching series variants with continuations', xbmc.LOGINFO)
            
            for variant in variants[:8]:  # Sníženo z 15 na 8 pro rychlost
                if len(seen_idents) >= 150:  # Sníženo z 200 na 150
                    break
                
                xbmc.log(f'Searching variant: "{variant}"', xbmc.LOGDEBUG)
                
                # Hledej základní variantu
                results = self.sm._perform_search(variant, api_function, token)
                if results:
                    for item in results:
                        ident = item.get('ident')
                        if ident and ident not in seen_idents:
                            seen_idents.add(ident)
                            grouped[ident] = item
                            self._update_coverage(item, season_coverage)
                
                # Jen nejzákladnější epizodní varianty pro rychlost
                episode_variants = [
                    f'{variant} s01',
                    f'{variant} s1',
                    f'{variant}_s01'
                ]
                
                for ep_variant in episode_variants:
                    if len(seen_idents) >= 150:  # Sníženo z 200 na 150
                        break
                        
                    results = self.sm._perform_search(ep_variant, api_function, token)
                    if results:
                        for item in results:
                            ident = item.get('ident')
                            if ident and ident not in seen_idents:
                                seen_idents.add(ident)
                                grouped[ident] = item
                                self._update_coverage(item, season_coverage)
            
            xbmc.log(f'Phase 4 completed: {len(seen_idents)} total items found', xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f'Error in phase 4: {str(e)}', xbmc.LOGWARNING)
    
    def _phase5_numbered_continuations(self, base, series_name, api_function, token, seen_idents, grouped, season_coverage):
        """Fáze 5: Adaptabilní hledání číslovaných pokračování (xxx-iii-XX formát)"""
        try:
            xbmc.log(f'Phase 5: Adaptive numbered continuations search for "{series_name}"', xbmc.LOGINFO)
            xbmc.log(f'Phase 5: Input base parameter: "{base}"', xbmc.LOGINFO)
            
            # 🧠 ADAPTABILNÍ: Generuj base_patterns ze jména seriálu
            base_patterns = self._generate_adaptive_base_patterns(series_name, base)
            xbmc.log(f'Phase 5: Generated {len(base_patterns)} base patterns: {base_patterns[:3]}', xbmc.LOGINFO)
            
            found_episodes = 0
            max_episodes_per_season = 60  # Rozumný limit
            max_seasons = 10  # Max sezóny k hledání
            
            for base_pattern in base_patterns[:2]:  # Sníženo z 3 na 2 pro rychlost
                xbmc.log(f'Phase 5: Trying base pattern "{base_pattern}"', xbmc.LOGINFO)
                
                for roman_num, season_num in [('ii', 2), ('iii', 3), ('iv', 4), ('v', 5), ('vi', 6), ('vii', 7), ('viii', 8), ('ix', 9), ('x', 10)]:
                    # 🚀 RYCHLÉ UKONČENÍ: Pouze pro neznámé série s mnoha epizodami (přesunuté dovnitř)
                    current_total = sum(len(v) for v in season_coverage.values())
                    
                    # Pro známé série (Velkolepé století) VŽDY pokračuj
                    known_series_keywords = ['velkolep', 'stoleti', 'hra', 'trun', 'walking', 'dead']
                    series_lower = series_name.lower()
                    is_known_series = any(kw in series_lower for kw in known_series_keywords)
                    
                    if not is_known_series and current_total >= 100:  # Pouze neznámé série s 100+ epizod
                        xbmc.log(f'Phase 5: Stopping roman search for unknown series - already found {current_total} episodes', xbmc.LOGINFO)
                        break
                    elif is_known_series and roman_num == 'ii':  # Log pouze jednou
                        xbmc.log(f'Phase 5: Continuing roman search for known series "{series_name}" (found {current_total} episodes)', xbmc.LOGINFO)
                    if season_num > max_seasons:
                        break
                    
                    # 🎯 NOVÁ STRATEGIE: Hledej nejprve obecný pattern pro celou sezónu
                    season_pattern = f'{base_pattern}-{roman_num}'
                    xbmc.log(f'Phase 5: Searching season pattern "{season_pattern}" for series "{series_name}"', xbmc.LOGINFO)
                    
                    season_results = self.sm._perform_search(season_pattern, api_function, token)
                    xbmc.log(f'Phase 5: Search "{season_pattern}" returned {len(season_results) if season_results else 0} results', xbmc.LOGINFO)
                    
                    if season_results:
                        xbmc.log(f'Phase 5: Found {len(season_results)} items for season pattern "{season_pattern}" - processing...', xbmc.LOGINFO)
                        
                        # Log první pár výsledků pro debugging
                        for i, item in enumerate(season_results[:3]):
                            xbmc.log(f'Phase 5: Result {i+1}: {item.get("name", "N/A")}', xbmc.LOGINFO)
                        
                        # Zpracuj všechny výsledky pro tuto sezónu najednou
                        for item in season_results:
                            ident = item.get('ident')
                            if ident and ident not in seen_idents:
                                seen_idents.add(ident)
                                grouped[ident] = item
                                self._update_coverage(item, season_coverage)
                                found_episodes += 1
                        
                        continue  # Přeskoč jednotlivé dotazy pro tuto sezónu
                    
                    # FALLBACK: Pokud obecný pattern nefunguje, zkus jednotlivé díly
                    consecutive_misses = 0
                    max_consecutive_misses = 5  # Kratší limit pro fallback
                    
                    for episode_num in range(1, 21):  # Kratší rozsah pro fallback
                        if len(seen_idents) >= 200:  # Sníženo z 400 na 200
                            xbmc.log('Phase 5: Reached global limit, stopping', xbmc.LOGINFO)
                            break
                            
                        search_pattern = f'{base_pattern}-{roman_num}-{episode_num}'
                        
                        results = self.sm._perform_search(search_pattern, api_function, token)
                        if results:
                            consecutive_misses = 0  # Reset počítadla
                            
                            for item in results:
                                ident = item.get('ident')
                                if ident and ident not in seen_idents:
                                    seen_idents.add(ident)
                                    grouped[ident] = item
                                    self._update_coverage(item, season_coverage)
                                    found_episodes += 1
                        else:
                            consecutive_misses += 1
                            
                        # 🎯 ADAPTABILNÍ ZASTAVENÍ: Kratší limit pro fallback
                        if consecutive_misses >= max_consecutive_misses:
                            break
                
                # 📊 STATISTIKA per base_pattern
                if found_episodes > 0:
                    xbmc.log(f'Phase 5: Base pattern "{base_pattern}" found {found_episodes} total episodes', xbmc.LOGDEBUG)
            
            xbmc.log(f'Phase 5 completed: {found_episodes} new episodes found, {len(seen_idents)} total items', xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f'Error in phase 5: {str(e)}', xbmc.LOGWARNING)
    
    def _should_run_advanced_phases(self, current_episodes, series_name):
        """🧠 Rozhoduje, jestli spustit pokročilé fáze 4&5 (časově náročné)"""
        try:
            xbmc.log(f'Phase Decision: Evaluating "{series_name}" with {current_episodes} episodes', xbmc.LOGINFO)
            
            # 0. 🚀 SUPER RYCHLÉ UKONČENÍ: Žádné epizody - pravděpodobně neexistuje
            if current_episodes == 0:
                xbmc.log(f'Phase Decision: 0 episodes found - series likely doesn\'t exist, skipping advanced phases', xbmc.LOGINFO)
                return False
            
            # 1. 🚀 RYCHLÉ UKONČENÍ: Velmi malé seriály (≤6 epizody) - přeskoč
            if current_episodes <= 6:
                xbmc.log(f'Phase Decision: ≤6 episodes ({current_episodes}) - checking known series...', xbmc.LOGINFO)
            else:
                xbmc.log(f'Phase Decision: >6 episodes ({current_episodes}) - would proceed anyway', xbmc.LOGINFO)
                # Nepokračuj s return False, zkontroluj i známé série
            
            # 2. 🎯 ZNÁMÉ SERIÁLY: Spusť vždy (včetně Marvel)
            known_series_keywords = [
                'velkolep', 'stoleti', 'hra', 'trun', 'walking', 'dead', 'breaking', 'bad',
                'sherlock', 'doctor', 'who', 'game', 'thrones', 'friends', 'office',
                'marvel', 'zombie', 'zombies', 'avengers', 'spider', 'batman', 'superman'
            ]
            series_lower = series_name.lower()
            matching_keywords = [kw for kw in known_series_keywords if kw in series_lower]
            
            if matching_keywords:
                xbmc.log(f'Phase Decision: ✅ Known series detected! Keywords: {matching_keywords}', xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f'Phase Decision: No known keywords found in "{series_lower}"', xbmc.LOGINFO)
                
            # Teprve teď zkontroluj threshold pro neznámé série
            if current_episodes <= 6:
                xbmc.log(f'Phase Decision: ❌ Unknown series with ≤6 episodes - skipping', xbmc.LOGINFO)
                return False
            
            # 3. 📊 STŘEDNÍ SERIÁLY: Pokud už našel 15+ epizod, pravděpodobně má více
            if current_episodes >= 15:
                return True
            
            # 4. 🔍 DETEKCE POKRAČOVÁNÍ: Pokud název obsahuje číslice/pokračovací slova
            continuation_indicators = [
                'ii', 'iii', 'iv', 'nova', 'new', 'pokracovani', 'season', 'series', 
                'cast', 'dil', 'rada', '2', '3', '4', '5'
            ]
            if any(indicator in series_lower for indicator in continuation_indicators):
                return True
            
            # 5. ⚡ OPTIMALIZACE: Střední rozsah (7-14 epizod) - přeskoč pro rychlost
            return False
            
        except Exception:
            # Při chybě raději spusť (bezpečná volba)
            return True
    
    def _generate_adaptive_base_patterns(self, series_name, base):
        """🧠 Generuje adaptabilní base_patterns pro jakýkoliv seriál"""
        patterns = []
        
        try:
            # 1. Základní normalizace názvu
            clean_name = unidecode.unidecode(series_name).lower()
            clean_name = re.sub(r'[^a-z0-9 ]', '', clean_name).strip()
            
            # 🇨🇿 PŘIDEJ PŮVODNÍ ČESKÝ TVAR (bez diakritiky, ale správně)
            czech_name = series_name.lower()
            # Specifické české mapování - některá slova mají jiný kořen
            czech_name = czech_name.replace('století', 'stoleti')  # Speciální případ
            czech_name = czech_name.replace('velkolepé', 'velkolepe')  # Zachovej plný tvar
            
            # Standardní diakritika
            czech_name = czech_name.replace('á', 'a').replace('é', 'e').replace('í', 'i')
            czech_name = czech_name.replace('ó', 'o').replace('ú', 'u').replace('ů', 'u')
            czech_name = czech_name.replace('ý', 'y').replace('č', 'c').replace('ď', 'd')
            czech_name = czech_name.replace('ě', 'e').replace('ň', 'n').replace('ř', 'r')
            czech_name = czech_name.replace('š', 's').replace('ť', 't').replace('ž', 'z')
            czech_name = re.sub(r'[^a-z0-9 ]', '', czech_name).strip()
            
            # 2. Různé formáty základu (použij ČESKÝ tvar primárně)
            words = czech_name.split()
            unidecode_words = clean_name.split()  # Backup unidecode verze
            # Kombinuj ČESKÝ i UNIDECODE tvary pro maximum pokrytí
            all_word_variants = [words, unidecode_words] if words != unidecode_words else [words]
            
            for word_set in all_word_variants:
                if len(word_set) >= 1:
                    # Celý název s různými oddělovači
                    patterns.extend([
                        '-'.join(word_set),           # velkolep-stoleti / velkolepe-stolete
                        '_'.join(word_set),           # velkolep_stoleti / velkolepe_stolete  
                        '.'.join(word_set),           # velkolep.stoleti / velkolepe.stolete
                        ''.join(word_set),            # velkolepostoleti / velkolepestolete
                    ])
                    
                    # První dvě slova (pro dlouhé názvy)
                    if len(word_set) >= 2:
                        first_two = word_set[:2]
                        patterns.extend([
                            '-'.join(first_two),   # velkolep-stoleti / velkolepe-stolete
                            '_'.join(first_two),   # velkolep_stoleti / velkolepe_stolete
                            ''.join(first_two),    # velkolepostoleti / velkolepestolete
                        ])
                    
                    # První slovo + zkrácené druhé
                    if len(word_set) >= 2 and len(word_set[1]) > 4:
                        short_second = word_set[1][:4]  # stoleti -> stol
                        patterns.extend([
                            f'{word_set[0]}-{short_second}',  # velkolep-stol
                            f'{word_set[0]}_{short_second}',  # velkolep_stol
                        ])
                    
                    # Zkrácené varianty (prvních 6-8 znaků každého slova)  
                    short_words = [w[:min(8, len(w))] for w in word_set if len(w) >= 3]
                    if short_words:
                        patterns.extend([
                            '-'.join(short_words),
                            '_'.join(short_words),
                        ])
            
            # 3. Odstraň duplicity a příliš krátké
            unique_patterns = []
            for pattern in patterns:
                if len(pattern) >= 4 and pattern not in unique_patterns:
                    unique_patterns.append(pattern)
            
            # 4. Seřaď podle pravděpodobnosti úspěchu (delší = lepší)
            unique_patterns.sort(key=len, reverse=True)
            
            xbmc.log(f'Phase 5: Generated {len(unique_patterns)} base patterns for "{series_name}": {unique_patterns[:5]}', xbmc.LOGINFO)
            return unique_patterns[:10]  # Max 10 nejlepších
            
        except Exception as e:
            xbmc.log(f'Error generating adaptive base patterns: {e}', xbmc.LOGWARNING)
            return [base.replace(' ', '-')]  # Fallback
    
    def _sort_results_intelligently(self, results):
        """🇨🇿 Inteligentní řazení - preferuj české názvy, větší soubory"""
        try:
            def get_czech_score(item):
                """Skóruj podle české priority"""
                name = (item.get('name') or '').lower()
                
                # Nejvyšší priorita: Obsahuje 'cz', 'czech', 'dabing'
                if any(keyword in name for keyword in ['cz', 'czech', 'dabing', 'czech.', '.cz.']):
                    return 1000
                
                # Střední priorita: Neobsahuje anglické indikátory
                english_indicators = ['eng', 'english', 'en.', '.en.', 'sub', 'subtitle']
                if not any(indicator in name for indicator in english_indicators):
                    return 500
                
                # Nízká priorita: Anglické názvy
                return 0
            
            def get_size(item):
                """Získej velikost souboru jako číselnou hodnotu"""
                try:
                    return int(item.get('size') or '0')
                except (ValueError, TypeError):
                    return 0
            
            # Seřaď podle: České priority (desc) -> Velikost souboru (desc) 
            return sorted(results, key=lambda item: (
                -get_czech_score(item),  # České názvy první
                -get_size(item)          # Větší soubory druhé
            ))
            
        except Exception as e:
            xbmc.log(f'Error sorting results intelligently: {e}', xbmc.LOGWARNING)
            return results  # Fallback na původní pořadí
    
    def _pattern_learning_recovery(self, base, discovered_seasons, api_function, token, seen_idents, grouped, season_coverage):
        """🧠 Pattern Learning Recovery - hledá v sezónách objevených Phase 1, ale vynechaných Phase 2&3"""  
        try:
            # Zjisti které sezóny už byly prohledány v Phase 2&3
            searched_seasons = {1, 2}  # Phase 2&3 hledaly S01, S02
            
            # Najdi sezóny které Phase 1 objevila, ale Phase 2&3 nehledaly
            recovery_seasons = [s for s in discovered_seasons if s not in searched_seasons]
            
            if not recovery_seasons:
                xbmc.log('Pattern Learning Recovery: No additional seasons to search', xbmc.LOGINFO)
                return
                
            xbmc.log(f'Pattern Learning Recovery: Searching seasons {recovery_seasons} (skipped by Phase 2&3)', xbmc.LOGINFO)
            
            episodes_found = 0
            
            # Hledej jen v top 3 sezónách (rychlost)
            for season_num in recovery_seasons[:3]:
                consecutive_empty = 0
                season_episodes = 0
                
                # Optimalizované hledání - jen klíčové epizody
                key_episodes = [1, 2, 3, 5, 10, 15, 20, 25]  # 8 dotazů místo 25+
                
                for ep in key_episodes:
                    if consecutive_empty >= 3:  # Rychlé ukončení
                        break
                        
                    if len(seen_idents) >= 150:  # Globální limit
                        xbmc.log('Pattern Learning Recovery: Hit global limit, stopping', xbmc.LOGINFO)
                        return
                    
                    found_new = self._search_specific_episode(base, season_num, ep, api_function, token, seen_idents, grouped, season_coverage)
                    
                    if found_new:
                        consecutive_empty = 0
                        season_episodes += 1
                        episodes_found += 1
                    else:
                        consecutive_empty += 1
                
                if season_episodes > 0:
                    xbmc.log(f'Pattern Learning Recovery: S{season_num:02d} → {season_episodes} episodes found', xbmc.LOGDEBUG)
            
            if episodes_found > 0:
                xbmc.log(f'Pattern Learning Recovery: Found {episodes_found} additional episodes in {len(recovery_seasons[:3])} seasons', xbmc.LOGINFO)
            else:
                xbmc.log('Pattern Learning Recovery: No additional episodes found', xbmc.LOGINFO)
                
        except Exception as e:
            xbmc.log(f'Error in Pattern Learning Recovery: {str(e)}', xbmc.LOGWARNING)