# -*- coding: utf-8 -*-

import xbmc # type: ignore
import xbmcgui # type: ignore

def main():
    """Vyhledej film pomocí originaltitle (anglického názvu)"""
    try:
        # Získej informace o filmu
        title = xbmc.getInfoLabel("ListItem.Label")
        year = xbmc.getInfoLabel("ListItem.Year")
        originaltitle = xbmc.getInfoLabel("ListItem.OriginalTitle")
        dbtype = xbmc.getInfoLabel("ListItem.DBTYPE")
        tmdb_id = xbmc.getInfoLabel("ListItem.UniqueId(tmdb)")
        
        xbmc.log(f'Search Movie Originaltitle Context Menu: title="{title}", originaltitle="{originaltitle}", year="{year}", dbtype="{dbtype}", tmdb_id="{tmdb_id}"', xbmc.LOGINFO)
        
        # Kontrola, zda je to film
        if dbtype not in ['movie', 'video']:
            xbmcgui.Dialog().notification(
                "Tshare", 
                "Tato funkce je pouze pro filmy", 
                xbmcgui.NOTIFICATION_WARNING, 
                4000
            )
            return
        
        # Kontrola, zda máme originaltitle
        if not originaltitle or originaltitle == title:
            xbmcgui.Dialog().notification(
                "Tshare", 
                "Anglický název není k dispozici nebo je stejný jako český", 
                xbmcgui.NOTIFICATION_WARNING, 
                4000
            )
            return
        
        # Vyhledej film pomocí originaltitle (anglického názvu)
        tshare_plugin_id = 'plugin.video.tshare'
        
        # Použij direct_search s originaltitle
        from urllib.parse import quote
        encoded_title = quote(str(originaltitle))
        encoded_year = quote(str(year)) if year else ''
        encoded_tmdb_id = quote(str(tmdb_id)) if tmdb_id else ''
        
        url = f'Container.Update(plugin://{tshare_plugin_id}?action=direct_search&what={encoded_title}&year={encoded_year}&tmdb_id={encoded_tmdb_id}&tmdb_type=movie)'
        
        xbmc.executebuiltin(url)
        
    except Exception as e:
        xbmc.log(f'Error in search_movie_originaltitle: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Tshare", 
            f"Chyba při vyhledávání: {str(e)}", 
            xbmcgui.NOTIFICATION_ERROR, 
            4000
        )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

if __name__ == '__main__':
    main()
