# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

def main():
    """Vyhledej seriál pomocí originaltitle a ulož pod českým názvem"""
    try:
        # Získej informace o seriálu
        title = xbmc.getInfoLabel("ListItem.Label")
        year = xbmc.getInfoLabel("ListItem.Year")
        originaltitle = xbmc.getInfoLabel("ListItem.OriginalTitle")
        
        xbmc.log(f'Search Originaltitle Context Menu: title="{title}", originaltitle="{originaltitle}", year="{year}"', xbmc.LOGINFO)
        
        # Kontrola, zda máme originaltitle
        if not originaltitle or originaltitle == title:
            xbmcgui.Dialog().notification(
                "Tshare", 
                "Originaltitle není k dispozici nebo je stejný jako český název", 
                xbmcgui.NOTIFICATION_WARNING, 
                4000
            )
            return
        
        # Vyhledej pomocí originaltitle, ale ulož pod českým názvem
        tshare_plugin_id = 'plugin.video.tshare'
        url = f'RunPlugin(plugin://{tshare_plugin_id}?action=search_originaltitle_save_as_czech&search_name={originaltitle}&save_as={title}&year={year})'
        xbmc.executebuiltin(url)
        
    except Exception as e:
        xbmc.log(f'Error in search_originaltitle: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Tshare", 
            f"Chyba při vyhledávání: {str(e)}", 
            xbmcgui.NOTIFICATION_ERROR, 
            4000
        )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

if __name__ == '__main__':
    main()