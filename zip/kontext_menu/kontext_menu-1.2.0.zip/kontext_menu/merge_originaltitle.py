# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

def main():
    """Vyhledej seriál a automaticky slouč s originaltitle"""
    try:
        # Získej informace o seriálu
        title = xbmc.getInfoLabel("ListItem.Label")
        year = xbmc.getInfoLabel("ListItem.Year")
        originaltitle = xbmc.getInfoLabel("ListItem.OriginalTitle")
        
        xbmc.log(f'Merge Context Menu: title="{title}", originaltitle="{originaltitle}", year="{year}"', xbmc.LOGINFO)
        
        # Kontrola, zda máme originaltitle
        if not originaltitle or originaltitle == title:
            xbmcgui.Dialog().notification(
                "Tshare", 
                "Originaltitle není k dispozici nebo je stejný jako český název", 
                xbmcgui.NOTIFICATION_WARNING, 
                4000
            )
            return
        
        # Spusť sloučené vyhledávání
        tshare_plugin_id = 'plugin.video.tshare'
        url = f'RunPlugin(plugin://{tshare_plugin_id}?action=series_merge_originaltitle&series_name={title}&originaltitle={originaltitle}&year={year})'
        xbmc.executebuiltin(url)
        
    except Exception as e:
        xbmc.log(f'Error in merge_originaltitle: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "Tshare", 
            f"Chyba při slučování: {str(e)}", 
            xbmcgui.NOTIFICATION_ERROR, 
            4000
        )
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

if __name__ == '__main__':
    main()