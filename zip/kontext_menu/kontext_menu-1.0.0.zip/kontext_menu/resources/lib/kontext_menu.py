# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import unicodedata
import requests
import hashlib
import xbmcvfs
from xml.etree import ElementTree as ET
import math

from urllib.parse import urlparse, parse_qs
from resources.lib.md5crypt import md5_crypt


addon = xbmcaddon.Addon(id='kontext_menu')
userpath = addon.getAddonInfo('profile')
ident_path = xbmcvfs.translatePath("%s/ident.txt" % userpath).encode().decode('utf-8')
qr_path = xbmcvfs.translatePath("%s/qr.png" % userpath).encode().decode('utf-8')
vs = {'0': '', '1': 'largest', '2': 'recent'}


def hash_password(password, salt):
    return hashlib.sha1(md5_crypt(password, salt).encode('utf-8')).hexdigest()


def login():
    user = addon.getSetting('user')
    passw = addon.getSetting('pass')
    req = requests.post('https://webshare.cz/api/salt/', data = {'username_or_email': user}).content
    status = ET.fromstring(req).find('status').text
    if status == 'OK':
        salt = ET.fromstring(req).find('salt').text
        psw = hash_password(passw, salt)
        req = requests.post('https://webshare.cz/api/login/', data = {'username_or_email': user, 'password': psw}).content
        status = ET.fromstring(req).find('status').text
        if status == 'OK':
            wst = ET.fromstring(req).find('wst').text
            addon.setSetting('wst', wst)
            xbmcgui.Dialog().notification("Webshare", "Přihlášení proběhlo úspěšně.", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
        else:
            message = ET.fromstring(req).find('message').text
            xbmcgui.Dialog().notification("Webshare", message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
            login_web()
    else:
        message = ET.fromstring(req).find('message').text
        xbmcgui.Dialog().notification("Webshare", message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        login_web()


def login_web():
    req = requests.get('https://webshare.cz/api/auth_token/').content
    token = ET.fromstring(req).find('auth_token').text
    url = 'https://webshare.cz/api/qr_login/'
    import qrcode
    qr_code = qrcode.QRCode()
    qr_code.add_data(url + '?token=' + token)
    qr_code.make(fit=True)
    img = qr_code.make_image(fill_color="white", back_color="black")
    img.save(qr_path)
    if xbmcgui.Dialog().ok('WEBSHARE QR LOGIN', 'Otevřete QR čtečku v aplikaci Webshare a naskenujte QR kód') == True:
        req = requests.post('https://webshare.cz/api/user_info_token/', data = {'auth_token': token}).content
        status = ET.fromstring(req).find('status').text
        if status == 'OK':
            wst = ET.fromstring(req).find('wst').text
            addon.setSetting('wst', wst)
            xbmcgui.Dialog().notification("Webshare", "Přihlášení proběhlo úspěšně.", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
        else:
            xbmcgui.Dialog().notification("Webshare", "Nepovedlo se přihlásit.", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)


def get_stream_url(ident):
    wst = addon.getSetting('wst')
    req = requests.post('https://webshare.cz/api/file_link/', data = {'wst': wst, 'ident': ident}).content
    status = ET.fromstring(req).find('status').text
    if status == 'OK':
        return ET.fromstring(req).find('url').text
    else:
        message = ET.fromstring(req).find('message').text
        if message == 'wst is missing, invalid or expired':
            login()
            return 'error'
        xbmcgui.Dialog().notification("Webshare", message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)


def get_stream_list_ws():
    tshare_plugin_id = 'plugin.video.tshare'  # Tuto hodnotu prosím zkontrolujte!
    
    title = xbmc.getInfoLabel("ListItem.Label")
    year = xbmc.getInfoLabel("ListItem.Year")
    dbtype = xbmc.getInfoLabel("ListItem.DBTYPE")
    
    query = ""
    if dbtype == 'episode':
        query = xbmc.getInfoLabel("ListItem.TVShowTitle")
    elif dbtype == 'movie':
        query = title.split(' - ')[0]
    elif dbtype == 'video':
        query = title.split('B]')[1].replace('[/', '')
    else:
        query = title
    
    # Zavolá se vyhledávání v doplňku tshare
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    xbmc.executebuiltin(f'RunPlugin(plugin://{tshare_plugin_id}?action=series_search&series_name={query})')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

def get_stream_list_movies(id):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        req = requests.get('http://saros.funsite.cz/sc/ws/movies/' + str(id) + '.json').json()
        streams = req['strms']
        name_list = []
        for name in streams:
            name_list.append("[B][" + name['lang'] + '] ' + name['quality'] + '[/B] - ' + name['size'] + name['ainfo'])
        if name_list == []:
            get_stream_list_ws()
            return
        name_list.append('[COLOR lightskyblue]Vyhledat na Webshare[/COLOR]')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        index = xbmcgui.Dialog().select(req['title'], name_list)
        if index == -1:
            return
        else:
            if name_list[index] == 'Vyhledat na Webshare':
                xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
                get_stream_list_ws()
            else:
                streamUrl = get_stream_url(str(streams[index]['ident']))
                if streamUrl:
                    listItem = xbmcgui.ListItem(path=streamUrl)
                    xbmc.Player().play(item=streamUrl, listitem=listItem)
                    return
    except:
        get_stream_list_ws()


def get_stream_list_episodes(season_id, episode_id, show_id):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        req = requests.get('https://saros.funsite.cz/sc/ws/series/' + str(show_id) + '.json').json()
        streams = req['seasons'][int(season_id) - 1]['episodes'][int(episode_id) - 1]['strms']
        
        unique_episodes = {}
        for stream in streams:
            ident = stream['ident']
            lang = stream['lang']
            quality = stream['quality']
            size = stream['size']
            
            # Create a unique key for each language and quality combo
            key = f"{lang}-{quality}"
            
            # Add to the list if not already present
            if key not in unique_episodes:
                unique_episodes[key] = {
                    'ident': ident,
                    'label': f"[B][{lang}] {quality}[/B] - {size}"
                }
        
        name_list = []
        for key in unique_episodes:
            name_list.append(unique_episodes[key]['label'])

        if not name_list:
            get_stream_list_ws()
            return

        name_list.append('[COLOR lightskyblue]Vyhledat na Webshare[/COLOR]')
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        index = xbmcgui.Dialog().select(req['title'], name_list)
        
        if index == -1:
            return
        
        if name_list[index] == 'Vyhledat na Webshare':
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            get_stream_list_ws()
            return
        
        # Get the ident from the selected item
        selected_key = list(unique_episodes.keys())[index]
        selected_ident = unique_episodes[selected_key]['ident']
        
        streamUrl = get_stream_url(selected_ident)
        if streamUrl:
            listItem = xbmcgui.ListItem(path=streamUrl)
            xbmc.Player().play(item=streamUrl, listitem=listItem)
            return

    except:
        get_stream_list_ws()


def set_query_ws(query):
    kb = xbmc.Keyboard(query, 'Vyhledávání na Webshare')
    kb.doModal()
    if (kb.isConfirmed()):
        search_ws(kb.getText())
    else:
        return


def search_ws(query):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    req = requests.post('https://webshare.cz/api/search/', data = {'wst': '', 'offset': 0, 'limit': 20, 'category': 'video', 'sort': vs[addon.getSetting('sorting')], 'what': query}).content
    xml = ET.fromstring(req)
    if xml.find('status').text == 'OK':
        name_list = []
        for file in xml.findall('file'):
            name = file.find('name').text
            url = file.find('ident').text
            size = int(file.find('size').text)
            name_list.append(('[' + convert_size(size) + '] ' + name, url))

        name_list.append(('[COLOR lightskyblue]Zadat ručně[/COLOR]', ''))
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        index = xbmcgui.Dialog().select('WEBSHARE', [x[0] for x in name_list])

        if index == -1:
            return
        else:
            if index == len(name_list) - 1:
                set_query_ws(query)
            else:

                streamUrl = get_stream_url(str(name_list[index][1]))
                if streamUrl:
                    listItem = xbmcgui.ListItem(path=streamUrl)
                    xbmc.Player().play(item=streamUrl, listitem=listItem)
                    return


def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])


def run():
    path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    parsed = urlparse(path)
    dbtype = xbmc.getInfoLabel("ListItem.DBTYPE")
    try:
        url_param = parse_qs(parsed.query)["url"][0]
        if dbtype == 'movie' or dbtype == 'video':
            id = (bytes.fromhex(url_param).decode('utf-8')).split('/')[-1]
            get_stream_list_movies(id)
        else:
            id = (bytes.fromhex(url_param).decode('utf-8')).split('/')
            get_stream_list_episodes(id[-3], id[-2], id[-1])
    except KeyError:
        get_stream_list_ws()
    except Exception as e:
        xbmcgui.Dialog().notification("Webshare","Došlo k chybě: " + str(e), xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        get_stream_list_ws()


if __name__ == '__main__':
    try:
        import math
        run()
    except:
        run()