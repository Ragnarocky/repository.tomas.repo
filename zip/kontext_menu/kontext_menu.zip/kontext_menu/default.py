import sys
from resources.lib import kontext_menu


if __name__ == '__main__':
    kontext_menu.run()